Brogue: Community Edition, WebAssembly build
============================================
This is the Brogue CE source (upstream https://github.com/tmewett/BrogueCE, commit 363440c)
with a browser platform added. All changes from upstream are in wasm-port.patch:

  src/platform/wasm-platform.c   new: console that draws through JavaScript imports
  src/platform/main.c,           select the wasm console and call it directly
  platformdependent.c, platform.h
  src/brogue/IO.c                tells the page when Brogue wants typed text (names, seeds)
  src/brogue/Buttons.c,          tell the page which menu or title buttons are showing,
  src/brogue/MainMenu.c          so phones can show them as big touch targets
  src/brogue/Architect.c,        the recursive flood fills rewritten with explicit stacks.
  src/brogue/Grid.c, Items.c     Same visiting order, so seeds produce identical dungeons
                                 (checked against upstream: 150 seeds x 26 levels of
                                 --print-seed-catalog output match byte for byte), but no
                                 deep recursion, which overflowed the call stack in Safari.

  src/brogue/IO.c                (kid look) hover details can go to the page as a bubble while the
                                 page shows a zoomed-in view; enemies are never drawn as a unicorn
                                 (hallucination, discord) when the page asks for the kid look
  src/platform/wasm-platform.c   js_bubble / js_kid imports for the two items above
  src/platform/wasm-mem.c        plain memcpy/memmove/memset, so the module needs only original WebAssembly
                                 (built with -mcpu=mvp; Binaryen lowers the C library's sign-extension ops)

Build: build-wasm.sh (wasi-sdk 24 clang, then Binaryen wasm-opt --asyncify, then --legalize-js-interface
so 64-bit values cross to JavaScript as two 32-bit halves for older web engines).
web/brogue-core.js runs the module (WASI shim, saves in localStorage, canvas renderer, input);
web/brogue-ui.js adds the touch controls; web/brogue-music.js is the kid look's chiptune soundtrack;
web/make_html.py packs everything into one page. kid/ draws the kid look's animal sprites (Python + a browser).
web/tiles48.png is cut from bin/assets/tiles.png (CC BY-SA 4.0, see bin/assets/LICENSE.txt).

License: GNU Affero General Public License v3.0 (LICENSE.txt), same as Brogue CE.
