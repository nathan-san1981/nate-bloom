set -e
cd /root/wasm/brogue
W=/root/wasm/wasi-sdk-24.0-x86_64-linux
SRC="$(ls src/brogue/*.c src/variants/*.c) src/platform/main.c src/platform/platformdependent.c src/platform/null-platform.c src/platform/wasm-platform.c src/platform/wasm-mem.c"
$W/bin/clang --sysroot=$W/share/wasi-sysroot --target=wasm32-wasi -O2 -mcpu=mvp -mmutable-globals -std=c99 -Isrc/brogue -Isrc/platform -Isrc/variants -DDATADIR=. -DBROGUE_WASM '-DBROGUE_EXTRA_VERSION=""' -D_WASI_EMULATED_SIGNAL -D_WASI_EMULATED_PROCESS_CLOCKS -Wno-everything $SRC -lwasi-emulated-signal -lwasi-emulated-process-clocks -Wl,--export=malloc -Wl,--export=free -Wl,-z,stack-size=1048576 -Wl,--initial-memory=67108864 -o /root/wasm/out/brogue.wasm
B=/root/wasm/binaryen-version_119/bin
# Console calls are direct in the wasm build, so indirect calls (stdio, qsort) can never suspend:
# ignoring them keeps Asyncify's instrumentation (and stack frames) to the input/pause call paths.
EXTRA=""; [ "$ASSERTS" = 1 ] && EXTRA="--pass-arg=asyncify-asserts"
# original WebAssembly only (no bulk memory or sign-extension): the C library's sign-extension ops are
# lowered first, then everything is checked against the MVP feature set, so older web engines can load it
$B/wasm-opt --signext-lowering /root/wasm/out/brogue.wasm -o /root/wasm/out/brogue.wasm
$B/wasm-opt --mvp-features --enable-mutable-globals -O2 --asyncify --pass-arg=asyncify-imports@env.js_next_event,env.js_pause --pass-arg=asyncify-ignore-indirect $EXTRA /root/wasm/out/brogue.wasm -o /root/wasm/out/brogue.async.wasm
# 64-bit values cross to JavaScript as two 32-bit halves, so web engines without wasm-BigInt (Chrome < 85, older Fire tablets) can run it
$B/wasm-opt --mvp-features --enable-mutable-globals --legalize-js-interface /root/wasm/out/brogue.async.wasm -o /root/wasm/out/brogue.async.wasm
ls -la /root/wasm/out
$B/wasm-dis /root/wasm/out/brogue.async.wasm | grep "(import" 
