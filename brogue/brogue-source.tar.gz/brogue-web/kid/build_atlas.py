"""Rasterize kid sprites into two 16-column atlases (fixed colour + tint mask), 64x112 frames,
indexed like Brogue's own tiles (glyph - 130). Also writes a labelled contact sheet for review.
usage: build_atlas.py [--sheet]"""
import os, sys, json, base64, importlib
D = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, D)
import sprites; importlib.reload(sprites)
from playwright.sync_api import sync_playwright

NAMES = """G_POTION G_GRASS G_WALL G_DEMON G_OPEN_DOOR G_GOLD G_CLOSED_DOOR G_RUBBLE G_KEY G_BOG
G_CHAIN_TOP_LEFT G_CHAIN_BOTTOM_RIGHT G_CHAIN_TOP_RIGHT G_CHAIN_BOTTOM_LEFT G_CHAIN_TOP G_CHAIN_BOTTOM G_CHAIN_LEFT G_CHAIN_RIGHT
G_FOOD G_UP_STAIRS G_VENT G_DOWN_STAIRS G_PLAYER G_BOG_MONSTER G_CENTAUR G_DRAGON G_FLAMEDANCER G_GOLEM G_TENTACLE_HORROR G_IFRIT
G_JELLY G_KRAKEN G_LICH G_NAGA G_OGRE G_PHANTOM G_REVENANT G_SALAMANDER G_TROLL G_UNDERWORM
G_VAMPIRE G_WRAITH G_ZOMBIE G_ARMOR G_STAFF G_WEB G_MOUND G_BLOAT G_CENTIPEDE G_DAR_BLADEMASTER
G_EEL G_FURY G_GOBLIN G_IMP G_JACKAL G_KOBOLD G_MONKEY G_PIXIE G_RAT G_SPIDER
G_TOAD G_BAT G_WISP G_PHOENIX G_ALTAR G_LIQUID G_FLOOR G_CHASM G_TRAP G_FIRE
G_FOLIAGE G_AMULET G_SCROLL G_RING G_WEAPON G_TURRET G_TOTEM G_GOOD_MAGIC G_BAD_MAGIC G_DOORWAY
G_CHARM G_WALL_TOP G_DAR_PRIESTESS G_DAR_BATTLEMAGE G_GOBLIN_MAGIC G_GOBLIN_CHIEFTAN G_OGRE_MAGIC G_GUARDIAN G_WINGED_GUARDIAN G_EGG
G_WARDEN G_DEWAR G_ANCIENT_SPIRIT G_LEVER G_LEVER_PULLED G_BLOODWORT_STALK G_FLOOR_ALT G_UNICORN G_GEM G_WAND
G_GRANITE G_CARPET G_CLOSED_IRON_DOOR G_OPEN_IRON_DOOR G_TORCH G_CRYSTAL G_PORTCULLIS G_BARRICADE G_STATUE G_CRACKED_STATUE
G_CLOSED_CAGE G_OPEN_CAGE G_PEDESTAL G_CLOSED_COFFIN G_OPEN_COFFIN G_MAGIC_GLYPH G_BRIDGE G_BONES G_ELECTRIC_CRYSTAL G_ASHES
G_BEDROLL G_BLOODWORT_POD G_VINE G_NET G_LICHEN G_PIPES G_SAC_ALTAR G_ORB_ALTAR""".split()
assert len(NAMES) == 128, len(NAMES)
IDX = {n: i for i, n in enumerate(NAMES)}
FW, FH, COLS = 64, 112, 16
NORIM = {'G_DOWN_STAIRS', 'G_UP_STAIRS'}

def build(sheet=False):
    importlib.reload(sprites)
    items = []
    for name, (fix, tint) in sprites.SPR.items():
        if name not in IDX: sys.exit('unknown glyph ' + name)
        items.append({'i': IDX[name], 'name': name, 'fix': sprites.svg(fix), 'tint': sprites.svg(tint) if tint else None, 'norim': name in NORIM})
    page = """<html><body><script>
async function img(svg){var i=new Image();i.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);await i.decode();return i;}
var RIM='rgba(255,246,255,.82)';
async function run(items,sheet){
  var A=document.createElement('canvas');A.width=%d;A.height=%d;var a=A.getContext('2d');
  var T=document.createElement('canvas');T.width=A.width;T.height=A.height;var t=T.getContext('2d');
  // sticker rim: a light ring just outside the whole silhouette (fixed + tint), so dark critters stand out on dark floors
  var U=document.createElement('canvas');U.width=64;U.height=112;var u=U.getContext('2d');
  var R=document.createElement('canvas');R.width=64;R.height=112;var r=R.getContext('2d');
  for(const it of items){var x=(it.i%%%d)*%d,y=Math.floor(it.i/%d)*%d;
    var fi=await img(it.fix),ti=it.tint?await img(it.tint):null;
    u.clearRect(0,0,64,112);u.drawImage(fi,0,0);if(ti)u.drawImage(ti,0,0);
    if(!it.norim){r.clearRect(0,0,64,112);r.globalCompositeOperation='source-over';
      for(var k=0;k<16;k++){var an=k*Math.PI/8;r.drawImage(U,Math.cos(an)*2.6,Math.sin(an)*2.6);}
      r.globalCompositeOperation='source-in';r.fillStyle=RIM;r.fillRect(0,0,64,112);
      r.globalCompositeOperation='destination-out';r.drawImage(U,0,0);r.globalCompositeOperation='source-over';
      a.drawImage(R,x,y);}
    a.drawImage(fi,x,y);if(ti)t.drawImage(ti,x,y);}
  var out={fix:A.toDataURL('image/png'),tint:T.toDataURL('image/png')};
  if(sheet){ // contact sheet: each sprite, tinted in a sample colour, on a dark tile, 2x, labelled
    var n=items.length,cols=10,cw=150,chh=250,S=document.createElement('canvas');S.width=cols*cw;S.height=Math.ceil(n/cols)*chh;var s=S.getContext('2d');
    s.fillStyle='#1C1530';s.fillRect(0,0,S.width,S.height);
    var sc=document.createElement('canvas');sc.width=64;sc.height=112;var sx=sc.getContext('2d');
    var tints=['#FF7FB0','#7FD3FF','#9BE07A','#FFD45C','#C9A2FF'];
    items.forEach(function(it,k){var X=(k%%cols)*cw,Y=Math.floor(k/cols)*chh;
      s.fillStyle='#2A2142';s.fillRect(X+11,Y+6,128,224);
      if(it.tint){sx.globalCompositeOperation='copy';sx.drawImage(T,(it.i%%%d)*64,Math.floor(it.i/%d)*112,64,112,0,0,64,112);sx.globalCompositeOperation='source-in';sx.fillStyle=tints[k%%5];sx.fillRect(0,0,64,112);
        s.drawImage(sc,0,0,64,112,X+11,Y+6,128,224);}
      s.drawImage(A,(it.i%%%d)*64,Math.floor(it.i/%d)*112,64,112,X+11,Y+6,128,224);
      s.fillStyle='#fff';s.font='12px sans-serif';s.textAlign='center';s.fillText(it.name.slice(2),X+75,Y+244);});
    out.sheet=S.toDataURL('image/png');}
  return out;}
</script></body></html>""" % (COLS * FW, 8 * FH, COLS, FW, COLS, FH, COLS, COLS, COLS, COLS)
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page(); pg.set_content(page)
        out = pg.evaluate("([items,sheet])=>run(items,sheet)", [items, sheet]); b.close()
    for k in ('fix', 'tint', 'sheet'):
        if k in out:
            open(os.path.join(D, f'kid_{k}.png'), 'wb').write(base64.b64decode(out[k].split(',', 1)[1]))
    has = sorted(set(it['i'] for it in items)); tinted = sorted(set(it['i'] for it in items if it['tint']))
    TERRAIN = {'G_DOWN_STAIRS', 'G_UP_STAIRS', 'G_CLOSED_COFFIN', 'G_OPEN_COFFIN', 'G_ALTAR', 'G_BLOODWORT_STALK', 'G_BLOODWORT_POD'}
    big = sorted(set(it['i'] for it in items if it['name'] not in TERRAIN))
    json.dump({'has': has, 'tint': tinted, 'big': big, 'w': FW, 'h': FH}, open(os.path.join(D, 'kid_meta.json'), 'w'))
    print('sprites', len(items), 'tinted', len(tinted), {k: os.path.getsize(os.path.join(D, f'kid_{k}.png')) for k in ('fix', 'tint')})

if __name__ == '__main__':
    build('--sheet' in sys.argv)
