"""'Unicorn Dungeon' sprites for Brogue in the unicorn clock.

Every sprite is drawn in a 64x112 frame (Brogue's cells are tall, 4:7) and has two layers:
  fixed - full colour, drawn on top
  tint  - white shapes that the page fills with Brogue's own colour for that cell (so potion colours,
          monster variants and lighting still mean what they mean in Brogue), drawn underneath.
Glyphs not listed here keep Brogue's original tiles."""

O = '#3B2350'          # outline (the clock's plum ink)
SW = 2.4               # outline width

def S(attrs, **kw):
    return attrs
def path(d, fill, stroke=O, sw=SW, extra=''):
    return f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" stroke-linejoin="round" stroke-linecap="round" {extra}/>'
def circ(cx, cy, r, fill, stroke=O, sw=SW, extra=''):
    return f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" {extra}/>'
def ell(cx, cy, rx, ry, fill, stroke=O, sw=SW, extra=''):
    return f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" {extra}/>'
def rect(x, y, w, h, rx, fill, stroke=O, sw=SW, extra=''):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" {extra}/>'
NS = 'none'

def eyes(cx=32, cy=64, sp=7.5, r=3.4, closed=False):
    if closed:
        return path(f'M{cx-sp-3} {cy} q3 3 6 0 M{cx+sp-3} {cy} q3 3 6 0', NS, sw=2.2)
    out = ''
    for x in (cx - sp, cx + sp):
        out += ell(x, cy, r, r * 1.18, O, sw=0) + circ(x + 1.1, cy - 1.4, r * 0.38, '#fff', sw=0)
    return out
def blush(cx=32, cy=70, sp=12):
    return ell(cx - sp, cy, 3.6, 2.2, '#FF9EC4', sw=0, extra='opacity=".85"') + ell(cx + sp, cy, 3.6, 2.2, '#FF9EC4', sw=0, extra='opacity=".85"')
def smile(cx=32, cy=72, w=4):
    return path(f'M{cx-w} {cy} q{w} {w*0.9} {w*2} 0', NS, sw=2)
def wmouth(cx=32, cy=72):
    return path(f'M{cx-5} {cy} q2.5 3 5 0 q2.5 3 5 0', NS, sw=2)

def wizard_hat(cx=32, top=14, base=50, w=20):
    # tinted (Brogue's colour for the caster), outline drawn in the fixed layer
    t = path(f'M{cx-w} {base} L{cx+2} {top} L{cx+w} {base} Z', '#fff', stroke='#fff', sw=1)
    f = path(f'M{cx-w} {base} L{cx+2} {top} L{cx+w} {base} Z', NS) + circ(cx + 6, base - 14, 2.2, '#FFE36B', sw=0) + circ(cx - 5, base - 7, 1.6, '#FFE36B', sw=0)
    f += path(f'M{cx-w-3} {base} q{w+3} 6 {2*w+6} 0', NS)
    return f, t
def crown(cx=32, y=44):
    return path(f'M{cx-12} {y} l0 -11 l6 6 l6 -9 l6 9 l6 -6 l0 11 Z', '#FFD45C') + circ(cx, y - 5, 2, '#F58BB8', sw=0)
def tiara(cx=32, y=47):
    return path(f'M{cx-11} {y} q11 -10 22 0', '#FFD45C', sw=2) + circ(cx, y - 6, 2.4, '#9FD3F5', sw=1.4)
def headband(cx=32, y=52, col='#E8414E'):
    return path(f'M{cx-18} {y+2} q18 -8 36 0 l0 5 q-18 -8 -36 0 Z', col, sw=1.8) + path(f'M{cx+17} {y+3} l8 -4 M{cx+17} {y+5} l9 3', NS, stroke=col, sw=3)

def mammal(body, belly=None, ears='round', earin='#F9B4CF', muzzle=None, nose=O, tail=None, top='', over='', tint='', mouth='smile', eyecol=None, cheeks=True, feet=None, face=None):
    """chibi animal: big head, little body. returns (fixed, tint)"""
    belly = belly or body
    f = ''
    # tail behind
    if tail == 'thin':
        f += path('M46 98 q14 -2 12 -16 q-1 -6 -5 -4', NS, sw=3.2) + path('M46 98 q14 -2 12 -16 q-1 -6 -5 -4', NS, stroke=body, sw=1.4)
    elif tail == 'fluffy':
        f += path('M44 98 q18 4 16 -16 q-2 -9 -9 -5 q4 10 -9 13 Z', body) + path('M58 84 q-2 -6 -6 -3', '#fff', sw=0)
    elif tail == 'curly':
        f += path('M46 96 q12 2 12 -8 q0 -7 -6 -6 q-5 1 -3 6', NS, sw=3.2)
    elif tail == 'stripe':
        f += path('M44 98 q18 4 16 -16 q-2 -9 -9 -5 q4 10 -9 13 Z', body) + path('M53 80 l6 2 M54 88 l6 0', NS, sw=2.4)
    elif tail == 'puff':
        f += circ(48, 98, 6, '#fff')
    # body
    f += ell(32, 94, 16, 13, body) + ell(32, 97, 9, 8, belly, sw=0)
    feetc = feet or body
    f += ell(24, 106, 6, 4, feetc) + ell(40, 106, 6, 4, feetc)
    # ears
    if ears == 'round':
        f += circ(16, 50, 8, body) + circ(48, 50, 8, body) + circ(16, 50, 4.2, earin, sw=0) + circ(48, 50, 4.2, earin, sw=0)
    elif ears == 'biground':
        f += circ(14, 50, 11, body) + circ(50, 50, 11, body) + circ(14, 50, 6.5, earin, sw=0) + circ(50, 50, 6.5, earin, sw=0)
    elif ears == 'pointy':
        f += path('M14 58 L12 34 L28 47 Z', body) + path('M50 58 L52 34 L36 47 Z', body)
        f += path('M16 53 L15 40 L24 48 Z', earin, sw=0) + path('M48 53 L49 40 L40 48 Z', earin, sw=0)
    elif ears == 'long':
        f += ell(22, 34, 6, 17, body) + ell(42, 34, 6, 17, body) + ell(22, 35, 2.8, 12, earin, sw=0) + ell(42, 35, 2.8, 12, earin, sw=0)
    elif ears == 'floppy':
        f += path('M15 54 q-9 4 -7 18 q2 6 8 2 Z', body) + path('M49 54 q9 4 7 18 q-2 6 -8 2 Z', body)
    elif ears == 'side':
        f += circ(12, 66, 7, body) + circ(52, 66, 7, body) + circ(12, 66, 3.8, earin, sw=0) + circ(52, 66, 3.8, earin, sw=0)
    elif ears == 'small':
        f += circ(19, 50, 5, body) + circ(45, 50, 5, body)
    elif ears == 'cat':
        f += path('M15 57 L17 36 L30 48 Z', body) + path('M49 57 L47 36 L34 48 Z', body) + path('M18 52 L19 42 L26 48 Z', earin, sw=0) + path('M46 52 L45 42 L38 48 Z', earin, sw=0)
    f += top
    # head
    f += circ(32, 65, 19, body)
    if face:
        f += path('M32 76 q-14 2 -14 -10 q0 -10 7 -10 q5 0 7 4 q2 -4 7 -4 q7 0 7 10 q0 12 -14 10 Z', face, sw=1.6)
    if muzzle:
        f += ell(32, 72, 9, 6.5, muzzle, sw=1.6)
    f += eyes(32, 63)
    if eyecol:
        f += ell(24.5, 63, 3.4, 4, eyecol, sw=0) + ell(39.5, 63, 3.4, 4, eyecol, sw=0) + circ(25.6, 61.6, 1.3, '#fff', sw=0) + circ(40.6, 61.6, 1.3, '#fff', sw=0)
    f += ell(32, 69, 2.6, 1.9, nose, sw=0)
    if cheeks: f += blush(32, 71, 12)
    if mouth == 'smile': f += smile(32, 72.5, 3)
    elif mouth == 'w': f += wmouth(32, 72.5)
    f += over
    return f, tint

# ---------------------------------------------------------------- the player and unicorns
def unicorn(coat='#FFFFFF', mane=('#F58BB8', '#B9A4F2', '#9FD3F5'), horn='#FFD45C', rainbow=False):
    f = ''
    # tail
    f += path('M46 96 q16 0 14 -14 q-2 6 -8 4 q6 -6 2 -12 q-4 6 -10 6 Z', mane[0])
    f += ell(32, 94, 15, 12, coat) + ell(23, 106, 5, 4, coat) + ell(41, 106, 5, 4, coat)
    f += ell(23, 108, 5, 2.2, mane[1], sw=1.2) + ell(41, 108, 5, 2.2, mane[1], sw=1.2)
    # head + horn + ears
    f += path('M26 50 L32 22 L38 50 Z', horn) + path('M28.5 43 l7 -2 M29.5 36 l5 -1.5', NS, sw=1.6)
    f += path('M16 56 L17 40 L27 49 Z', coat) + path('M48 56 L47 40 L37 49 Z', coat)
    f += circ(32, 65, 19, coat)
    # mane down the side
    cols = ('#F58BB8', '#FFD45C', '#B6E388', '#9FD3F5', '#B9A4F2') if rainbow else mane
    f += path('M18 52 q-8 10 -4 24 q4 -6 8 -4 q-6 -10 2 -18 Z', cols[0])
    f += path('M22 47 q10 -6 18 0 q-6 2 -9 7 q-3 -5 -9 -7 Z', cols[1 % len(cols)])
    f += path('M14 64 q-5 8 0 16 q2 -6 6 -6 Z', cols[2 % len(cols)])
    f += eyes(32, 64) + blush(32, 71, 12) + smile(32, 73, 3)
    return f, ''

# ---------------------------------------------------------------- other critters
def fish(body='#9FD3F5', fin='#5FA8D3'):
    f = path('M12 86 L2 76 L2 98 Z', fin) + ell(34, 87, 22, 15, body) + path('M30 73 q6 -10 14 -2', fin)
    f += path('M22 88 q4 4 8 0', NS, sw=1.6) + eyes(42, 84, 0.01, 3.4)[: ] + blush(44, 92, 0.01)
    return f, ''
def blob(col_fixed=None, spikes=False, drip=True):
    # body tinted with Brogue's colour; face fixed
    shape = 'M10 104 q-4 -34 22 -44 q26 10 22 44 q-6 4 -11 0 q-5 4 -11 0 q-5 4 -11 0 q-6 4 -11 0 Z' if drip else 'M8 104 q0 -40 24 -42 q24 2 24 42 Z'
    t = path(shape, '#fff', stroke='#fff', sw=1)
    f = path(shape, NS) + path('M20 72 q4 -6 10 -7', NS, stroke='#fff', sw=3, extra='opacity=".7"')
    if spikes:
        for (x, y) in ((10, 82), (54, 82), (20, 64), (44, 64), (32, 59)):
            f += circ(x, y, 3, '#FFE6F0', sw=1.6)
    f += eyes(32, 84) + blush(32, 91, 12) + smile(32, 93, 3)
    return f, t
def puffer():
    t = circ(32, 82, 22, '#fff', stroke='#fff')
    f = circ(32, 82, 22, NS) + path('M10 82 l-6 -3 M54 82 l6 -3 M32 60 l0 -6 M17 66 l-4 -5 M47 66 l4 -5 M16 99 l-4 5 M48 99 l4 5', NS, sw=2.4)
    f += path('M40 104 q4 6 10 4', NS, sw=2) + eyes(32, 80) + blush(32, 88, 12) + path('M28 92 q4 3 8 0', NS, sw=2)
    return f, t
def ghost(col='#FFFFFF'):
    sh = 'M12 108 q0 -58 20 -60 q20 2 20 60 q-5 -6 -10 0 q-5 -6 -10 0 q-5 -6 -10 0 q-5 -6 -10 0 Z'
    return path(sh, col, extra='opacity=".92"') + eyes(32, 76) + blush(32, 84, 11) + ell(32, 87, 3, 3.6, O, sw=0), ''
def bat(body='#8A6FD1', wing='#5E4A9E', cape=False):
    f = path('M30 82 q-14 -16 -28 -8 q6 4 4 10 q6 -4 10 2 q4 -6 14 -4 Z', wing) + path('M34 82 q14 -16 28 -8 q-6 4 -4 10 q-6 -4 -10 2 q-4 -6 -14 -4 Z', wing)
    if cape: f += path('M18 84 q14 30 28 0 Z', '#E8414E')
    f += path('M20 70 L18 56 L27 64 Z', body) + path('M44 70 L46 56 L37 64 Z', body)
    f += circ(32, 78, 14, body) + eyes(32, 77, 6, 3) + blush(32, 83, 9) + path('M29 85 l1.5 3 l1.5 -3 M33 85 l1.5 3 l1.5 -3', '#fff', sw=1.2)
    return f, ''
def bird(body='#C9A27A', belly='#F2E2C4', crest=None, wings=None, owl=False, flame=False):
    f = ''
    if flame:
        f += path('M20 94 q-14 -10 -10 -30 q6 10 12 8 q-4 -12 4 -22 q2 12 8 14 q2 -10 8 -14 q4 12 0 22 q6 0 10 -8 q4 20 -10 30 Z', '#FFB347')
    if wings:
        f += path('M12 88 q-8 -14 4 -24 q6 12 6 24 Z', wings) + path('M52 88 q8 -14 -4 -24 q-6 12 -6 24 Z', wings)
    f += ell(32, 86, 18, 21, body) + ell(32, 92, 11, 13, belly, sw=0)
    if owl:
        f += path('M15 70 L14 56 L24 64 Z', body) + path('M49 70 L50 56 L40 64 Z', body)
        f += circ(25, 78, 7, '#fff', sw=1.6) + circ(39, 78, 7, '#fff', sw=1.6)
        f += eyes(32, 78, 7, 3.2)
    else:
        f += eyes(32, 78, 6.5, 3.2) + blush(32, 85, 11)
    if crest: f += path('M28 66 q-2 -10 6 -14 q-2 8 4 10 Z', crest)
    f += path('M29 84 L35 84 L32 90 Z', '#FFB347', sw=1.6)
    f += path('M26 106 l0 3 M38 106 l0 3', NS, stroke='#FFB347', sw=2.6)
    return f, ''
def frog(body='#7FD36B', belly='#D8F3C6'):
    f = ell(32, 92, 22, 15, body) + ell(32, 96, 13, 9, belly, sw=0)
    f += circ(20, 72, 9, body) + circ(44, 72, 9, body) + eyes(32, 72, 12, 3.6)
    f += path('M22 90 q10 8 20 0', NS, sw=2) + blush(32, 88, 15)
    f += ell(14, 106, 7, 3.5, body) + ell(50, 106, 7, 3.5, body)
    return f, ''
def ladybug():
    f = ''.join(path(f'M{x} {y} l{dx} {dy}', NS, sw=2.2) for (x, y, dx, dy) in ((14, 88, -7, -4), (14, 96, -8, 0), (16, 103, -7, 4), (50, 88, 7, -4), (50, 96, 8, 0), (48, 103, 7, 4)))
    f += ell(32, 94, 20, 15, '#E8414E') + path('M32 80 L32 108', NS, sw=1.8)
    for (x, y) in ((23, 92), (41, 92), (25, 102), (39, 102), (32, 86)):
        f += circ(x, y, 3, O, sw=0)
    f += circ(32, 74, 11, '#3B2350') + eyes(32, 73, 4.5, 2.8) + path('M27 64 q-4 -8 -8 -8 M37 64 q4 -8 8 -8', NS, sw=2) + circ(19, 56, 2, O, sw=0) + circ(45, 56, 2, O, sw=0)
    f = f.replace(eyes(32, 73, 4.5, 2.8), '') + circ(28, 73, 2.6, '#fff', sw=0) + circ(36, 73, 2.6, '#fff', sw=0) + circ(28.6, 73.4, 1.3, O, sw=0) + circ(36.6, 73.4, 1.3, O, sw=0)
    return f, ''
def caterpillar(col='#9BE07A', head='#7FD36B'):
    f = ''
    for i, x in enumerate((50, 40, 30)):
        f += circ(x, 96 - (i % 2) * 4, 9, col)
    f += circ(20, 86, 13, head) + path('M15 74 q-2 -8 -6 -9 M25 74 q2 -8 6 -9', NS, sw=2) + circ(9, 65, 2.4, '#F58BB8', sw=0) + circ(31, 65, 2.4, '#F58BB8', sw=0)
    f += eyes(20, 85, 5, 2.8) + blush(20, 91, 8) + smile(20, 92, 2)
    return f, ''
def snake(col='#5FC7B8', belly='#CFF5EC'):
    f = path('M8 104 q0 -14 16 -12 q20 2 22 -10 q2 -10 -8 -10', NS, sw=13) + path('M8 104 q0 -14 16 -12 q20 2 22 -10 q2 -10 -8 -10', NS, stroke=col, sw=9)
    f += circ(36, 66, 13, col) + eyes(36, 65, 5.5, 3) + blush(36, 71, 9) + path('M36 77 l0 5 l-3 3 M36 82 l3 3', NS, stroke='#E8414E', sw=1.6)
    return f, ''
def octopus(col_fixed=None):
    sh = 'M14 92 q-2 -36 18 -38 q20 2 18 38 Z'
    t = path(sh, '#fff', stroke='#fff') + ''.join(path(f'M{x} 90 q{d} 10 {d*0.3} 18', NS, stroke='#fff', sw=6) for x, d in ((16, -6), (24, -3), (32, 0.01), (40, 3), (48, 6)))
    f = path(sh, NS) + ''.join(path(f'M{x} 90 q{d} 10 {d*0.3} 18', NS, sw=1.6) for x, d in ((16, -6), (24, -3), (32, 0.01), (40, 3), (48, 6)))
    f += eyes(32, 76) + blush(32, 83, 12) + smile(32, 84, 3)
    return f, t
def dragon(col='#B9A4F2', belly='#F2E8FF', wing='#F58BB8'):
    f = path('M14 84 q-12 -18 -8 -32 q8 8 14 6 q-2 12 4 18 Z', wing) + path('M50 84 q12 -18 8 -32 q-8 8 -14 6 q2 12 -4 18 Z', wing)
    f += path('M46 100 q16 4 14 -10 l-6 4', NS, sw=3) + ell(32, 94, 15, 13, col) + ell(32, 97, 8, 8, belly, sw=0)
    f += path('M22 52 L20 42 L28 48 Z', '#FFD45C', sw=1.8) + path('M42 52 L44 42 L36 48 Z', '#FFD45C', sw=1.8)
    f += circ(32, 66, 18, col) + ell(32, 73, 9, 6, belly, sw=1.4) + eyes(32, 63) + blush(32, 70, 12) + circ(29, 72, 1.1, O, sw=0) + circ(35, 72, 1.1, O, sw=0)
    f += ell(24, 106, 5.5, 4, col) + ell(40, 106, 5.5, 4, col)
    return f, ''
def lizard(col='#FF9F45', belly='#FFE0B8', flame=True):
    f = ''
    if flame: f += path('M48 100 q12 -4 10 -18 q-4 6 -8 4 q2 -8 -4 -12 q0 10 -6 14 Z', '#FFD45C')
    f += path('M44 100 q14 2 12 -10', NS, sw=6) + path('M44 100 q14 2 12 -10', NS, stroke=col, sw=3)
    f += ell(32, 96, 17, 10, col) + ell(32, 99, 9, 5, belly, sw=0) + ell(20, 106, 5, 3, col) + ell(44, 106, 5, 3, col)
    f += ell(30, 76, 16, 13, col) + eyes(30, 74, 6.5, 3.2) + blush(30, 80, 10) + smile(30, 81, 3)
    return f, ''
def worm(col='#FF9EC4'):
    f = path('M6 104 q10 -26 26 -8 q14 14 22 -16', NS, sw=16) + path('M6 104 q10 -26 26 -8 q14 14 22 -16', NS, stroke=col, sw=12)
    f += circ(52, 76, 11, col) + eyes(52, 75, 4.5, 2.6) + blush(52, 80, 7)
    return f, ''
def pony(coat='#C98A5A', mane='#6E4A33'):
    f = path('M46 96 q16 0 14 -14 q-6 6 -10 2 Z', mane)
    f += ell(32, 94, 15, 12, coat) + ell(23, 106, 5, 4, coat) + ell(41, 106, 5, 4, coat)
    f += path('M16 56 L17 40 L27 49 Z', coat) + path('M48 56 L47 40 L37 49 Z', coat)
    f += circ(32, 65, 19, coat) + ell(32, 73, 10, 7, '#F2D2B0', sw=1.4)
    f += path('M22 47 q10 -6 18 0 q-6 2 -9 7 q-3 -5 -9 -7 Z', mane) + path('M18 52 q-8 10 -4 24 q4 -6 8 -4 q-6 -10 2 -18 Z', mane)
    f += eyes(32, 63) + blush(32, 70, 12) + circ(29, 73, 1, O, sw=0) + circ(35, 73, 1, O, sw=0)
    return f, ''
def genie():
    t = path('M14 104 q8 -6 18 -2 q-16 -8 -4 -20 q-14 -14 4 -26 q18 -6 22 10 q8 16 -6 22 q14 12 -8 16', '#fff', stroke='#fff', sw=2)
    f = path('M14 104 q8 -6 18 -2 q-16 -8 -4 -20 q-14 -14 4 -26 q18 -6 22 10 q8 16 -6 22 q14 12 -8 16', NS)
    f += eyes(34, 70, 6, 3) + blush(34, 76, 10) + smile(34, 78, 3) + path('M26 54 q8 -10 16 0', '#FFD45C', sw=1.8) + circ(34, 48, 2.4, '#E8414E', sw=1.2)
    return f, t
def firefly(col_fixed=None):
    t = circ(32, 84, 15, '#fff', stroke='#fff')
    f = circ(32, 84, 15, NS, extra='') + path('M22 76 q-14 -18 -16 -4 q4 8 14 6 M42 76 q14 -18 16 -4 q-4 8 -14 6', '#E9F7FF', sw=1.8, extra='opacity=".9"')
    f += eyes(32, 84, 5, 2.6) + blush(32, 89, 8) + path('M28 70 q-3 -8 -6 -8 M36 70 q3 -8 6 -8', NS, sw=1.6)
    return f, t
def fairy():
    f = path('M30 82 q-20 -22 -24 -4 q-2 12 22 8 Z', '#B9E6FF', sw=1.8, extra='opacity=".9"') + path('M34 82 q20 -22 24 -4 q2 12 -22 8 Z', '#B9E6FF', sw=1.8, extra='opacity=".9"')
    f += path('M26 108 L32 84 L38 108 Z', '#F58BB8') + circ(32, 72, 12, '#FFE0CC') + path('M20 70 q2 -14 12 -14 q10 0 12 14 q-6 -6 -12 -5 q-6 -1 -12 5 Z', '#FFD45C', sw=1.8)
    f += eyes(32, 73, 5, 2.6) + blush(32, 78, 8) + smile(32, 79, 2)
    t = circ(46, 60, 3.5, '#fff', stroke='#fff')   # a little glowing wand star in Brogue's pixie colour
    f += path('M38 74 L46 60', NS, sw=1.6)
    return f, t
def golem(col='#B8B2C8', teddy=True):
    f = circ(16, 52, 7, col) + circ(48, 52, 7, col) + ell(32, 94, 18, 14, col) + circ(32, 66, 19, col)
    f += ell(32, 73, 9, 6, '#E9E4F2', sw=1.4) + eyes(32, 63) + circ(32, 70, 2, O, sw=0) + smile(32, 74, 3)
    f += path('M22 86 l4 4 l-4 4 M42 86 l-4 4 l4 4', NS, sw=1.6) + ell(23, 106, 6, 4, col) + ell(41, 106, 6, 4, col) + blush(32, 71, 12)
    return f, ''
def turtle(shell='#5FB36E', skin='#B6E388'):
    f = ell(16, 100, 6, 4, skin) + ell(48, 100, 6, 4, skin) + circ(54, 78, 11, skin) + eyes(54, 77, 4, 2.6) + blush(56, 82, 6)
    f += path('M8 100 q2 -34 26 -34 q22 0 24 34 Z', shell) + path('M18 98 l6 -16 l12 0 l6 16 M24 82 l-6 -6 M36 82 l6 -6', NS, sw=1.8)
    f = f.replace(circ(54, 78, 11, skin) + eyes(54, 77, 4, 2.6) + blush(56, 82, 6), '') + circ(54, 78, 11, skin) + eyes(54, 77, 4, 2.6) + blush(56, 82, 6)
    return f, ''
def statue(kind='lion'):
    stone, dark = '#C9C4D6', '#9C95AE'
    f = rect(12, 96, 40, 12, 3, dark)
    if kind == 'lion':
        f += circ(32, 70, 22, '#B3ACC4') + circ(32, 72, 15, stone) + eyes(32, 70, 6, 2.6, closed=True) + ell(32, 76, 3, 2, O, sw=0) + ell(32, 92, 13, 8, stone)
    elif kind == 'angel':
        f += path('M18 80 q-14 -20 -6 -34 q8 12 16 14 Z', stone) + path('M46 80 q14 -20 6 -34 q-8 12 -16 14 Z', stone) + ell(32, 90, 12, 10, stone) + circ(32, 70, 13, stone) + eyes(32, 69, 5, 2.4, closed=True) + ell(32, 54, 9, 2.6, NS, stroke='#FFD45C', sw=2)
    elif kind == 'bear':
        f += circ(17, 56, 7, stone) + circ(47, 56, 7, stone) + ell(32, 90, 17, 11, stone) + circ(32, 68, 17, stone) + eyes(32, 66, 6, 2.6, closed=True) + ell(32, 74, 7, 5, '#E4E0EE', sw=1.4)
    elif kind == 'plain':
        f += rect(20, 56, 24, 40, 8, stone) + circ(32, 52, 10, stone)
    return f, ''
def totem():
    f = rect(18, 44, 28, 64, 5, '#C98A5A')
    for y in (60, 84):
        f += eyes(32, y, 6, 2.6) + smile(32, y + 7, 3) + path(f'M18 {y+14} l28 0', NS, sw=1.6)
    f += ell(24, 40, 4, 10, '#C98A5A') + ell(40, 40, 4, 10, '#C98A5A')
    return f, ''
def turret():
    f = path('M32 108 L32 82', NS, stroke='#5FB36E', sw=5) + path('M32 96 q-12 -2 -14 -10 q10 0 14 6', '#7FD36B', sw=1.8)
    for i in range(10):
        import math
        a = i * math.pi / 5
        f += ell(32 + 14 * math.cos(a), 70 + 14 * math.sin(a), 6, 4, '#FFD45C', sw=1.6, extra=f'transform="rotate({a*180/math.pi} {32 + 14 * math.cos(a)} {70 + 14 * math.sin(a)})"')
    f += circ(32, 70, 10, '#B07A4A') + eyes(32, 69, 4, 2.4) + smile(32, 74, 2)
    return f, ''
def egg():
    f = path('M32 60 q18 0 18 30 q0 18 -18 18 q-18 0 -18 -18 q0 -30 18 -30 Z', '#FFF6E0')
    for (x, y, r) in ((26, 78, 3.5), (38, 88, 4), (28, 98, 3), (40, 72, 2.5)):
        f += circ(x, y, r, '#B9A4F2', sw=0)
    return f, ''
def flower_plant(pod=False):
    if pod:
        return circ(32, 92, 9, '#F58BB8') + path('M29 85 q3 -3 6 0', '#7FD36B', sw=1.4) + circ(29, 89, 2, '#fff', sw=0), ''
    f = path('M32 108 L32 70', NS, stroke='#5FB36E', sw=4) + path('M32 92 q-14 -2 -16 -12 q12 0 16 8 M32 86 q14 -2 16 -12 q-12 0 -16 8', '#7FD36B', sw=1.6)
    for (x, y) in ((32, 56), (24, 64), (40, 64), (27, 74), (37, 74)):
        f += circ(x, y, 6, '#F58BB8', sw=1.6)
    f += circ(32, 66, 5, '#FFD45C', sw=1.6)
    return f, ''

# ---------------------------------------------------------------- items
def potion():
    liquid = 'M18 84 q0 -10 14 -10 q14 0 14 10 q0 20 -14 20 q-14 0 -14 -20 Z'
    t = path(liquid, '#fff', stroke='#fff', sw=1)
    f = path('M26 58 L38 58 L38 68 q14 6 14 18 q0 24 -20 24 q-20 0 -20 -24 q0 -12 14 -18 Z', NS) + rect(24, 52, 16, 8, 3, '#C98A5A')
    f += path('M27 92 q-3 -6 2 -9 q3 -2 3 2 q0 -4 3 -2 q5 3 2 9 l-5 5 Z', '#fff', sw=0, extra='opacity=".85"') + path('M18 78 q2 -5 6 -6', NS, stroke='#fff', sw=2.4, extra='opacity=".8"')
    return f, t
def scroll():
    f = rect(14, 62, 36, 40, 4, '#FFF1D6') + ell(14, 82, 4, 20, '#F2D9A8') + ell(50, 82, 4, 20, '#F2D9A8')
    f += path('M22 74 l20 0 M22 82 l16 0 M22 90 l20 0', NS, stroke='#C9A27A', sw=1.8)
    f += path('M28 100 q4 6 0 10 M36 100 q-4 6 0 10', NS, stroke='#F58BB8', sw=3) + circ(32, 100, 3.6, '#F58BB8', sw=1.6)
    return f, ''
def cupcake():
    f = path('M16 84 L22 108 L42 108 L48 84 Z', '#9FD3F5') + path('M22 86 l3 20 M30 86 l1 20 M38 86 l-1 20 M44 86 l-3 20', NS, stroke='#6FB3E0', sw=1.4)
    f += path('M12 86 q-2 -14 12 -14 q2 -12 16 -10 q14 0 12 12 q10 2 6 12 Z', '#FFB6D5') + circ(32, 58, 5, '#E8414E', sw=1.8) + path('M32 53 q2 -5 6 -6', NS, stroke='#5FB36E', sw=1.8)
    for (x, y, c) in ((22, 78, '#FFD45C'), (30, 72, '#9FD3F5'), (40, 76, '#B6E388'), (46, 82, '#FFD45C')):
        f += rect(x, y, 4, 2, 1, c, sw=0)
    return f, ''
def starcoin():
    import math
    pts = ' '.join(f'{32+15*math.cos(math.radians(-90+i*36))*(1 if i%2==0 else .5):.1f},{86+15*math.sin(math.radians(-90+i*36))*(1 if i%2==0 else .5):.1f}' for i in range(10))
    f = circ(32, 86, 20, '#FFD45C') + circ(32, 86, 15.5, NS, stroke='#E0A82E', sw=1.6) + f'<polygon points="{pts}" fill="#FFF1A8" stroke="{O}" stroke-width="1.8" stroke-linejoin="round"/>'
    f += path('M18 76 q4 -8 12 -10', NS, stroke='#fff', sw=2.4, extra='opacity=".8"')
    return f, ''
def sword():
    f = path('M30 100 L30 52 L34 44 L38 52 L38 100 Z', '#E9F2FF') + path('M34 50 L34 96', NS, stroke='#B9D3F0', sw=1.6)
    f += rect(22, 98, 24, 6, 3, '#B9A4F2') + rect(31, 104, 6, 6, 2, '#F58BB8') + circ(34, 111, 0.01, NS, sw=0)
    t = circ(34, 101, 3, '#fff', stroke='#fff')   # gem in the hilt: Brogue's weapon colour
    f += circ(34, 101, 3, NS, sw=1.4) + path('M44 58 l2 -6 l2 6 l6 2 l-6 2 l-2 6 l-2 -6 l-6 -2 Z', '#FFE36B', sw=1.2)
    return f, t
def armor():
    f = path('M16 66 L26 60 Q32 66 38 60 L48 66 L46 78 L42 76 L42 104 Q32 108 22 104 L22 76 L18 78 Z', '#F9D5EC')
    f += path('M22 86 Q32 92 42 86', NS, stroke='#F58BB8', sw=2) + path('M32 66 l0 34', NS, stroke='#E6A8CB', sw=1.6)
    t = path('M27 70 l5 8 l5 -8 Z', '#fff', stroke='#fff', sw=1)
    f += path('M27 70 l5 8 l5 -8 Z', NS, sw=1.4)
    return f, t
def staff():
    f = path('M30 108 L36 58', NS, sw=6) + path('M30 108 L36 58', NS, stroke='#C98A5A', sw=3.4)
    t = circ(37, 52, 8, '#fff', stroke='#fff')
    f += circ(37, 52, 8, NS) + path('M33 48 q3 -3 6 -2', NS, stroke='#fff', sw=2) + path('M30 64 q-6 -4 -6 -10 M42 62 q6 -4 6 -10', NS, stroke='#B6E388', sw=2)
    return f, t
def wand():
    f = path('M24 106 L38 66', NS, sw=6) + path('M24 106 L38 66', NS, stroke='#FFF1D6', sw=3.4)
    import math
    pts = ' '.join(f'{40+11*math.cos(math.radians(-90+i*36))*(1 if i%2==0 else .45):.1f},{60+11*math.sin(math.radians(-90+i*36))*(1 if i%2==0 else .45):.1f}' for i in range(10))
    t = f'<polygon points="{pts}" fill="#fff" stroke="#fff" stroke-width="1"/>'
    f += f'<polygon points="{pts}" fill="none" stroke="{O}" stroke-width="1.8" stroke-linejoin="round"/>' + path('M18 70 l2 -4 l2 4 l4 2 l-4 2 l-2 4 l-2 -4 l-4 -2 Z', '#FFE36B', sw=1)
    return f, t
def ring():
    f = circ(32, 94, 12, NS, sw=6.5) + circ(32, 94, 12, NS, stroke='#FFD45C', sw=3.6)
    t = path('M24 78 L28 70 L36 70 L40 78 L32 86 Z', '#fff', stroke='#fff', sw=1)
    f += path('M24 78 L28 70 L36 70 L40 78 L32 86 Z', NS, sw=1.8) + path('M28 75 l3 -3', NS, stroke='#fff', sw=1.6)
    return f, t
def charm():
    f = path('M20 66 q12 -10 24 0', NS, stroke='#C9C4D6', sw=2.4) + path('M32 70 L32 74', NS, sw=1.6)
    t = path('M32 106 q-20 -14 -16 -26 q4 -8 12 -4 l4 4 l4 -4 q8 -4 12 4 q4 12 -16 26 Z', '#fff', stroke='#fff', sw=1)
    f += path('M32 106 q-20 -14 -16 -26 q4 -8 12 -4 l4 4 l4 -4 q8 -4 12 4 q4 12 -16 26 Z', NS) + path('M22 84 q2 -4 6 -4', NS, stroke='#fff', sw=2)
    return f, t
def amulet():
    f = path('M14 60 q18 30 36 0', NS, stroke='#FFD45C', sw=3)
    f += circ(32, 92, 14, '#FFD45C') + circ(32, 92, 9, '#F58BB8', sw=1.6) + path('M27 88 q3 -3 7 -2', NS, stroke='#fff', sw=2)
    for (x, c) in ((18, '#9FD3F5'), (24, '#B6E388'), (40, '#B9A4F2'), (46, '#FFB347')):
        f += circ(x, 72 + abs(32 - x) * -0.3 + 4, 3, c, sw=1.2)
    return f, ''
def gem():
    t = path('M16 84 L24 72 L40 72 L48 84 L32 104 Z', '#fff', stroke='#fff', sw=1)
    f = path('M16 84 L24 72 L40 72 L48 84 L32 104 Z', NS) + path('M16 84 L48 84 M24 72 L32 84 L40 72 M32 84 L32 104', NS, sw=1.4) + path('M22 80 l4 -5', NS, stroke='#fff', sw=2)
    return f, t
def key():
    f = circ(22, 84, 9, NS, sw=6) + circ(22, 84, 9, NS, stroke='#FFD45C', sw=3.4) + path('M31 84 L52 84 M46 84 l0 7 M51 84 l0 6', NS, sw=6) + path('M31 84 L52 84 M46 84 l0 7 M51 84 l0 6', NS, stroke='#FFD45C', sw=3.4)
    f += path('M18 78 q2 -2 5 -2', NS, stroke='#fff', sw=1.6)
    return f, ''
def dewar():
    t = rect(20, 72, 24, 30, 8, '#fff', stroke='#fff')
    f = rect(20, 64, 24, 40, 10, NS) + rect(24, 56, 16, 10, 3, '#C9C4D6') + path('M24 76 q2 -4 6 -4', NS, stroke='#fff', sw=2)
    return f, t

# ---------------------------------------------------------------- terrain that should stand out
def stairs(down=True):
    cols = ['#F58BB8', '#FFC46B', '#FFE36B', '#B6E388', '#9FD3F5', '#B9A4F2']
    f = rect(4, 40, 56, 68, 8, '#2A2440')
    for i, c in enumerate(cols):
        y = 48 + i * 10
        x0 = 8 + (i * 4 if down else (5 - i) * 4)
        f += rect(x0, y, 48 - (i * 4 if down else (5 - i) * 4) - 4 + 4, 9, 3, c, sw=1.6)
    if down:
        f += path('M32 20 L32 36 M25 30 L32 37 L39 30', NS, stroke='#FFE36B', sw=4)
    else:
        f += path('M32 37 L32 21 M25 27 L32 20 L39 27', NS, stroke='#FFE36B', sw=4)
    return f, ''
def chest(open_=False):
    f = rect(10, 80, 44, 28, 5, '#C98A5A') + path('M10 92 L54 92', NS, sw=1.8) + rect(28, 88, 8, 10, 2, '#FFD45C', sw=1.6)
    if open_:
        f += path('M10 80 L14 62 L50 62 L54 80 Z', '#B07A4A') + ell(32, 80, 18, 4, '#FFE36B', sw=1.4) + circ(24, 77, 3, '#F58BB8', sw=1) + circ(38, 76, 3, '#9FD3F5', sw=1)
    else:
        f += path('M10 80 q0 -18 22 -18 q22 0 22 18 Z', '#D9965F') + path('M22 64 L22 80 M42 64 L42 80', NS, stroke='#FFD45C', sw=3)
    return f, ''
def altar():
    f = rect(12, 86, 40, 22, 4, '#E9E4F2') + rect(8, 80, 48, 8, 3, '#F9D5EC') + path('M20 96 l24 0', NS, stroke='#C9C4D6', sw=1.6)
    t = path('M32 56 l4 10 l10 1 l-8 6 l3 10 l-9 -6 l-9 6 l3 -10 l-8 -6 l10 -1 Z', '#fff', stroke='#fff', sw=1)
    f += path('M32 56 l4 10 l10 1 l-8 6 l3 10 l-9 -6 l-9 6 l3 -10 l-8 -6 l10 -1 Z', NS, sw=1.6)
    return f, t

SPR = {
    # you, and unicorns
    'G_PLAYER': unicorn(),
    'G_UNICORN': unicorn(coat='#FFF6FB', rainbow=True),
    # monsters -> animals
    'G_RAT': mammal('#C9C4D6', '#F2EEF8', ears='biground', earin='#FFB6D5', tail='thin', muzzle='#F2EEF8', nose='#F58BB8'),
    'G_KOBOLD': mammal('#E2C08F', '#FFF1D6', ears='floppy', muzzle='#FFF1D6', tail='curly'),
    'G_JACKAL': mammal('#FF9F45', '#FFF1D6', ears='pointy', earin='#FFF1D6', muzzle='#FFF1D6', tail='fluffy'),
    'G_MONKEY': mammal('#B5733F', '#F2D2B0', ears='side', earin='#F2D2B0', face='#F2D2B0', tail='curly', top=path('M28 47 q4 -8 10 -6 q-6 2 -6 7', '#B5733F', sw=1.8)),
    'G_GOBLIN': mammal('#A8A2B8', '#E9E4F2', ears='pointy', earin='#4A4060', muzzle='#E9E4F2', tail='stripe',
                       over=path('M17 62 q15 -9 30 0 q-2 8 -8 6 q-7 -5 -14 0 q-6 2 -8 -6 Z', '#4A4060', sw=0) + eyes(32, 63)),
    'G_OGRE': mammal('#B07A4A', '#E2C08F', ears='round', earin='#E2C08F', muzzle='#E2C08F'),
    'G_ZOMBIE': mammal('#FFFFFF', '#FFFFFF', ears='round', earin='#3B2350',
                       over=ell(24.5, 63, 6.5, 7.5, '#3B2350', sw=0) + ell(39.5, 63, 6.5, 7.5, '#3B2350', sw=0) + circ(25.6, 62, 1.6, '#fff', sw=0) + circ(40.6, 62, 1.6, '#fff', sw=0), feet='#3B2350'),
    'G_TROLL': mammal('#5E6680', '#AEB5CC', ears='side', earin='#AEB5CC', face='#AEB5CC', mouth='w', top=path('M22 50 q10 -10 20 0 q-10 -4 -20 0 Z', '#5E6680', sw=1.8)),
    'G_IMP': mammal('#FF8A80', '#FFE0DC', ears='cat', earin='#FFE0DC', tail='thin',
                    top=path('M24 49 l-3 -9 l7 5 Z M40 49 l3 -9 l-7 5 Z', '#FFE36B', sw=1.6)),
    'G_DEMON': mammal('#FFC46B', '#FFF1D6', ears='round', earin='#FFF1D6', muzzle='#FFF1D6', tail='thin',
                      top=circ(32, 62, 26, '#E0882E')),
    'G_DAR_BLADEMASTER': mammal('#8C82A8', '#D9D3EA', ears='cat', earin='#D9D3EA', tail='thin', over=headband(32, 50, '#E8414E')),
    'G_DAR_PRIESTESS': mammal('#8C82A8', '#D9D3EA', ears='cat', earin='#D9D3EA', tail='thin', over=tiara(32, 48)),
    'G_FURY': bird('#B07A4A', '#F2D2B0', owl=True, wings='#8A5A36'),
    'G_LICH': bird('#8A6FD1', '#D9CCF5', owl=True),
    'G_PHOENIX': bird('#FF7A45', '#FFE0B8', crest='#FFD45C', wings='#FFB347', flame=True),
    'G_EEL': fish('#7FC8E8', '#3F8DC9'),
    'G_BLOAT': puffer(),
    'G_JELLY': blob(),
    'G_MOUND': blob(drip=False),
    'G_ANCIENT_SPIRIT': ghost('#D9F2FF'),
    'G_PHANTOM': ghost('#FFFFFF'),
    'G_WRAITH': ghost('#C9B8F2'),
    'G_REVENANT': mammal('#FFFFFF', '#FFFFFF', ears='long', earin='#FFB6D5', tail='puff',
                         over=path('M14 60 q18 -26 36 0 l0 6 q-18 -10 -36 0 Z', '#C9C4D6', sw=2) + path('M30 34 q2 -6 8 -4 q-4 2 -4 8', '#F58BB8', sw=1.4)),
    'G_VAMPIRE': bat('#6E5A9E', '#3F3266', cape=True),
    'G_BAT': bat(),
    'G_SPIDER': ladybug(),
    'G_CENTIPEDE': caterpillar(),
    'G_UNDERWORM': worm(),
    'G_TOAD': frog(),
    'G_NAGA': snake(),
    'G_SALAMANDER': lizard(),
    'G_DRAGON': dragon(),
    'G_KRAKEN': octopus(),
    'G_TENTACLE_HORROR': octopus(),
    'G_BOG_MONSTER': turtle(),
    'G_CENTAUR': pony(),
    'G_GOLEM': golem(),
    'G_IFRIT': genie(),
    'G_FLAMEDANCER': mammal('#FF6B4A', '#FFE0B8', ears='pointy', earin='#FFD45C', muzzle='#FFE0B8', tail='fluffy',
                            top=path('M24 50 q-4 -14 6 -20 q-1 8 4 10 q2 -8 8 -10 q4 10 -2 20 Z', '#FFD45C')),
    'G_WISP': firefly(),
    'G_PIXIE': fairy(),
    'G_TURRET': turret(),
    'G_TOTEM': totem(),
    'G_GUARDIAN': statue('lion'),
    'G_WINGED_GUARDIAN': statue('angel'),
    'G_WARDEN': statue('bear'),
    'G_EGG': egg(),
    'G_BLOODWORT_STALK': flower_plant(),
    'G_BLOODWORT_POD': flower_plant(pod=True),
    # items
    'G_POTION': potion(), 'G_SCROLL': scroll(), 'G_FOOD': cupcake(), 'G_GOLD': starcoin(), 'G_WEAPON': sword(),
    'G_ARMOR': armor(), 'G_STAFF': staff(), 'G_WAND': wand(), 'G_RING': ring(), 'G_CHARM': charm(),
    'G_AMULET': amulet(), 'G_GEM': gem(), 'G_KEY': key(), 'G_DEWAR': dewar(),
    # terrain that should stand out
    'G_DOWN_STAIRS': stairs(True), 'G_UP_STAIRS': stairs(False),
    'G_CLOSED_COFFIN': chest(False), 'G_OPEN_COFFIN': chest(True), 'G_ALTAR': altar(),
}

def wizard(base_name, args, kw, hat_w=20):
    f, t = mammal(*args, **kw)
    hf, ht = wizard_hat(32, 18, 50, hat_w)
    return f + hf, t + ht
SPR['G_GOBLIN_MAGIC'] = wizard('raccoon', ('#A8A2B8', '#E9E4F2'), dict(ears='small', muzzle='#E9E4F2', tail='stripe',
                               over=path('M17 62 q15 -9 30 0 q-2 8 -8 6 q-7 -5 -14 0 q-6 2 -8 -6 Z', '#4A4060', sw=0) + eyes(32, 63)))
SPR['G_GOBLIN_CHIEFTAN'] = mammal('#A8A2B8', '#E9E4F2', ears='small', muzzle='#E9E4F2', tail='stripe',
                                  over=path('M17 62 q15 -9 30 0 q-2 8 -8 6 q-7 -5 -14 0 q-6 2 -8 -6 Z', '#4A4060', sw=0) + eyes(32, 63) + crown(32, 48))
SPR['G_OGRE_MAGIC'] = wizard('bear', ('#B07A4A', '#E2C08F'), dict(ears='small', muzzle='#E2C08F'))
SPR['G_DAR_BATTLEMAGE'] = wizard('cat', ('#8C82A8', '#D9D3EA'), dict(ears='small', tail='thin'))

def svg(inner):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="64" height="112" viewBox="0 0 64 112">{inner}</svg>'
