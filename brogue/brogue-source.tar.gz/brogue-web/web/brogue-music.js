/* Dungeon music for the kid look (unicorn clock): chiptune in the NES style - a pulse-wave lead with vibrato,
   fast chord arpeggios, an octave-bouncing triangle bass and noise drums. A title tune and six floor themes that
   change with depth, plus a "new floor!" jingle, all made on the device with Web Audio (no files).
   window.BrogueMusic.create(opts) */
(function(){
var NOTE={C:0,D:2,E:4,F:5,G:7,A:9,B:11};
function midi(n){var m=/^([A-G])(#|b)?(\d)$/.exec(n);if(!m)return null;return NOTE[m[1]]+(m[2]==='#'?1:m[2]==='b'?-1:0)+12*(+m[3]+1);}
function mhz(m){return 440*Math.pow(2,(m-69)/12);}
function hz(n){var m=midi(n);return m===null?0:mhz(m);}
// chord symbol -> semitones above the root
var QUAL={'':[0,4,7],m:[0,3,7],'7':[0,4,7,10],maj7:[0,4,7,11],m7:[0,3,7,10],sus4:[0,5,7],dim:[0,3,6],aug:[0,4,8]};
function chord(sym){var m=/^([A-G])(#|b)?(maj7|m7|sus4|dim|aug|m|7)?$/.exec(sym);if(!m)return null;
  return {root:NOTE[m[1]]+(m[2]==='#'?1:m[2]==='b'?-1:0),iv:QUAL[m[3]||'']};}
function toks(str){return str?str.replace(/\|/g,' ').trim().split(/\s+/):[];}

/* Each tune: lead in 8th-note steps ('.' rest, '-' hold, 'A5,B5' two 16ths), chords one per half bar ('-' = same),
   bass style (oct: root/octave bounce, walk: root-fifth-octave-fifth, pump: root-root-octave-root), drums one bar of
   16ths (k kick, s snare, h hat, o open hat) with a fill every 4th bar, duty = lead pulse width. */
var T={
  title:{name:'Unicorn Dungeon',bpm:150,duty:0.25,bass:'oct',
    lead:'C5 . E5 . G5 . C6 . | B5 - A5 . G5 . D5 . | E5 . A5 . C6 - B5 A5 | A5 - G5 F5 G5 - D5 . | C5 . E5 . G5 . C6 . | A5 - G5 F5 E5 - C5 . | D5 . F5 A5 G5 . B5 D6 | C6 - - . C5,E5 G5,C6 . .',
    chords:'C C | G G | Am Am | F G | C C | F F | Dm G | C C',
    drum:'k.h.s.h.k.h.s.h.',fill:'k.h.s.h.s.ssk.ss'},
  sunny:{name:'Sunny Caves',bpm:164,duty:0.25,bass:'oct',
    lead:'G5 . D5 . G5 . A5 B5 | C6 . B5 A5 A5 . F#5 . | G5 . D5 . G5 . B5 D6 | E6 - D6 B5 A5 . F#5 . | E5 . G5 . C6 . E6 . | D6 - B5 G5 G5 . E5 . | A5 . C6 . F#5 . A5 . | G5 - - . D5,E5 F#5,G5 . . | E5 E5 G5 . C6 . G5 . | D6 D6 B5 . G5 . D5 . | C6 . B5 A5 E5 . A5 . | F#5 . A5 . D6 . C6 . | B5 . A5 G5 A5 . F#5 . | D5 . F#5 B5 G5 . E5 . | C6 - B5 A5 F#5 - A5 . | G5 - - - G5,A5 B5,D6 G6 .',
    chords:'G G | C D | G G | Em D | C C | G Em | Am D | G G | C C | G G | Am Am | D D | C D | Bm Em | Am D | G G',
    drum:'k.h.s.hkk.h.s.h.',fill:'k.h.s.h.s.ssk.ss'},
  crystal:{name:'Crystal Caverns',bpm:150,duty:0.125,bass:'walk',arp:0.11,
    lead:'E5 . A5 . C#6 . B5,A5 E5 | G#5 - B5 . E6 - - . | F#5 . A5 . C#6 . A5 F#5 | F#5 . D5 F#5 E5 . G#5 B5 | C#6 . A5 . E6 . C#6 A5 | G#5 . E5 G#5 C#6 - B5,C#6 B5 | A5 . F#5 A5 B5 . G#5 E5 | A5 - - . A5,C#6 E6,A6 . .',
    chords:'A A | E E | F#m F#m | D E | A A | C#m C#m | D E | A A',
    drum:'k...h.h.s...h.hh',fill:'k...h.h.s.s.ssss'},
  mushroom:{name:'Mushroom Forest',bpm:172,duty:0.5,bass:'pump',
    lead:'C5 F5 . F5 A5 . C6 . | D6 . Bb5 . C6 . G5 . | A5 F5 . F5 A5 . C6 . | Bb5 . G5 . E5 . C5 . | F5 . A5 C6 F6 . C6 . | D6 . F6 . D6 . Bb5 . | A5 . C6 A5 G5 . E5 G5 | F5 - - . C5,D5 E5,F5 . . | D5 . F5 . A5 . F5 . | G5 . Bb5 . D6 . Bb5 . | C6 . E5 . G5 . C6 . | A5 - F5 . C5 . F5 . | D6 . Bb5 F5 E5 . G5 C6 | C6 . A5 E5 F5 . A5 D6 | Bb5 . G5 D5 E5,F5 G5 Bb5 . | A5 - G5 . F5 . . .',
    chords:'F F | Bb C | F F | Gm C | F F | Bb Bb | F C | F F | Dm Dm | Gm Gm | C C | F F | Bb C | Am Dm | Gm C | F F',
    drum:'k.hks.h.k.hks.hh',fill:'k.hks.h.s.s.ssss'},
  lagoon:{name:'Underwater Lagoon',bpm:140,duty:0.5,bass:'walk',arp:0.1,
    lead:'D5 - F5 . Bb5 - A5 . | G5 - D5 . Bb4 . D5 . | Eb5 - G5 . Bb5 - G5 . | A5 - - . F5 . C5 . | D5 - F5 . Bb5 - D6 . | A5 - F5 D5 G5 - Bb5 . | G5 . Eb5 G5 F5 . A5 C6 | Bb5 - - - Bb4,D5 F5,Bb5 . .',
    chords:'Bb Bb | Gm Gm | Eb Eb | F F | Bb Bb | Dm Gm | Eb F | Bb Bb',
    drum:'k...h..ks...h.h.',fill:'k...h..ks.s.ssss'},
  lava:{name:'Lava Halls',bpm:176,duty:0.25,bass:'oct',
    lead:'A4 . C5 E5 A5 . G5 . | F5 . A5 . G5 . B5 . | C6 . B5 A5 E5 . A5 . | F5 . A5 F5 E5 . G#5 B5 | A5 . E5 . A5 . C6 . | D6 . A5 . F5 . D5 . | G5 . B5 . D6 . B5 . | G#5 - E5 . B4 . E5 . | F5,G5 A5 . C6 . A5 F5 . | G5,A5 B5 . D6 . B5 G5 . | E5 . G5 B5 A5 . C6 E6 | D6 . A5 F5 E5 . G#5 B5 | C6 . A5 F5 D6 . B5 G5 | B5 . G5 E5 C6 . A5 E5 | F5 . A5 D6 B5 . G#5 E5 | A5 - - . E5,A5 C6,E6 A6 .',
    chords:'Am Am | F G | Am Am | F E | Am Am | Dm Dm | G G | E E | F F | G G | Em Am | Dm E | F G | Em Am | Dm E | Am Am',
    drum:'k.hhs.hhk.hhs.hh',fill:'k.hhs.hhs.ssk.ss'},
  stars:{name:'Starry Vault',bpm:156,duty:0.25,bass:'oct',arp:0.1,
    lead:'D5 . F#5 . A5 . D6 . | C#6 - A5 . E5 . A5 . | B5 . F#5 . D6 . B5 . | G5 . B5 D6 E6 . C#6 A5 | F#5 . A5 D6 F#6 - D6 . | C#6 . A5 F#5 B5 . D6 B5 | G5 . B5 D6 C#6 . E6 A5 | D6 - - . D5,F#5 A5,D6 . .',
    chords:'D D | A A | Bm Bm | G A | D D | F#m Bm | G A | D D',
    drum:'k.h.s.h.k.h.s.hh',fill:'k.h.s.h.s.ssssss'}
};
// mix: melody on top, then bass, drums, and the arpeggio shimmer underneath
var LEAD=0.22,BASS=0.11,ARP=0.075;
// which theme plays on which floor
function band(d){return d<=3?'sunny':d<=7?'crystal':d<=12?'mushroom':d<=17?'lagoon':d<=22?'lava':'stars';}
// jingles: [note, length in 16ths]
var J={down:[['C5',1],['E5',1],['G5',1],['C6',1],['E6',1],['G6',1],['C7',4]],up:[['C7',1],['G6',1],['E6',1],['C6',4]]};

function create(opts){
  opts=opts||{};var key=opts.key||'brogue.music',on=true;try{on=localStorage.getItem(key)!=='0';}catch(e){}
  var ctx=null,master=null,bus=null,cur=null,step=0,next=0,timer=null,noiseBuf=null,hold=0,wanted=null,waves={};
  function init(){if(ctx)return true;
    try{ctx=opts.audio?opts.audio():new (window.AudioContext||window.webkitAudioContext)();
      master=ctx.createGain();master.gain.value=0.8;master.connect(ctx.destination);
      var n=Math.floor(ctx.sampleRate*0.5);noiseBuf=ctx.createBuffer(1,n,ctx.sampleRate);var d=noiseBuf.getChannelData(0);
      // NES-style noise: random levels held for a few samples, which gives it a crunchy edge
      for(var i=0,v=0;i<n;i++){if(i%3===0)v=Math.random()<0.5?-1:1;d[i]=v;}return true;}catch(e){ctx=null;return false;}}
  // pulse wave with the given duty (0.125 / 0.25 / 0.5): the classic NES square channels
  function pulse(duty){if(waves[duty])return waves[duty];var N=48,re=new Float32Array(N),im=new Float32Array(N);
    for(var k=1;k<N;k++){re[k]=Math.sin(2*Math.PI*k*duty)/(Math.PI*k);im[k]=(1-Math.cos(2*Math.PI*k*duty))/(Math.PI*k);}
    return waves[duty]=ctx.createPeriodicWave(re,im);}
  function env(g,when,dur,vol){g.gain.setValueAtTime(0,when);g.gain.linearRampToValueAtTime(vol,when+0.004);g.gain.setTargetAtTime(vol*0.75,when+0.02,0.08);
    g.gain.setValueAtTime(vol*0.75,Math.max(when+0.02,when+dur-0.02));g.gain.linearRampToValueAtTime(0,when+dur);}
  function note(f,when,dur,duty,vol,dest,vib){if(!f)return;var o=ctx.createOscillator(),g=ctx.createGain();
    if(duty==='tri')o.type='triangle';else o.setPeriodicWave(pulse(duty));o.frequency.setValueAtTime(f,when);
    env(g,when,dur,vol);o.connect(g);g.connect(dest);o.start(when);o.stop(when+dur+0.05);
    if(vib&&dur>0.3){var l=ctx.createOscillator(),lg=ctx.createGain();l.frequency.value=6;lg.gain.setValueAtTime(0,when);lg.gain.linearRampToValueAtTime(f*0.012,when+0.25);
      l.connect(lg);lg.connect(o.frequency);l.start(when);l.stop(when+dur+0.05);}}
  // fast chord arpeggio over one span: the chord tones cycled every 32nd note on a thin pulse
  function arp(c,when,dur,s32,vol,dest){var o=ctx.createOscillator(),g=ctx.createGain(),tones=c.iv.concat([12]),base=60+c.root,i=0;
    if(base>66)base-=12;o.setPeriodicWave(pulse(0.125));for(var t=when;t<when+dur-0.001;t+=s32){o.frequency.setValueAtTime(mhz(base+tones[i%tones.length]),t);i++;}
    env(g,when,dur,vol);o.connect(g);g.connect(dest);o.start(when);o.stop(when+dur+0.05);}
  function drum(ch,when,dest){
    if(ch==='k'){var o=ctx.createOscillator(),g=ctx.createGain();o.type='triangle';o.frequency.setValueAtTime(180,when);o.frequency.exponentialRampToValueAtTime(40,when+0.09);
      g.gain.setValueAtTime(0.55,when);g.gain.exponentialRampToValueAtTime(0.001,when+0.13);o.connect(g);g.connect(dest);o.start(when);o.stop(when+0.15);}
    var s=ctx.createBufferSource(),f=ctx.createBiquadFilter(),g3=ctx.createGain(),len=ch==='k'?0.02:ch==='s'?0.13:ch==='o'?0.14:0.035,vol=ch==='k'?0.12:ch==='s'?0.2:ch==='o'?0.07:0.07;
    s.buffer=noiseBuf;s.playbackRate.value=ch==='s'||ch==='k'?0.5:1;f.type=ch==='s'||ch==='k'?'bandpass':'highpass';f.frequency.value=ch==='s'?2200:ch==='k'?900:7500;
    g3.gain.setValueAtTime(vol,when);g3.gain.exponentialRampToValueAtTime(0.001,when+len);s.connect(f);f.connect(g3);g3.connect(dest);s.start(when);s.stop(when+len+0.02);}
  function prep(tu){if(tu._l)return;tu._l=toks(tu.lead);var c=toks(tu.chords),last=null;tu._c=c.map(function(x){if(x!=='-')last=chord(x);return last;});}
  function chordAt(tu,e){return tu._c[Math.floor(e/4)%tu._c.length];}
  function bassNote(tu,e){var c=chordAt(tu,e),r=36+c.root;if(r<38)r+=12;var k=e%4,st=tu.bass;
    if(st==='walk')return r+[0,7,12,7][k];if(st==='pump')return r+[0,0,12,0][k];return r+(k%2?12:0);}
  function tick(){if(!cur||!ctx)return;var tu=T[cur];prep(tu);var s16=60/tu.bpm/4,L=tu._l;
    // look further ahead than usual: the tablet can be busy drawing the dungeon for a moment
    while(next<ctx.currentTime+0.35){
      var e=step>>1,loop=Math.floor(e/L.length),i=e%L.length,bar=Math.floor(e/8);
      // second time round the lead changes tone; every third time it rests and the arpeggios carry the tune
      var rest=loop%3===2,duty=loop%3===1?(tu.duty===0.125?0.25:0.125):tu.duty;
      if(step%2===0){
        var t=L[i];
        if(!rest&&t!=='.'&&t!=='-'){var h=1;while(L[(i+h)%L.length]==='-'&&h<16)h++;
          if(t.indexOf(',')>0){var p=t.split(',');note(hz(p[0]),next,s16*0.95,duty,LEAD,bus,false);note(hz(p[1]),next+s16,s16*(1+2*(h-1))*0.92,duty,LEAD,bus,h>1);}
          else note(hz(t),next,s16*2*h*0.92,duty,LEAD,bus,true);}
        note(mhz(bassNote(tu,e)),next,s16*1.7,'tri',BASS,bus,false);
        if(e%4===0)arp(chordAt(tu,e),next,s16*8,s16/2,rest?0.15:(tu.arp||ARP),bus);}
      var D=(bar%4===3&&tu.fill)?tu.fill:tu.drum,dc=D[step%16];if(dc&&dc!=='.')drum(dc,next,bus);
      step++;next+=s16;}}
  function fadeOut(){if(timer){clearInterval(timer);timer=null;}if(bus&&ctx){var b=bus;try{b.gain.setTargetAtTime(0,ctx.currentTime,0.06);setTimeout(function(){try{b.disconnect();}catch(e){}},700);}catch(e){}}bus=null;cur=null;}
  function start(name){fadeOut();if(!on||!T[name]||!init())return;cur=name;bus=ctx.createGain();bus.gain.value=0.5;bus.connect(master);step=0;next=Math.max(ctx.currentTime+0.08,hold);tick();timer=setInterval(tick,60);}
  // the tune for where we are; switching waits for a jingle to finish
  function want(name){wanted=name;if(cur===name&&timer)return;start(name);}
  function stop(){wanted=null;fadeOut();}
  function jingle(name){if(!on||!J[name]||!init())return;var j=J[name],t=ctx.currentTime+0.03,s=0.055;
    j.forEach(function(x){var d=x[1]*s;note(hz(x[0]),t,d*0.95,0.25,0.17,master,x[1]>2);note(hz(x[0])/2,t,d*0.95,0.125,0.07,master,false);t+=d;});
    hold=t+0.2;if(cur){var c=cur;fadeOut();start(c);}}
  function setOn(v){on=!!v;try{localStorage.setItem(key,on?'1':'0');}catch(e){}if(!on)fadeOut();else if(wanted)start(wanted);}
  return {want:want,stop:stop,jingle:jingle,setOn:setOn,isOn:function(){return on;},cur:function(){return cur;},band:band,
    unlock:function(){if(on&&init()&&ctx.state==='suspended'){try{ctx.resume();}catch(e){}}},tunes:T};
}
window.BrogueMusic={create:create,band:band,chord:chord};
})();
