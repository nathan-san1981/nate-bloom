/* Dungeon music for the kid look (unicorn clock): calm, ambient chiptune. Soft square-wave pads, slow chord
   arpeggios with an echo, a few gentle melody notes on top and a round triangle bass. No drums. A title tune and
   six floor themes that change with depth, plus a soft "new floor" chime, all made on the device with Web Audio.
   window.BrogueMusic.create(opts) */
(function(){
var NOTE={C:0,D:2,E:4,F:5,G:7,A:9,B:11};
function midi(n){var m=/^([A-G])(#|b)?(\d)$/.exec(n);if(!m)return null;return NOTE[m[1]]+(m[2]==='#'?1:m[2]==='b'?-1:0)+12*(+m[3]+1);}
function mhz(m){return 440*Math.pow(2,(m-69)/12);}
function hz(n){var m=midi(n);return m===null?0:mhz(m);}
// chord symbol -> semitones above the root
var QUAL={'':[0,4,7],m:[0,3,7],'7':[0,4,7,10],maj7:[0,4,7,11],m7:[0,3,7,10],sus4:[0,5,7],sus2:[0,2,7],add9:[0,4,7,14],dim:[0,3,6],aug:[0,4,8]};
function chord(sym){var m=/^([A-G])(#|b)?(maj7|m7|sus4|sus2|add9|dim|aug|m|7)?$/.exec(sym);if(!m)return null;
  return {root:NOTE[m[1]]+(m[2]==='#'?1:m[2]==='b'?-1:0),iv:QUAL[m[3]||'']};}
function toks(str){return str?str.replace(/\|/g,' ').trim().split(/\s+/):[];}

/* Each tune: one chord per bar; the arpeggio pattern is one bar of 8th notes, each a chord-tone index (0 = root,
   counting up through the chord and into the next octave) or '.' for a rest; the melody is in 8th notes ('.' rest,
   '-' hold) and plays every other time round; voice = melody sound (tri: soft flute, pulse: mellow square,
   bell: plucked chime); arpOct shifts the arpeggio register; wobble gives the pads a slow underwater sway. */
var T={
  title:{name:'Unicorn Dungeon',bpm:72,voice:'tri',arp:'0 1 2 3 4 3 2 1',
    chords:'Cmaj7 Fmaj7 Am7 G Cmaj7 Fmaj7 Dm7 Gsus4',
    lead:'E5 - - - G5 - - - | A5 - - - G5 - E5 - | C5 - - - - - . . | D5 - - - B4 - - - | E5 - - - G5 - C6 - | B5 - - - A5 - - - | F5 - - - E5 - D5 - | D5 - - - - - . .'},
  sunny:{name:'Sunny Caves',bpm:80,voice:'pulse',arp:'0 2 4 2 1 3 5 3',
    chords:'Gmaj7 Cmaj7 Em7 D Gmaj7 Cmaj7 Am7 Dsus4',
    lead:'B5 - - - D6 - - - | E6 - - - D6 - B5 - | G5 - - - - - B5 - | A5 - - - F#5 - - - | G5 - B5 - D6 - - - | E6 - - - C6 - B5 - | A5 - - - G5 - E5 - | D5 - - - - - . .'},
  crystal:{name:'Crystal Caverns',bpm:70,voice:'bell',arp:'0 2 4 6 7 5 3 1',arpOct:1,
    chords:'Amaj7 C#m7 Dmaj7 E Amaj7 F#m7 Dmaj7 Esus4',
    lead:'C#6 - - - - - - - | E6 - - - B5 - - - | A5 - - - F#5 - - - | G#5 - - - - - - - | C#6 - - - E6 - - - | C#6 - - - A5 - - - | F#5 - - - A5 - - - | B5 - - - - - . .'},
  mushroom:{name:'Mushroom Forest',bpm:84,voice:'pulse',arp:'0 . 2 1 3 . 2 1',
    chords:'Fmaj7 Gm7 Am7 Bbmaj7 Fmaj7 Gm7 Bbmaj7 C',
    lead:'A5 . C6 . A5 . F5 . | G5 - - - Bb5 - - - | A5 . C6 . E6 - - - | D6 - - - - - . . | C6 . A5 . F5 . A5 . | Bb5 - - - D6 - - - | F5 - - - A5 - - - | G5 - - - E5 - - -'},
  lagoon:{name:'Underwater Lagoon',bpm:62,voice:'tri',arp:'0 1 2 3 2 1 2 3',wobble:1,
    chords:'Bbmaj7 Gm7 Ebmaj7 F Bbmaj7 Dm7 Ebmaj7 Fsus4',
    lead:'D6 - - - - - - - | Bb5 - - - - - D6 - | G5 - - - - - - - | A5 - - - F5 - - - | F5 - - - A5 - - - | F5 - - - - - D5 - | G5 - - - Bb5 - - - | C6 - - - - - . .'},
  lava:{name:'Lava Halls',bpm:64,voice:'tri',arp:'0 1 2 1 0 1 2 3',arpOct:-1,
    chords:'Am Fmaj7 C G Am Fmaj7 Dm7 E',
    lead:'E5 - - - - - C5 - | A4 - - - - - - - | G4 - - - E5 - - - | D5 - - - - - B4 - | C5 - - - E5 - A5 - | G5 - - - E5 - - - | F5 - - - D5 - - - | G#4 - - - - - . .'},
  stars:{name:'Starry Vault',bpm:68,voice:'bell',arp:'4 5 6 7 6 5 4 3',
    chords:'Dmaj7 Bm7 Gmaj7 A Dmaj7 F#m7 Gmaj7 Asus4',
    lead:'F#6 - - - A5 - - - | D6 - - - - - B5 - | B5 - - - - - - - | C#6 - - - E6 - - - | A5 - - - C#6 - F#6 - | E6 - - - C#6 - - - | D6 - - - B5 - - - | A5 - - - - - . .'}
};
// mix: everything soft; the pads underneath, the arpeggio and its echo in the middle, the melody gently on top
var PAD=0.032,ARP=0.055,LEAD=0.075,BASS=0.07;
// which theme plays on which floor
function band(d){return d<=3?'sunny':d<=7?'crystal':d<=12?'mushroom':d<=17?'lagoon':d<=22?'lava':'stars';}
// chimes: [note, length in 8ths]
var J={down:[['G5',1],['C6',1],['E6',1],['G6',3]],up:[['G6',1],['E6',1],['C6',3]]};

function create(opts){
  opts=opts||{};var key=opts.key||'brogue.music',on=true;try{on=localStorage.getItem(key)!=='0';}catch(e){}
  var ctx=null,master=null,cur=null,step=0,next=0,timer=null,hold=0,wanted=null,waves={},N=null;
  function init(){if(ctx)return true;
    try{ctx=opts.audio?opts.audio():new (window.AudioContext||window.webkitAudioContext)();
      master=ctx.createGain();master.gain.value=0.75;master.connect(ctx.destination);return true;}catch(e){ctx=null;return false;}}
  // pulse wave with the given duty: the classic square channels, here always heard through a soft filter
  function pulse(duty){if(waves[duty])return waves[duty];var n=32,re=new Float32Array(n),im=new Float32Array(n);
    for(var k=1;k<n;k++){re[k]=Math.sin(2*Math.PI*k*duty)/(Math.PI*k);im[k]=(1-Math.cos(2*Math.PI*k*duty))/(Math.PI*k);}
    return waves[duty]=ctx.createPeriodicWave(re,im);}
  function osc(type,f,when){var o=ctx.createOscillator();if(type==='tri')o.type='triangle';else o.setPeriodicWave(pulse(type));o.frequency.setValueAtTime(f,when);return o;}
  // swell in, hold, fade out: no clicks, nothing sharp
  function env(g,when,dur,vol,atk,rel){atk=Math.min(atk,dur*0.5);g.gain.setValueAtTime(0.0001,when);g.gain.linearRampToValueAtTime(vol,when+atk);
    g.gain.setValueAtTime(vol,Math.max(when+atk,when+dur-rel));g.gain.linearRampToValueAtTime(0.0001,when+dur);}
  function play(type,f,when,dur,vol,dest,atk,rel,vib){if(!f)return;var o=osc(type,f,when),g=ctx.createGain();env(g,when,dur,vol,atk,rel);o.connect(g);g.connect(dest);
    if(vib&&dur>0.6){var l=ctx.createOscillator(),lg=ctx.createGain();l.frequency.value=4.5;lg.gain.setValueAtTime(0,when);lg.gain.linearRampToValueAtTime(f*0.008,when+0.5);
      l.connect(lg);lg.connect(o.frequency);l.start(when);l.stop(when+dur+0.05);}
    o.start(when);o.stop(when+dur+0.05);}
  // plucked chime: quick start, long ring-out
  function bell(f,when,vol,dest){var o=osc(0.125,f,when),o2=osc('tri',f*2,when),g=ctx.createGain();
    g.gain.setValueAtTime(0.0001,when);g.gain.linearRampToValueAtTime(vol,when+0.01);g.gain.exponentialRampToValueAtTime(0.0001,when+1.6);
    o.connect(g);o2.connect(g);g.connect(dest);o.start(when);o2.start(when);o.stop(when+1.7);o2.stop(when+1.7);}
  // one tune's sound: pads through a low filter, arpeggio and melody into an echo, all fading together on change
  function chain(tu){var bus=ctx.createGain();bus.gain.setValueAtTime(0.0001,ctx.currentTime);bus.gain.linearRampToValueAtTime(1,ctx.currentTime+1.2);bus.connect(master);
    var padF=ctx.createBiquadFilter();padF.type='lowpass';padF.frequency.value=1100;padF.Q.value=0.4;padF.connect(bus);
    if(tu.wobble){var lf=ctx.createOscillator(),lg=ctx.createGain();lf.frequency.value=0.18;lg.gain.value=380;lf.connect(lg);lg.connect(padF.frequency);lf.start();}
    var tone=ctx.createBiquadFilter();tone.type='lowpass';tone.frequency.value=2600;tone.Q.value=0.3;tone.connect(bus);
    var d=ctx.createDelay(2),fb=ctx.createGain(),wet=ctx.createGain(),wf=ctx.createBiquadFilter();
    d.delayTime.value=60/tu.bpm*0.75;fb.gain.value=0.42;wet.gain.value=0.55;wf.type='lowpass';wf.frequency.value=1800;
    tone.connect(d);d.connect(wf);wf.connect(fb);fb.connect(d);wf.connect(wet);wet.connect(bus);
    return {bus:bus,pad:padF,tone:tone};}
  function prep(tu){if(tu._l)return;tu._l=toks(tu.lead);tu._c=toks(tu.chords).map(chord);tu._a=toks(tu.arp);}
  function tone(c,i,base){var iv=c.iv,n=iv.length;return base+c.root+iv[i%n]+12*Math.floor(i/n);}
  function tick(){if(!cur||!ctx||!N)return;var tu=T[cur];prep(tu);var s8=60/tu.bpm/2,L=tu._l,bars=tu._c.length;
    while(next<ctx.currentTime+0.5){
      var bar=Math.floor(step/8)%bars,loop=Math.floor(step/8/bars),c=tu._c[bar],k=step%8,t=next;
      if(k===0){
        // pads: three soft voices for the whole bar, overlapping into the next
        var pb=48;var vs=[tone(c,1,pb),tone(c,2,pb),tone(c,c.iv.length>3?3:0,pb+(c.iv.length>3?0:12))];
        vs.forEach(function(m,j){play(0.5,mhz(m),t,s8*8+0.6,PAD*(j?0.8:1),N.pad,0.9,0.9,false);});
        // bass: the root, long and round
        var r=36+c.root;if(r<38)r+=12;play('tri',mhz(r),t,s8*8-0.05,BASS,N.bus,0.25,0.5,false);}
      var a=tu._a[k];if(a&&a!=='.'){var m=tone(c,+a,60+12*(tu.arpOct||0));if(m>88)m-=12;
        play(0.25,mhz(m),t,s8*0.9,ARP*(k%2?0.8:1),N.tone,0.012,0.18,false);}
      // melody: first time round, then rests a time to let the arpeggios breathe
      if(loop%2===0){var li=(bar*8+k)%L.length,n=L[li];
        if(n&&n!=='.'&&n!=='-'){var h=1;while(L[(li+h)%L.length]==='-'&&h<16)h++;var f=hz(n),dur=s8*h;
          if(tu.voice==='bell')bell(f,t,LEAD*1.1,N.tone);
          else play(tu.voice==='pulse'?0.25:'tri',f,t,dur*0.96,tu.voice==='pulse'?LEAD*0.8:LEAD,N.tone,0.06,Math.min(0.5,dur*0.4),true);}}
      step++;next+=s8;}}
  function fadeOut(){if(timer){clearInterval(timer);timer=null;}if(N&&ctx){var b=N.bus;try{b.gain.cancelScheduledValues(ctx.currentTime);b.gain.setTargetAtTime(0.0001,ctx.currentTime,0.35);setTimeout(function(){try{b.disconnect();}catch(e){}},2600);}catch(e){}}N=null;cur=null;}
  function start(name){fadeOut();if(!on||!T[name]||!init())return;cur=name;N=chain(T[name]);step=0;next=Math.max(ctx.currentTime+0.1,hold);tick();timer=setInterval(tick,80);}
  // the tune for where we are; switching waits for a chime to finish
  function want(name){wanted=name;if(cur===name&&timer)return;start(name);}
  function stop(){wanted=null;fadeOut();}
  function jingle(name){if(!on||!J[name]||!init())return;var j=J[name],t=ctx.currentTime+0.03,s=0.16;
    j.forEach(function(x){bell(hz(x[0]),t,0.09,master);t+=x[1]*s;});
    hold=t+0.6;if(cur){var c=cur;fadeOut();start(c);}}
  function setOn(v){on=!!v;try{localStorage.setItem(key,on?'1':'0');}catch(e){}if(!on)fadeOut();else if(wanted)start(wanted);}
  return {want:want,stop:stop,jingle:jingle,setOn:setOn,isOn:function(){return on;},cur:function(){return cur;},band:band,
    unlock:function(){if(on&&init()&&ctx.state==='suspended'){try{ctx.resume();}catch(e){}}},tunes:T};
}
window.BrogueMusic={create:create,band:band,chord:chord};
})();
