/* Brogue CE in the browser: WASI shim + Asyncify driver + canvas renderer + touch/keyboard input.
   Exposes window.BrogueApp.start(opts). Brogue CE is AGPL-3.0; tiles are CC BY-SA 4.0 (Brogue CE maintainers). */
(function(){
'use strict';
var COLS=100,ROWS=34,SBW=20,MSGL=3;
function b64bytes(b){var s=atob(b),u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return u;}
function u8tob64(u){var s='',CH=0x8000;for(var i=0;i<u.length;i+=CH)s+=String.fromCharCode.apply(null,u.subarray(i,i+CH));return btoa(s);}

/* ---------------- memory file system (persisted to localStorage) ---------------- */
function MemFS(key){
  this.key=key;this.files={};
  try{var raw=localStorage.getItem(key);if(raw){var o=JSON.parse(raw);for(var k in o)this.files[k]={data:b64bytes(o[k].d),mtime:o[k].m||Date.now()};}}catch(e){}
}
MemFS.prototype.save=function(){var self=this;clearTimeout(this.t);this.t=setTimeout(function(){self.saveNow();},400);};
MemFS.prototype.saveNow=function(){
  var o={},names=Object.keys(this.files);
  // keep saves, scores and history first; recordings only if there is room
  names.sort(function(a,b){function r(n){return /\.broguesave$/.test(n)?0:/\.txt$/.test(n)?1:2;}return r(a)-r(b);});
  var total=0;
  for(var i=0;i<names.length;i++){var f=this.files[names[i]];if(f.data.length>1500000&&!/\.broguesave$/.test(names[i]))continue;var d=u8tob64(f.data);total+=d.length;if(total>3000000&&!/\.broguesave$|\.txt$/.test(names[i]))continue;o[names[i]]={d:d,m:f.mtime};}
  try{localStorage.setItem(this.key,JSON.stringify(o));}catch(e){
    // quota: drop recordings and try again
    for(var k in o)if(/\.broguerec$/.test(k))delete o[k];
    try{localStorage.setItem(this.key,JSON.stringify(o));}catch(e2){}
  }
};

/* ---------------- the app ---------------- */
function BrogueApp(opts){
  this.o=opts;this.fs=new MemFS(opts.storageKey||'brogue.fs');
  this.queue=[];this.waiter=null;this.mods={shift:false,ctrl:false};
  this.cells=new Array(COLS*ROWS);for(var i=0;i<this.cells.length;i++)this.cells[i]={u:32,s:-1,f:'#fff',b:'#000',d:true};
  this.allDirty=true;this.gmode=0;this.textInput=false;this.zoom=opts.zoom||1;this.ended=false;
}
BrogueApp.prototype.start=async function(){
  var self=this,o=this.o;
  this.canvas=o.canvas;this.ctx=this.canvas.getContext('2d');
  this.off=document.createElement('canvas');this.octx=this.off.getContext('2d');
  this.setCellSize(o.kid?24:16,o.kid?42:28);
  // kid look (unicorn clock): full-colour sprites drawn over a tint layer in Brogue's own colour
  this.kid=null;if(o.kid){var K=this.kid={has:{},tint:{},big:{},seen:{},fix:null,tin:null,cache:{},on:false};o.kid.has.forEach(function(i){K.has[i]=1;});o.kid.tint.forEach(function(i){K.tint[i]=1;});(o.kid.big||[]).forEach(function(i){K.big[i]=1;});
    var a=new Image();a.onload=function(){K.fix=a;K.cache={};self.allDirty=true;};a.src='data:image/png;base64,'+o.kid.fixB64;
    var b=new Image();b.onload=function(){K.tin=b;K.cache={};self.allDirty=true;};b.src='data:image/png;base64,'+o.kid.tintB64;}
  // tiles atlas -> per-size cache built lazily
  this.tilesImg=null;if(o.tilesB64){var im=new Image();im.onload=function(){self.tilesImg=im;self.tileCache={};self.allDirty=true;};im.src='data:image/png;base64,'+o.tilesB64;}
  var bytes=b64bytes(o.wasmB64);
  var imports={env:this.envImports(),wasi_snapshot_preview1:this.wasiImports()};
  var res=await WebAssembly.instantiate(bytes,imports);
  this.inst=res.instance;this.ex=this.inst.exports;this.mem=this.ex.memory;
  this.adata=this.ex.malloc(1<<20);var dv=new DataView(this.mem.buffer);dv.setInt32(this.adata,this.adata+8,true);dv.setInt32(this.adata+4,this.adata+(1<<20),true);
  this.astate=0; // 0 normal 1 unwinding 2 rewinding
  this.bindInput();
  this.raf();
  this.run();
};
// stop this game for good (restart builds a fresh one): no more frames, input or wasm resumes
BrogueApp.prototype.destroy=function(){this.dead=true;this.ended=true;this.queue=[];this.waiter=null;
  window.removeEventListener('keydown',this.onKey);window.removeEventListener('keyup',this.onKey);window.removeEventListener('blur',this.onBlur);};
BrogueApp.prototype.setCellSize=function(cw,ch){this.cw=cw;this.ch=ch;this.off.width=COLS*cw;this.off.height=ROWS*ch;this.allDirty=true;this.tileCache={};if(this.kid)this.kid.cache={};};
BrogueApp.prototype.run=async function(){
  var ex=this.ex;
  for(;;){
    try{ex._start();}
    catch(e){if(e&&e.brogueExit!==undefined){this.ended=true;if(this.o.onExit)this.o.onExit(e.brogueExit);return;}console.error(e);if(this.o.onError)this.o.onError(e);return;}
    if(this.astate!==1){this.ended=true;if(this.o.onExit)this.o.onExit(0);return;}
    ex.asyncify_stop_unwind();this.astate=0;
    this.aresult=await this.apromise;
    if(this.dead)return;
    ex.asyncify_start_rewind(this.adata);this.astate=2;
  }
};
BrogueApp.prototype.async=function(fn){var self=this;return function(){
  if(self.astate===2){self.ex.asyncify_stop_rewind();self.astate=0;return self.aresult;}
  var r=fn.apply(self,arguments);
  if(r&&typeof r.then==='function'){self.apromise=r;self.ex.asyncify_start_unwind(self.adata);self.astate=1;return 0;}
  return r;};};
BrogueApp.prototype.str=function(p){var u=new Uint8Array(this.mem.buffer),e=p;while(u[e])e++;return new TextDecoder().decode(u.subarray(p,e));};
BrogueApp.prototype.envImports=function(){
  var self=this;
  return {
    js_plot:function(glyph,sprite,uni,x,y,fr,fg,fb,br,bg,bb){
      if(x<0||y<0||x>=COLS||y>=ROWS)return;var c=self.cells[y*COLS+x];
      if(self.kid){var m=Math.max(br,bg,bb),t=m<14?1-m/14:0;if(t>0){br+=11*t;bg+=7*t;bb+=19*t;}}
      var f='rgb('+Math.round(fr*2.55)+','+Math.round(fg*2.55)+','+Math.round(fb*2.55)+')',b='rgb('+Math.round(br*2.55)+','+Math.round(bg*2.55)+','+Math.round(bb*2.55)+')';
      if(c.u!==uni||c.s!==sprite||c.f!==f||c.b!==b){c.u=uni;c.s=sprite;c.f=f;c.b=b;c.fm=Math.max(fr,fg,fb);c.d=true;self.dirty=true;}},
    js_next_event:this.async(function(out,textInput,dance){
      var self2=this;this.setTextInput(!!textInput);
      var take=function(){var ev=self2.queue.shift();var dv=new DataView(self2.mem.buffer);for(var i=0;i<5;i++)dv.setInt32(out+i*4,ev[i]|0,true);return 0;};
      if(this.queue.length)return take();
      return new Promise(function(res){
        var danceT=dance?setInterval(function(){if(!self2.queue.length){self2.queue.push([99,0,0,0,0]);var w=self2.waiter;self2.waiter=null;if(w)w();}},180):null;
        self2.waiter=function(){if(danceT)clearInterval(danceT);take();res(0);};
      });}),
    js_pause:this.async(function(ms,mouseMove){
      var self2=this;
      if(this.queue.some(function(e){return e[0]!==99&&(mouseMove||e[0]!==5);}))return 1;
      if(ms<=0)return 0;
      return new Promise(function(res){var done=false;
        var t=setTimeout(function(){if(done)return;done=true;self2.waiter=null;res(0);},ms);
        self2.waiter=function(){if(done)return;done=true;clearTimeout(t);res(1);};});}),
    js_modifier:function(w){return w===0?(self.mods.shift?1:0):(self.mods.ctrl?1:0);},
    js_notify:function(id,d1,d2,s1,s2){if(id===900){if(self.o.onTextInput)self.o.onTextInput(!!d1);return;}
      if(id===901){self.onTitle=!!d1;if(self.o.onTitle)self.o.onTitle(!!d1);return;}
      if(id===902){var items=self.str(s1).split('\n').filter(Boolean).map(function(l){var f=l.split('\t');return {i:+f[0],x:+f[1],y:+f[2],hk:+f[3],en:f[4]==='1',label:f.slice(5).join(' ').replace(/\s+/g,' ').trim()};});
        var w=self.str(s2).split(',').map(Number);if(self.o.onMenu)self.o.onMenu(items,{x:w[0],y:w[1],w:w[2],h:w[3]});return;}
      if(id===903){if(self.o.onMenuClose)self.o.onMenuClose(d1);return;}
      if(id===906){if(self.o.onMessage)self.o.onMessage(self.str(s1).replace(/\x19[\s\S]{3}/g,''),d1);return;}
      if(id===904||id===905){if(self.o.onBubble)self.o.onBubble(id===904?{text:self.str(s1).replace(/\x19[\s\S]{3}/g,''),title:self.str(s2).replace(/\x19[\s\S]{3}/g,'')}:null);return;}if(self.o.onNotify)self.o.onNotify(id,d1,d2,self.str(s1),self.str(s2));},
    js_graphics:function(mode){self.gmode=mode;self.allDirty=true;if(self.o.onGraphics)self.o.onGraphics(mode);return mode;},
    js_remap:function(){},
    js_bubble:function(){return self.kid&&self.kid.on&&self.o.onBubble?1:0;},
    js_kid:function(){return self.kid?1:0;}
  };
};
BrogueApp.prototype.push=function(ev){this.queue.push(ev);var w=this.waiter;this.waiter=null;if(w)w();};
BrogueApp.prototype.key=function(code,shift,ctrl){this.push([0,code,0,ctrl?1:0,shift?1:0]);};
BrogueApp.prototype.click=function(x,y){this.push([5,x,y,0,0]);this.push([2,x,y,0,0]);this.push([1,x,y,0,0]);};
BrogueApp.prototype.hover=function(x,y){this.push([5,x,y,0,0]);};
BrogueApp.prototype.cellRectCss=function(){if(!this.canvas||(((this.zoomSusp||!this.inGame())?1:this.zoom)>1))return null;var r=this.regions()[0],k=this.canvas.width/(this.canvas.clientWidth||1);return {x0:r.dx/k,y0:r.dy/k,cw:r.dw/k/COLS,ch:r.dh/k/ROWS};};
BrogueApp.prototype.tapCell=function(x,y){this.hover(x,y);this.push([2,x,y,0,0]);this.push([1,x,y,0,0]);};
BrogueApp.prototype.hasSave=function(){return Object.keys(this.fs.files).some(function(n){return /\.broguesave$/.test(n);});};
BrogueApp.prototype.setTextInput=function(on){this.textInput=on;};

/* ---------------- WASI ---------------- */
BrogueApp.prototype.wasiImports=function(){
  var self=this,fs=this.fs,fds={0:{t:'tty'},1:{t:'tty'},2:{t:'tty'},3:{t:'dir',path:''}},nextFd=4,enc=new TextEncoder(),out='';
  var ENOENT=44,EBADF=8,EEXIST=20,EINVAL=28,ENOTDIR=54;
  function V(){return new DataView(self.mem.buffer);} function U(){return new Uint8Array(self.mem.buffer);}
  function pth(p,l){var s=new TextDecoder().decode(U().subarray(p,p+l));s=s.replace(/^\.\//,'').replace(/^\/+/,'');return s==='.'?'':s;}
  function grow(f,n){if(f.data.length>=n)return;var cap=Math.max(n,f.data.length*2,256),d=new Uint8Array(cap);d.set(f.data);f.cap=d;}
  return {
    args_sizes_get:function(pc,ps){var a=self.args();V().setUint32(pc,a.length,true);V().setUint32(ps,a.reduce(function(s,x){return s+enc.encode(x).length+1;},0),true);return 0;},
    args_get:function(pv,pb){var a=self.args(),v=V(),u=U();a.forEach(function(x,i){v.setUint32(pv+i*4,pb,true);var b=enc.encode(x);u.set(b,pb);u[pb+b.length]=0;pb+=b.length+1;});return 0;},
    environ_sizes_get:function(c,s){V().setUint32(c,0,true);V().setUint32(s,0,true);return 0;},
    environ_get:function(){return 0;},
    clock_time_get:function(id,prec,p){if(arguments.length>=4)p=arguments[3];V().setBigUint64(p,BigInt(Date.now())*1000000n,true);return 0;},
    clock_res_get:function(id,p){V().setBigUint64(p,1000000n,true);return 0;},
    random_get:function(p,l){var u=U();for(var i=0;i<l;i++)u[p+i]=Math.random()*256|0;return 0;},
    proc_exit:function(c){var e=new Error('exit');e.brogueExit=c;throw e;},
    sched_yield:function(){return 0;},
    poll_oneoff:function(){return 52;},
    fd_prestat_get:function(fd,p){if(fd!==3)return EBADF;var v=V();v.setUint8(p,0);v.setUint32(p+4,1,true);return 0;},
    fd_prestat_dir_name:function(fd,p,l){if(fd!==3)return EBADF;U()[p]=46;return 0;},
    fd_fdstat_get:function(fd,p){var f=fds[fd];if(!f)return EBADF;var v=V();v.setUint8(p,f.t==='tty'?2:f.t==='dir'?3:4);v.setUint16(p+2,0,true);v.setBigUint64(p+8,0xffffffffffffffffn,true);v.setBigUint64(p+16,0xffffffffffffffffn,true);return 0;},
    fd_fdstat_set_flags:function(){return 0;},
    fd_filestat_get:function(fd,p){var f=fds[fd];if(!f)return EBADF;var v=V();for(var i=0;i<64;i++)v.setUint8(p+i,0);
      v.setUint8(p+16,f.t==='dir'?3:f.t==='tty'?2:4);v.setBigUint64(p+24,1n,true);if(f.t==='file'){var F=fs.files[f.path];v.setBigUint64(p+32,BigInt(F?F.data.length:0),true);var m=BigInt((F?F.mtime:Date.now()))*1000000n;v.setBigUint64(p+40,m,true);v.setBigUint64(p+48,m,true);v.setBigUint64(p+56,m,true);}return 0;},
    path_filestat_get:function(dfd,flags,p,l,b){var n=pth(p,l),v=V();for(var i=0;i<64;i++)v.setUint8(b+i,0);
      if(n===''){v.setUint8(b+16,3);return 0;}var F=fs.files[n];if(!F)return ENOENT;v.setUint8(b+16,4);v.setBigUint64(b+24,1n,true);v.setBigUint64(b+32,BigInt(F.data.length),true);var m=BigInt(F.mtime)*1000000n;v.setBigUint64(b+40,m,true);v.setBigUint64(b+48,m,true);v.setBigUint64(b+56,m,true);return 0;},
    path_open:function(dfd,dflags,p,l,oflags,rb,ri,fdflags,pfd){if(arguments.length>=11){fdflags=arguments[9];pfd=arguments[10];}var n=pth(p,l);
      if(n===''||(oflags&2)){var fd=nextFd++;fds[fd]={t:'dir',path:n,list:null};V().setUint32(pfd,fd,true);return 0;}
      var F=fs.files[n];if(!F){if(!(oflags&1))return ENOENT;F=fs.files[n]={data:new Uint8Array(0),mtime:Date.now()};}
      else if(oflags&4)return EEXIST;
      if(oflags&8){F.data=new Uint8Array(0);F.mtime=Date.now();}
      var fd2=nextFd++;fds[fd2]={t:'file',path:n,pos:(fdflags&1)?F.data.length:0,app:!!(fdflags&1),w:false};V().setUint32(pfd,fd2,true);return 0;},
    fd_close:function(fd){var f=fds[fd];if(!f)return EBADF;if(f.t==='file'&&f.w)fs.save();delete fds[fd];return 0;},
    fd_read:function(fd,iovs,n,pr){var f=fds[fd];if(!f)return EBADF;var v=V(),u=U(),tot=0;if(f.t!=='file'){v.setUint32(pr,0,true);return 0;}
      var F=fs.files[f.path];for(var i=0;i<n;i++){var b=v.getUint32(iovs+i*8,true),l=v.getUint32(iovs+i*8+4,true),k=Math.min(l,F.data.length-f.pos);if(k<=0)break;u.set(F.data.subarray(f.pos,f.pos+k),b);f.pos+=k;tot+=k;if(k<l)break;}
      v.setUint32(pr,tot,true);return 0;},
    fd_write:function(fd,iovs,n,pw){var f=fds[fd];if(!f)return EBADF;var v=V(),u=U(),tot=0;
      for(var i=0;i<n;i++){var b=v.getUint32(iovs+i*8,true),l=v.getUint32(iovs+i*8+4,true);var chunk=u.slice(b,b+l);tot+=l;
        if(f.t==='tty'){out+=new TextDecoder().decode(chunk);var nl=out.lastIndexOf('\n');if(nl>=0){console.log('[brogue] '+out.slice(0,nl));out=out.slice(nl+1);}}
        else if(f.t==='file'){var F=fs.files[f.path];if(f.app)f.pos=F.data.length;var end=f.pos+l;if(end>F.data.length){var d=new Uint8Array(end);d.set(F.data);F.data=d;}F.data.set(chunk,f.pos);f.pos=end;F.mtime=Date.now();f.w=true;}}
      v.setUint32(pw,tot,true);return 0;},
    fd_seek:function(fd,off,wh,pn){if(arguments.length>=5){off=(arguments[1]>>>0)+(arguments[2]|0)*4294967296;wh=arguments[3];pn=arguments[4];}var f=fds[fd];if(!f||f.t!=='file')return f?0:EBADF;var F=fs.files[f.path];var o=Number(off);
      f.pos=wh===0?o:wh===1?f.pos+o:F.data.length+o;if(f.pos<0)f.pos=0;V().setBigUint64(pn,BigInt(f.pos),true);return 0;},
    fd_tell:function(fd,pn){var f=fds[fd];if(!f)return EBADF;V().setBigUint64(pn,BigInt(f.pos||0),true);return 0;},
    fd_sync:function(){fs.save();return 0;},fd_datasync:function(){fs.save();return 0;},
    fd_readdir:function(fd,buf,len,cookie,pu){if(arguments.length>=6){cookie=(arguments[3]>>>0)+arguments[4]*4294967296;pu=arguments[5];}var f=fds[fd];if(!f||f.t!=='dir')return EBADF;var names=['.','..'].concat(Object.keys(fs.files));var v=V(),u=U(),pos=0,c=Number(cookie);
      for(var i=c;i<names.length;i++){var nb=enc.encode(names[i]);var rec=new Uint8Array(24+nb.length),rv=new DataView(rec.buffer);rv.setBigUint64(0,BigInt(i+1),true);rv.setBigUint64(8,BigInt(i+1),true);rv.setUint32(16,nb.length,true);rv.setUint8(20,i<2?3:4);rec.set(nb,24);
        var k=Math.min(rec.length,len-pos);u.set(rec.subarray(0,k),buf+pos);pos+=k;if(pos>=len)break;}
      v.setUint32(pu,pos,true);return 0;},
    path_unlink_file:function(dfd,p,l){var n=pth(p,l);if(!fs.files[n])return ENOENT;delete fs.files[n];fs.save();return 0;},
    path_remove_directory:function(){return ENOTDIR;},
    path_rename:function(a,p1,l1,b,p2,l2){var x=pth(p1,l1),y=pth(p2,l2);if(!fs.files[x])return ENOENT;fs.files[y]=fs.files[x];delete fs.files[x];fs.save();return 0;},
    path_create_directory:function(){return 0;}
  };
};
BrogueApp.prototype.args=function(){var a=['brogue'];if(this.o.graphics)a.push('-G');return a;};

/* ---------------- rendering ---------------- */
BrogueApp.prototype.tile=function(s){ // white tile mask at current cell size
  var key=s;if(this.tileCache[key])return this.tileCache[key];
  var i=s-256,col=i%16,row=Math.floor(i/16),c=document.createElement('canvas');c.width=this.cw;c.height=this.ch;var x=c.getContext('2d');
  x.imageSmoothingQuality='high';x.drawImage(this.tilesImg,col*48,row*87,48,87,0,0,this.cw,this.ch);this.tileCache[key]=c;return c;};
// kid sprite at the current cell size: {fix, tint}
BrogueApp.prototype.kidTile=function(i){var K=this.kid,e=K.cache[i];if(e)return e;
  var cut=function(img){var c=document.createElement('canvas');c.width=this.cw;c.height=this.ch;var x=c.getContext('2d');x.imageSmoothingQuality='high';x.drawImage(img,(i%16)*64,Math.floor(i/16)*112,64,112,0,0,this.cw,this.ch);return c;}.bind(this);
  e=K.cache[i]={fix:cut(K.fix),tint:K.tint[i]?cut(K.tin):null};return e;};
BrogueApp.prototype.drawCell=function(i){
  var c=this.cells[i],x=(i%COLS)*this.cw,y=Math.floor(i/COLS)*this.ch,g=this.octx,K=this.kid;
  g.fillStyle=c.b;g.fillRect(x,y,this.cw,this.ch);
  if(K&&c.s>=256&&K.has[c.s-256]&&K.fix&&K.tin){
    var k=c.s-256,fm=c.fm||100,mx=K.seen[k]=Math.max(K.seen[k]||0,fm);c.L=Math.max(k===22?0.6:0.32,Math.min(1,fm/mx));
    var cx=i%COLS,cy=Math.floor(i/COLS);c.big=K.on&&K.big[k]&&cx>SBW&&cy>=MSGL&&cy<ROWS-2;
    if(c.big){c.d=false;return;}
    var e=this.kidTile(k);
    if(e.tint){var sc=this.scratch||(this.scratch=document.createElement('canvas'));if(sc.width!==this.cw||sc.height!==this.ch){sc.width=this.cw;sc.height=this.ch;}
      var sx=sc.getContext('2d');sx.globalCompositeOperation='copy';sx.drawImage(e.tint,0,0);sx.globalCompositeOperation='source-in';sx.fillStyle=c.f;sx.fillRect(0,0,this.cw,this.ch);g.drawImage(sc,x,y);}
    // Brogue dims what is out of the light or only remembered: follow it by fading the sprite toward the floor
    g.globalAlpha=c.L;g.drawImage(e.fix,x,y);g.globalAlpha=1;
  }else if((c.big=false),c.s>=256&&this.tilesImg){
    var t=this.tile(c.s),sc=this.scratch||(this.scratch=document.createElement('canvas'));if(sc.width!==this.cw||sc.height!==this.ch){sc.width=this.cw;sc.height=this.ch;}
    var sx=sc.getContext('2d');sx.globalCompositeOperation='copy';sx.drawImage(t,0,0);sx.globalCompositeOperation='source-in';sx.fillStyle=c.f;sx.fillRect(0,0,this.cw,this.ch);
    g.drawImage(sc,x,y);
  }else if(c.u&&c.u!==32){
    g.fillStyle=c.f;g.font=this.font;g.textAlign='center';g.textBaseline='middle';
    g.fillText(String.fromCodePoint(c.u),x+this.cw/2,y+this.ch*0.54);
  }
  c.d=false;
};
BrogueApp.prototype.raf=function(){var self=this;
  this.font=Math.round(this.ch*0.78)+'px "DejaVu Sans Mono","Menlo","Consolas","Roboto Mono",monospace';
  var loop=function(){
    if(self.dead)return;
    if(self.kid)self.kidSync();
    if(self.dirty||self.allDirty){var all=self.allDirty;for(var i=0;i<self.cells.length;i++)if(all||self.cells[i].d)self.drawCell(i);self.dirty=false;self.allDirty=false;self.present();}
    else if(self.needPresent)self.present();
    if(self.zoomSusp){try{if(self.ex.wasm_turn()!==self.suspTurn)self.resumeZoom();}catch(e){}}
    if(self.zoom>1&&!self.zoomSusp){try{var pxy=self.ex.wasm_player_x()*1000+self.ex.wasm_player_y();if(pxy!==self.lastPxy){self.lastPxy=pxy;self.needPresent=true;}}catch(e){}}
    requestAnimationFrame(loop);};
  requestAnimationFrame(loop);};
// what part of the console goes where on screen: fit = whole console; zoom = messages strip + close-up map + bottom strip
BrogueApp.prototype.inGame=function(){if(this.onTitle)return false;try{return this.ex.wasm_depth()>0;}catch(e){return false;}};
BrogueApp.prototype.regions=function(){
  var W=this.canvas.width,H=this.canvas.height,cw=this.cw,ch=this.ch,ow=this.off.width,oh=this.off.height;
  var z=(this.zoomSusp||!this.inGame())?1:this.zoom; // title, saved-game list and other start-up screens show whole
  if(z<=1){var s=Math.min(W/ow,H/oh),dw=ow*s,dh=oh*s;return [{sx:0,sy:0,sw:ow,sh:oh,dx:(W-dw)/2,dy:(H-dh)/2,dw:dw,dh:dh}];}
  var mc=COLS-SBW,sm=Math.min(W/(mc*cw),0.15*H/(MSGL*ch)),stripW=mc*cw*sm,sx0=(W-stripW)/2;
  // the kid look leaves out Brogue's own bottom strip (tiny text buttons): the page has big ones instead
  var ht=MSGL*ch*sm,hb=this.kid?0:2*ch*sm,R=[];
  R.push({sx:SBW*cw,sy:0,sw:mc*cw,sh:MSGL*ch,dx:sx0,dy:0,dw:stripW,dh:ht,strip:1});
  if(hb)R.push({sx:SBW*cw,sy:(ROWS-2)*ch,sw:mc*cw,sh:2*ch,dx:sx0,dy:H-hb,dw:stripW,dh:hb,strip:1});
  var s0=Math.min(W/ow,H/oh),s1=s0*z,mh=H-ht-hb,sw=W/s1,sh=mh/s1;
  var px=(SBW+1+40)*cw,py=(MSGL+14)*ch;try{px=(this.ex.wasm_player_x()+SBW+1+0.5)*cw;py=(this.ex.wasm_player_y()+MSGL+0.5)*ch;}catch(e){}
  var minx=SBW*cw,maxx=COLS*cw,miny=MSGL*ch,maxy=(ROWS-2)*ch;
  // a screen wider or taller than the whole map shows just the map, centred (never the message rows again)
  var dx=0,dw=W,dy=ht,dh=mh,sx,sy;
  if(sw>=maxx-minx){dw=(maxx-minx)*s1;dx=(W-dw)/2;sw=maxx-minx;sx=minx;}else sx=Math.max(minx,Math.min(maxx-sw,px-sw/2));
  if(sh>=maxy-miny){dh=(maxy-miny)*s1;dy=ht+(mh-dh)/2;sh=maxy-miny;sy=miny;}else sy=Math.max(miny,Math.min(maxy-sh,py-sh/2));
  R.push({sx:sx,sy:sy,sw:sw,sh:sh,dx:dx,dy:dy,dw:dw,dh:dh});
  return R;};
BrogueApp.prototype.kidSync=function(){var K=this.kid;if(!K)return;var on=this.zoom>1&&!this.zoomSusp&&this.inGame();if(on===K.on)return;K.on=on;
  for(var i=0;i<this.cells.length;i++){var c=this.cells[i];if(c.s>=256&&K.has[c.s-256]){c.d=true;this.dirty=true;}}};
// close-up view: characters and items drawn half again bigger than their cell, standing on it, nearer rows in front
BrogueApp.prototype.kidBig=function(g,r){var K=this.kid,cw=this.cw,ch=this.ch,kx=r.dw/r.sw,ky=r.dh/r.sh;
  var x0=Math.max(SBW+1,Math.floor(r.sx/cw)-1),x1=Math.min(COLS-1,Math.ceil((r.sx+r.sw)/cw)+1),y0=Math.max(MSGL,Math.floor(r.sy/ch)),y1=Math.min(ROWS-3,Math.ceil((r.sy+r.sh)/ch)+1);
  var sc=this.bigScratch||(this.bigScratch=document.createElement('canvas'));sc.width=64;sc.height=112;var sx=sc.getContext('2d');
  for(var y=y0;y<=y1;y++)for(var x=x0;x<=x1;x++){var c=this.cells[y*COLS+x];if(!c.big)continue;
    var k=c.s-256,ax=(k%16)*64,ay=Math.floor(k/16)*112,w=cw*kx,h=ch*ky,dx=r.dx+(x*cw-r.sx)*kx,dy=r.dy+(y*ch-r.sy)*ky,bw=w*1.5,bh=h*1.5,bx=dx+w/2-bw/2,by=dy+h*1.02-bh;
    if(K.tint[k]){sx.globalCompositeOperation='copy';sx.drawImage(K.tin,ax,ay,64,112,0,0,64,112);sx.globalCompositeOperation='source-in';sx.fillStyle=c.f;sx.fillRect(0,0,64,112);g.drawImage(sc,0,0,64,112,bx,by,bw,bh);}
    g.globalAlpha=c.L||1;g.drawImage(K.fix,ax,ay,64,112,bx,by,bw,bh);g.globalAlpha=1;}};
BrogueApp.prototype.present=function(){
  var W=this.canvas.width,H=this.canvas.height,g=this.ctx;this.needPresent=false;
  var R=this.regions();g.fillStyle='#000';g.fillRect(0,0,W,H);g.imageSmoothingEnabled=true;
  for(var i=R.length-1;i>=0;i--){var r=R[i];g.save();g.beginPath();g.rect(r.dx,r.dy,r.dw,r.dh);g.clip();g.drawImage(this.off,r.sx,r.sy,r.sw,r.sh,r.dx,r.dy,r.dw,r.dh);
    if(this.kid&&this.kid.on&&!r.strip&&this.kid.fix&&this.kid.tin)this.kidBig(g,r);g.restore();
    if(r.strip){g.fillStyle='rgba(255,255,255,.12)';g.fillRect(0,r.dy===0?r.dh:r.dy-1,W,1);}}
  this.R=R;};
BrogueApp.prototype.cellAt=function(cx,cy){
  var R=this.R;if(!R)return null;
  for(var i=0;i<R.length;i++){var r=R[i];if(cx>=r.dx&&cx<r.dx+r.dw&&cy>=r.dy&&cy<r.dy+r.dh){
    var ox=r.sx+(cx-r.dx)*r.sw/r.dw,oy=r.sy+(cy-r.dy)*r.sh/r.dh,x=Math.floor(ox/this.cw),y=Math.floor(oy/this.ch);
    if(x<0||y<0||x>=COLS||y>=ROWS)return null;return {x:x,y:y};}}
  return null;};
BrogueApp.prototype.suspendZoom=function(){if(this.zoom>1){this.zoomSusp=true;try{this.suspTurn=this.ex.wasm_turn();}catch(e){}this.needPresent=true;}};
BrogueApp.prototype.resumeZoom=function(){if(this.zoomSusp){this.zoomSusp=false;this.needPresent=true;}};
BrogueApp.prototype.setZoom=function(z){this.zoom=z;this.zoomSusp=false;this.needPresent=true;};

/* ---------------- input ---------------- */
BrogueApp.prototype.bindInput=function(){
  var self=this,cv=this.canvas,down=null,lp=null;
  function pt(e){var r=cv.getBoundingClientRect();return self.cellAt((e.clientX-r.left)*cv.width/r.width,(e.clientY-r.top)*cv.height/r.height);}
  cv.addEventListener('pointerdown',function(e){e.preventDefault();var c=pt(e);if(!c)return;down={c:c,t:Date.now(),x:e.clientX,y:e.clientY,long:false};self.hover(c.x,c.y);
    lp=setTimeout(function(){if(down){down.long=true;if(navigator.vibrate)try{navigator.vibrate(15);}catch(x){}}},450);});
  cv.addEventListener('pointermove',function(e){if(e.pointerType==='mouse'&&!down){var c=pt(e);if(c&&(!self.lastHover||self.lastHover.x!==c.x||self.lastHover.y!==c.y)){self.lastHover=c;self.hover(c.x,c.y);}return;}
    if(down){var c2=pt(e);if(c2&&(c2.x!==down.c.x||c2.y!==down.c.y)){down.c=c2;self.hover(c2.x,c2.y);}}});
  function up(e){clearTimeout(lp);if(!down)return;var d=down;down=null;if(d.long)return; /* long press = look only */ self.push([2,d.c.x,d.c.y,0,0]);self.push([1,d.c.x,d.c.y,0,0]);}
  cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',function(){clearTimeout(lp);down=null;});
  cv.addEventListener('contextmenu',function(e){e.preventDefault();});
  this.onKey=function(e){
    if(self.o.keyTarget&&!self.o.keyTarget())return;
    var t=e.target;if(t&&(t.tagName==='INPUT'||t.tagName==='TEXTAREA'||t.isContentEditable))return; // typing a name
    if(e.key==='Shift'){self.mods.shift=e.type==='keydown';return;}if(e.key==='Control'){self.mods.ctrl=e.type==='keydown';return;}
    if(e.type!=='keydown')return;
    if(e.metaKey||e.altKey)return; // leave browser and system shortcuts alone
    var map={ArrowUp:63232,ArrowDown:63233,ArrowLeft:63234,ArrowRight:63235,Enter:10,Escape:27,Backspace:127,Tab:9,Delete:127};
    var k=map[e.key];
    if(e.code&&e.code.indexOf('Numpad')===0){var np={Home:55,End:49,PageUp:57,PageDown:51,Clear:53,Insert:48,Enter:10};if(np[e.key]!==undefined)k=np[e.key];}
    if(k===undefined){if(e.key.length===1)k=e.key.charCodeAt(0);else return;}
    if(e.key==='Tab'&&e.shiftKey)k=25;
    if(e.ctrlKey&&e.key.length===1)k=(e.shiftKey?e.key.toUpperCase():e.key.toLowerCase()).charCodeAt(0);
    e.preventDefault();
    if(e.repeat&&self.queue.length>1)return; // a held key should not pile up moves after it is let go
    if(self.zoom>1&&!e.ctrlKey&&'iaertdcRMDF?~QS'.indexOf(String.fromCharCode(k))>=0)self.suspendZoom();
    if(k===27)setTimeout(function(){self.resumeZoom();},250);
    self.key(k,e.shiftKey,e.ctrlKey);};
  this.onBlur=function(){self.mods.shift=false;self.mods.ctrl=false;};window.addEventListener('blur',this.onBlur);
  window.addEventListener('keydown',this.onKey);window.addEventListener('keyup',this.onKey);
};
window.BrogueApp=BrogueApp;
})();
