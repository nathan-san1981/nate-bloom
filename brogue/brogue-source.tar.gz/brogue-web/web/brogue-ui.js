/* Touch-first shell around BrogueApp: d-pad, action buttons, zoom, text entry, help. */
(function(){
'use strict';
var CSS=`
.bq [hidden]{display:none!important}
.bq{position:absolute;top:0;right:0;bottom:0;left:0;background:#000;overflow:hidden;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;-webkit-user-select:none;user-select:none;touch-action:none}
.bq canvas{position:absolute;left:0;top:0;touch-action:none}
.bq .bq-col{position:absolute;display:flex;flex-direction:column;gap:8px;z-index:3}
.bq .bq-b{width:var(--bs,58px);height:var(--bs,58px);border-radius:16px;border:2px solid rgba(255,255,255,.35);background:rgba(20,22,40,.72);color:#fff;font-size:15px;font-weight:700;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;padding:0;line-height:1;touch-action:none;backdrop-filter:blur(3px)}
.bq .bq-b small{font-size:10px;font-weight:600;opacity:.8}
.bq .bq-b:active,.bq .bq-b.on{background:rgba(120,90,220,.85);border-color:#fff}
.bq .bq-b .ic{font-size:22px}
.bq .bq-b.exit{background:#C2367E;border-color:#fff;box-shadow:0 4px 0 #8C1F59}.bq .bq-b.exit small{opacity:1;font-size:13px;font-weight:800}
.bq .bq-b.restart{border-color:rgba(255,190,120,.7)}
.bq .bq-row button.danger{background:#B8321F;border-color:#E8766A}
.bq .bq-pad{position:absolute;z-index:3;display:grid;grid-template-columns:repeat(3,var(--ps,56px));grid-template-rows:repeat(3,var(--ps,56px));gap:4px;opacity:.92}
.bq .bq-pad button{border-radius:14px;border:2px solid rgba(255,255,255,.3);background:rgba(20,22,40,.6);color:#fff;font-size:22px;font-weight:700;padding:0;touch-action:none}
.bq .bq-pad button:active{background:rgba(120,90,220,.85)}
.bq .bq-pad .run{font-size:12px}
.bq .bq-pad .run.on{background:rgba(220,120,60,.85)}
.bq .bq-sheet{position:absolute;top:0;right:0;bottom:0;left:0;z-index:6;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center}
.bq .bq-sheet[hidden]{display:none}
.bq .bq-card{background:#16182c;color:#eee;border:2px solid #4a4f80;border-radius:20px;padding:16px 18px;max-width:min(760px,94%);max-height:90%;overflow:auto}
.bq .bq-card h3{margin:0 0 10px;font-size:19px}
.bq .bq-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(112px,1fr));gap:8px}
.bq .bq-grid button{height:56px;border-radius:14px;border:2px solid #4a4f80;background:#23264a;color:#fff;font-size:14px;font-weight:700;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px}
.bq .bq-grid button small{font-weight:500;opacity:.7;font-size:11px}
.bq .bq-row{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
.bq .bq-row button{height:48px;padding:0 16px;border-radius:14px;border:2px solid #4a4f80;background:#2f3366;color:#fff;font-size:15px;font-weight:700}
.bq .bq-help{font-size:14px;line-height:1.45;color:#cfd2ee}
.bq .bq-help b{color:#fff}
.bq .bq-keys{border-collapse:collapse;width:100%;margin:2px 0 8px}.bq .bq-keys td{padding:3px 6px;vertical-align:top;border-bottom:1px solid rgba(255,255,255,.08)}.bq .bq-keys td:first-child{white-space:nowrap}
.bq kbd{font:600 13px ui-monospace,Menlo,Consolas,monospace;color:#ffe08a}
.bq .bq-text{position:absolute;left:50%;top:10px;transform:translateX(-50%);z-index:7;display:flex;gap:6px;background:#16182c;border:2px solid #7a6fe0;border-radius:14px;padding:6px}
.bq .bq-text[hidden]{display:none}
.bq .bq-text input{font-size:18px;width:240px;border:none;border-radius:8px;padding:8px;background:#0c0d1a;color:#fff}
.bq .bq-text button{border:none;border-radius:10px;background:#7a6fe0;color:#fff;font-weight:700;padding:0 14px;font-size:16px}
.bq .bq-title{position:absolute;z-index:4;display:flex;flex-wrap:wrap;justify-content:center;align-items:center;gap:10px;pointer-events:none;transform:translateX(-50%)}
.bq .bq-title button{pointer-events:auto;min-height:50px;padding:0 20px;border-radius:16px;border:2px solid rgba(255,255,255,.45);background:rgba(22,24,48,.86);color:#fff;font:700 17px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;backdrop-filter:blur(4px)}
.bq .bq-title button.main{min-height:60px;font-size:21px;padding:0 30px;background:#6d4fd8;border-color:#fff}
.bq .bq-title button:active{background:#8c70f0}
.bq .bq-title button.kidplay{min-height:76px;font-size:26px;padding:0 36px;background:#C2367E;border-color:#fff;box-shadow:0 5px 0 #8C1F59}
.bq .bq-menu{position:absolute;z-index:5;display:flex;flex-direction:column;gap:6px;padding:8px;overflow-y:auto;-webkit-overflow-scrolling:touch;touch-action:pan-y;background:rgba(14,15,32,.94);border:2px solid #4a4f80;border-radius:18px;box-sizing:border-box}
.bq .bq-menu button{flex:none;min-height:46px;text-align:left;padding:6px 12px;border-radius:12px;border:2px solid #3d4275;background:#23264a;color:#fff;font:600 16px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;line-height:1.25;touch-action:manipulation}
.bq .bq-menu button:active{background:#5b48c4}
.bq .bq-menu button[disabled]{opacity:.4}
.bq .bq-menu button.cancel{text-align:center;background:#3a2238;border-color:#6b3d5f}
.bq .bq-turn{position:absolute;left:50%;top:8px;transform:translateX(-50%);z-index:4;background:rgba(22,24,48,.9);color:#fff;border:1px solid #4a4f80;border-radius:12px;padding:6px 12px;font:600 14px system-ui,-apple-system,sans-serif;pointer-events:none;white-space:nowrap}
.bq .bq-bub{position:absolute;z-index:3;left:50%;transform:translateX(-50%);max-width:min(560px,70%);max-height:38%;overflow:hidden;box-sizing:border-box;padding:10px 16px 12px;border-radius:18px;background:rgba(36,24,64,.94);border:2px solid #B9A4F2;color:#fff;font:500 15px/1.35 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;white-space:pre-line;pointer-events:none;box-shadow:0 6px 18px rgba(0,0,0,.4);-webkit-mask-image:linear-gradient(#000 80%,transparent);mask-image:linear-gradient(#000 80%,transparent)}
.bq .bq-bub b{display:block;font-size:17px;color:#FFD45C;margin-bottom:2px}
.bq .bq-load{position:absolute;top:0;right:0;bottom:0;left:0;display:flex;align-items:center;justify-content:center;color:#ccc;font-size:18px;z-index:2}
.bq .bq-pad button.held{background:rgba(120,90,220,.95);border-color:#fff}
/* ---- kid look: few, big, picture-first buttons ---- */
.bq.kid .bq-col{gap:10px}
.bq.kid .bq-b{width:var(--kw,132px);height:var(--ku,64px);border-radius:20px;border-width:3px;background:rgba(36,28,72,.86)}
.bq.kid .bq-b .ic{font-size:30px}.bq.kid .bq-b small{font-size:15px;font-weight:800;opacity:1;margin-top:2px}
.bq.kid .bq-b.xl{height:calc(var(--ku,64px)*2);background:#7B4FD8;border-color:#fff;box-shadow:0 5px 0 #4B2E99}
.bq.kid .bq-b.xl .ic{font-size:66px;line-height:1}.bq.kid .bq-b.xl small{font-size:22px}
.bq.kid .bq-b.lg{height:calc(var(--ku,64px)*1.35)}.bq.kid .bq-b.lg .ic{font-size:40px}.bq.kid .bq-b.lg small{font-size:17px}
.bq.kid .bq-b.exit small{font-size:15px}
.bq.kid .bq-b.sm{width:56px;height:56px;border-radius:16px}.bq.kid .bq-b.sm .ic{font-size:24px}.bq.kid .bq-b.sm small{font-size:11px}
.bq.kid .bq-pad{gap:6px;opacity:.95}
.bq.kid .bq-pad button{font-size:34px;border-width:3px;border-radius:18px;background:rgba(36,28,72,.72)}
.bq.kid .bq-pad button.dg{font-size:24px;opacity:.75}
.bq.kid .bq-pad button.rest{font-size:28px;background:rgba(60,52,110,.8)}
.bq.kid .bq-pad button.rest.glow{background:#2E8B57;border-color:#9BF0A8;animation:bqbeat 1.1s ease-in-out infinite}
.bq.kid .bq-menu{gap:8px;padding:10px}
.bq.kid .bq-menu button{min-height:62px;font-size:20px;font-weight:700;border-radius:16px;padding:8px 14px}
.bq.kid .bq-menu button.yes{background:#2E8B57;border-color:#9BF0A8;font-size:22px}
.bq.kid .bq-menu button.no{background:#5a3a6e;border-color:#c9a2e6;font-size:22px}
.bq .bq-q{display:flex;align-items:center;gap:10px;color:#fff;font:800 20px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;padding:6px 4px 8px;cursor:pointer}
.bq .bq-q .spk{flex:none;display:flex;align-items:center;justify-content:center;width:44px;height:44px;border-radius:22px;background:rgba(123,79,216,.9);border:2px solid #fff;font-size:22px}
.bq.kid .bq-menu button.pic{display:flex;align-items:center;gap:12px;padding-left:8px}
.bq.kid .bq-menu button canvas.pic{position:static;width:32px;height:56px;flex:none;filter:drop-shadow(0 2px 2px rgba(0,0,0,.5))}
.bq .bq-life .fl{color:#FFD45C;font:800 15px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;white-space:nowrap}
.bq .bq-life{position:absolute;z-index:3;display:flex;align-items:center;gap:8px;height:46px;box-sizing:border-box;padding:0 14px 0 8px;border-radius:23px;background:rgba(28,18,48,.88);border:3px solid rgba(255,255,255,.55);pointer-events:none}
.bq .bq-life .h{font-size:28px;line-height:1;filter:drop-shadow(0 1px 0 rgba(0,0,0,.4))}
.bq .bq-life .bar{flex:1;height:20px;border-radius:10px;background:rgba(255,255,255,.16);overflow:hidden;box-shadow:inset 0 2px 3px rgba(0,0,0,.45)}
.bq .bq-life .bar i{display:block;height:100%;width:100%;border-radius:10px;background:#5BD66B;transition:width .35s ease,background-color .35s}
.bq .bq-life .n{color:#fff;font:800 15px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;min-width:58px;text-align:right;opacity:.85}
.bq .bq-life.low .h{animation:bqbeat .7s ease-in-out infinite}
.bq .bq-life.hurt{animation:bqshake .45s;border-color:#FF6B8A}
.bq .bq-life.heal{border-color:#9BF0A8}
@keyframes bqbeat{0%,100%{transform:scale(1)}50%{transform:scale(1.28)}}
@keyframes bqshake{0%,100%{transform:translateX(0)}20%{transform:translateX(-7px)}40%{transform:translateX(6px)}60%{transform:translateX(-4px)}80%{transform:translateX(3px)}}
.bq .bq-say{position:absolute;z-index:3;cursor:pointer;touch-action:manipulation}
.bq .bq-say .spk{position:absolute;right:6px;top:50%;transform:translateY(-50%);display:flex;align-items:center;justify-content:center;width:44px;height:44px;border-radius:22px;background:rgba(123,79,216,.9);border:2px solid #fff;font-size:22px;line-height:1;box-shadow:0 3px 0 #4B2E99}
.bq .bq-say.talk .spk{animation:bqbeat .6s ease-in-out infinite}
.bq .bq-say.talk{background:rgba(185,164,242,.14);border-radius:12px}
.bq .bq-kgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(132px,1fr));gap:10px;margin-bottom:14px}
.bq .bq-kgrid button{height:84px;border-radius:18px;border:3px solid #6a5fc0;background:#2c2860;color:#fff;font:800 16px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px}
.bq .bq-kgrid button .ic{font-size:30px;line-height:1}
.bq .bq-kgrid button.on{background:#6d4fd8;border-color:#fff}
.bq .bq-card h4{margin:6px 0 8px;font-size:14px;color:#aab;font-weight:700;text-transform:uppercase;letter-spacing:.06em}
`;
function el(tag,cls,html){var e=document.createElement(tag);if(cls)e.className=cls;if(html!=null)e.innerHTML=html;return e;}
function mount(host,opts){
  if(!document.getElementById('bq-css')){var st=el('style');st.id='bq-css';st.textContent=CSS;document.head.appendChild(st);}
  var root=el('div','bq');host.appendChild(root);
  var cv=el('canvas');root.appendChild(cv);var load=el('div','bq-load','Opening the dungeon…');root.appendChild(load);
  var app=new BrogueApp({canvas:cv,wasmB64:opts.wasmB64,tilesB64:opts.tilesB64,storageKey:opts.storageKey||'brogue.fs',graphics:opts.graphics!==false,kid:opts.kid||null,zoom:opts.kid?2.6:1,
    keyTarget:opts.keyTarget,onExit:function(){load.textContent='Thanks for playing! Reload to play again.';load.hidden=false;},
    onTextInput:function(on){if(kidSeeding&&on)return;txt.hidden=!on;if(on){inp.value='';setTimeout(function(){try{inp.focus();}catch(e){}},50);}},
    onError:function(e){load.hidden=false;load.textContent='Something went wrong: '+e;},
    onTitle:function(on){showTitle(on);},onBubble:opts.kid?function(b){showBubble(b);}:null,onMenu:function(items,win){showMenu(items,win);},onMenuClose:function(){hideMenu();},
    onMessage:function(t,f){gotMessage(t,f);}});
  if(opts.kid)root.classList.add('kid');
  // ---- what just happened: the newest messages (those that came together), read aloud when the text is tapped ----
  var lastMsgs=[],lastMsgT=0,question=null;
  function gotMessage(t,f){t=String(t||'').replace(/\s+/g,' ').trim();if(!t)return;var now=Date.now();
    if(f&0x40000000){question={t:t,at:now};lastMsgs=[t];lastMsgT=now;return;}   // a Yes / No question: shown with its buttons
    if(/^(Exploring|Playing|Travell?ing|Resting|Searching)\b.*(press|touch)/i.test(t)||/^Press .* for help/i.test(t))return;   // "press any key" and help-key notes
    if(now-lastMsgT>900)lastMsgs=[];lastMsgT=now;if(lastMsgs.indexOf(t)<0)lastMsgs.push(t);if(lastMsgs.length>4)lastMsgs.shift();
    if(opts.onMessage)opts.onMessage(t,f);}
  // the words as a child would hear them: no item letters, counts in brackets, or made-up scroll titles
  function spoken(t){return String(t).replace(/--MORE--/g,'').replace(/\s*\([a-z]\)/g,'').replace(/<[^>]*>/g,'').replace(/\s+entitled\s+["“][^"”]*["”]/gi,'')
    .replace(/\s*\[[^\]]*\]/g,'').replace(/\s*\((?:press|touch|tap|hit)[^)]*\)/gi,'').replace(/(^|\s)[+-]\d+(?=\s)/g,'$1').replace(/\s{2,}/g,' ').replace(/\s+([.,!?;:])/g,'$1').trim();}
  var talkOn=true;try{talkOn=localStorage.getItem((opts.storageKey||'brogue')+'.talk')!=='0';}catch(e){}
  function speak(t){t=spoken(t);if(!t)return false;
    if(opts.say){try{return opts.say(t)!==false;}catch(e){}}
    try{var ss=window.speechSynthesis;if(!ss)return false;ss.cancel();var u=new SpeechSynthesisUtterance(t),vs=ss.getVoices(),pick=null;
      ['Samantha','Ava','Allison','Google US English','Microsoft Aria','Microsoft Jenny','Karen','Moira'].some(function(n){return vs.some(function(v){if(v.name.indexOf(n)>=0&&/^en/i.test(v.lang)){pick=v;return true;}return false;});});
      if(!pick)vs.some(function(v){if(/^en[-_]US/i.test(v.lang)){pick=v;return true;}return false;});if(pick)u.voice=pick;u.rate=0.95;u.pitch=1.05;ss.speak(u);return true;}catch(e){return false;}}
  var say=el('div','bq-say','<span class="spk" aria-hidden="true">🔊</span>');say.hidden=true;say.title='Tap to hear what just happened';root.appendChild(say);
  say.addEventListener('pointerdown',function(e){e.preventDefault();e.stopPropagation();if(!lastMsgs.length)return;
    speak(lastMsgs.join(' '));say.classList.add('talk');clearTimeout(say._t);say._t=setTimeout(function(){say.classList.remove('talk');},Math.min(9000,1200+lastMsgs.join(' ').length*65));});
  app.lastMessages=function(){return lastMsgs.slice();};app.spoken=spoken;
  // ---- kid view: hover details as a bubble (Brogue sends them here while zoomed in) ----
  var bub=el('div','bq-bub');bub.hidden=true;root.appendChild(bub);
  function showBubble(b){if(!b){bub.hidden=true;return;}bub.innerHTML='';var ti=String(b.title||''),tx=String(b.text||'').trim(),nl=tx.indexOf('\n');
    if(nl>0&&tx.slice(0,nl).trim().toLowerCase()===ti.trim().toLowerCase())tx=tx.slice(nl).trim();
    var t=el('b');t.textContent=ti.charAt(0).toUpperCase()+ti.slice(1);bub.appendChild(t);bub.appendChild(document.createTextNode(tx.replace(/\n{3,}/g,'\n\n')));
    var R=app.R,top=8;if(R&&R.length>1)top=Math.round(R[0].dh/(app.canvas.height/(cv.clientHeight||1)))+cv.offsetTop+8;bub.style.top=top+'px';bub.hidden=false;}
  root.addEventListener('pointerdown',function(){bub.hidden=true;},true);window.addEventListener('keydown',function(){bub.hidden=true;},true);
  // ---- controls ----
  var K=function(c){return typeof c==='string'?c.charCodeAt(0):c;};
  var right=el('div','bq-col'),left=el('div','bq-col');root.appendChild(right);root.appendChild(left);
  function B(parent,label,small,fn,title){var b=el('button','bq-b','<span class="ic">'+label+'</span>'+(small?'<small>'+small+'</small>':''));b.title=title||small||'';
    b.addEventListener('pointerdown',function(e){e.preventDefault();e.stopPropagation();fn(b);});parent.appendChild(b);return b;}
  var zooms=opts.kid?[1,1.8,2.6,3.4]:[1,1.8,2.6],zi=opts.kid?2:0,run=false;
  if(opts.onBack){var exitBtn=B(right,'<svg width="26" height="26" viewBox="0 0 26 26" aria-hidden="true"><path d="M11 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h5" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/><path d="M16 8l5 5-5 5M21 13H10" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>','Exit',function(){opts.onBack();},'Back to the clock');exitBtn.classList.add('exit');}
  function zoomStep(){zi=(zi+1)%zooms.length;app.setZoom(zooms[zi]);zoomBtn.querySelector('small').textContent=zi?('×'+zooms[zi]):'Zoom';zoomBtn.classList.toggle('on',zi>0);}
  var backBtn=B(right,'✕','Back',function(){app.key(27);setTimeout(function(){app.resumeZoom();},250);},'Escape / cancel');
  var okBtn=B(right,'✓','OK',function(){app.key(10);},'Enter / confirm');
  var packBtn=B(right,'🎒','Pack',function(){if(opts.kid&&!menu.hidden){app.key(27);return;}app.suspendZoom();app.key(K('i'));},'Inventory (i)');
  var exploreBtn=B(right,'🧭','Explore',function(){app.key(K('x'));},'Auto-explore (x)');
  var stairsBtn=B(right,'⬇','Stairs',function(){app.key(K('>'));},'Travel to the down stairs (>)');
  var zoomBtn=B(right,'🔍','Zoom',function(){zoomStep();},'Zoom in on your hero');
  var moreBtn=B(right,'⋯','More',function(){card.hidden=false;helpCard.hidden=true;sheet.hidden=false;},'All actions');
  var searchBtn=B(left,'🔎','Search',function(){app.key(K('s'));},'Search (s), press 5 times to search hard');
  var restBtn=B(left,'💤','Rest',function(){app.key(K('z'));},'Rest one turn (z)');
  var padBtn=B(left,'✥','Pad',function(b){pad.hidden=!pad.hidden;b.classList.toggle('on',!pad.hidden);try{localStorage.setItem('brogue.pad',pad.hidden?'0':'1');}catch(e){}layout();},'Show the direction pad');
  if(zi){zoomBtn.querySelector('small').textContent='×'+zooms[zi];zoomBtn.classList.add('on');}
  if(opts.kid){
    // a five-year-old's set: Pack big, Explore and Stairs large, Back and More plain; the rest lives in More
    packBtn.classList.add('xl');exploreBtn.classList.add('lg');stairsBtn.classList.add('lg');
    [okBtn,zoomBtn,searchBtn,restBtn,padBtn].forEach(function(b){b.parentNode.removeChild(b);});
    right.insertBefore(packBtn,backBtn);right.insertBefore(exploreBtn,backBtn);right.insertBefore(stairsBtn,backBtn);right.appendChild(moreBtn);}
  // ---- dungeon music (kid look): a theme per group of floors, a jingle on each new floor, on/off button ----
  var mus=null;
  if(opts.music&&window.BrogueMusic){
    mus=BrogueMusic.create({audio:opts.audio,key:(opts.storageKey||'brogue')+'.music'});
    var NOTE_ON='<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 18V6l11-2v12" fill="none" stroke="#fff" stroke-width="2.2" stroke-linejoin="round"/><circle cx="6.5" cy="18" r="2.8" fill="#fff"/><circle cx="17.5" cy="16" r="2.8" fill="#fff"/></svg>';
    var NOTE_OFF='<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 18V6l11-2v12" fill="none" stroke="#9a96b8" stroke-width="2.2" stroke-linejoin="round"/><circle cx="6.5" cy="18" r="2.8" fill="#9a96b8"/><circle cx="17.5" cy="16" r="2.8" fill="#9a96b8"/><path d="M3 3l18 18" stroke="#ff8fb8" stroke-width="2.4" stroke-linecap="round"/></svg>';
    var musBtn=B(left,mus.isOn()?NOTE_ON:NOTE_OFF,'Music',function(b){mus.setOn(!mus.isOn());b.querySelector('.ic').innerHTML=mus.isOn()?NOTE_ON:NOTE_OFF;b.classList.toggle('on',mus.isOn());if(mus.isOn())musTick();},'Music on or off');
    musBtn.classList.toggle('on',mus.isOn());app.music=mus;if(opts.kid)musBtn.classList.add('sm');
    var lastDepth=0,wasTitle=true;
    var musTick=function(){
      if(app.dead){clearInterval(musTimer);mus.stop();return;}
      if((opts.keyTarget&&!opts.keyTarget())||document.hidden){mus.stop();return;}
      var d=0;try{d=app.ex?app.ex.wasm_depth():0;}catch(e){}
      if(app.onTitle!==false||!d){mus.want('title');lastDepth=0;wasTitle=true;return;}
      if(lastDepth&&d!==lastDepth)mus.jingle(d>lastDepth?'down':'up');
      lastDepth=d;mus.want(BrogueMusic.band(d));};
    var musTimer=setInterval(musTick,400);
    root.addEventListener('pointerdown',function(){mus.unlock();},true);
    window.addEventListener('keydown',function(){if(!app.dead)mus.unlock();},true);
  }
  var restartBtn=B(right,'↻','Restart',function(){askRestart();},'Start a new game');restartBtn.classList.add('restart');
  if(opts.kid)right.removeChild(restartBtn);
  var R0=Array.prototype.slice.call(right.children),L0=Array.prototype.slice.call(left.children),SPILL=opts.kid?[]:[zoomBtn,stairsBtn,restartBtn];
  // d-pad: yku / h.l / bjn
  var pad=el('div','bq-pad');pad.hidden=true;try{pad.hidden=localStorage.getItem('brogue.pad')!=='1';}catch(e){}if(opts.kid)pad.hidden=false;root.appendChild(pad);
  // press and hold: one step at once, then another step whenever the game is ready for one, until let go
  var holding=[],restPad=null;
  function holdable(b,send){var t=null;
    function stop(){if(t){clearTimeout(t);t=null;}b.classList.remove('held');}
    function again(){t=null;if(app.dead||!b.classList.contains('held'))return;if(!app.queue.length)send();t=setTimeout(again,app.queue.length?60:190);}
    b.addEventListener('pointerdown',function(e){e.preventDefault();e.stopPropagation();try{b.setPointerCapture(e.pointerId);}catch(x){}stop();send();b.classList.add('held');t=setTimeout(again,360);});
    ['pointerup','pointercancel','lostpointercapture'].forEach(function(ev){b.addEventListener(ev,stop);});holding.push(stop);}
  window.addEventListener('blur',function(){holding.forEach(function(f){f();});});
  document.addEventListener('visibilitychange',function(){if(document.hidden)holding.forEach(function(f){f();});});
  [['↖','y'],['↑','k'],['↗','u'],['←','h'],[opts.kid?'💤':'RUN',opts.kid?'z':'.'],['→','l'],['↙','b'],['↓','j'],['↘','n']].forEach(function(d){
    var b=el('button',d[1]==='.'?'run':d[1]==='z'?'rest':'yubn'.indexOf(d[1])>=0?'dg':'',d[0]);
    if(d[1]==='.')b.addEventListener('pointerdown',function(e){e.preventDefault();e.stopPropagation();run=!run;b.classList.toggle('on',run);});
    else holdable(b,function(){app.key(K(run&&d[1]!=='z'?d[1].toUpperCase():d[1]));});
    if(d[1]==='z'){b.title='Rest a turn (hold to keep resting)';restPad=b;}pad.appendChild(b);});
  // ---- life bar (kid look): how much life the hero has, big and colourful ----
  var life=null,lifeLast=-1,lifeT=null;
  if(opts.kid){life=el('div','bq-life','<span class="h" aria-hidden="true">❤️</span><div class="bar"><i></i></div><span class="n"></span><span class="fl"></span>');life.hidden=true;root.appendChild(life);
    var lifeFill=life.querySelector('i'),lifeNum=life.querySelector('.n'),lifeFloor=life.querySelector('.fl');
    lifeT=setInterval(function(){if(app.dead){clearInterval(lifeT);return;}var hp=-1,mx=0;
      try{if(app.inGame()&&app.ex.wasm_hp){hp=app.ex.wasm_hp();mx=app.ex.wasm_maxhp();}}catch(e){}
      if(hp<0||mx<=0){life.hidden=true;lifeLast=-1;return;}life.hidden=false;
      var f=Math.max(0,Math.min(1,hp/mx));lifeFill.style.width=Math.round(f*100)+'%';lifeFill.style.backgroundColor=f>0.6?'#5BD66B':f>0.3?'#FFC93C':'#FF5A6E';
      lifeNum.textContent=Math.max(0,hp)+' / '+mx;life.classList.toggle('low',f<=0.3&&hp>0);if(restPad)restPad.classList.toggle('glow',f<=0.3&&hp>0);
      try{lifeFloor.textContent='Floor '+app.ex.wasm_depth();}catch(e){}
      if(lifeLast>=0&&hp<lifeLast){life.classList.remove('hurt');void life.offsetWidth;life.classList.add('hurt');}
      if(lifeLast>=0&&hp>=lifeLast+3){life.classList.add('heal');setTimeout(function(){life.classList.remove('heal');},700);}
      lifeLast=hp;},250);
    app.life=function(){return {shown:!life.hidden,text:lifeNum.textContent,width:lifeFill.style.width,low:life.classList.contains('low')};};}
  // ---- more sheet: actions card + help card ----
  var sheet=el('div','bq-sheet');sheet.hidden=true;root.appendChild(sheet);
  sheet.addEventListener('click',function(e){if(e.target===sheet){sheet.hidden=true;rsCard.hidden=true;card.hidden=false;}});
  var card=el('div','bq-card','<h3>Actions</h3>');sheet.appendChild(card);
  var helpCard=el('div','bq-card');helpCard.hidden=true;sheet.appendChild(helpCard);
  var rsCard=el('div','bq-card','<h3>Start over?</h3><div class="bq-help">This ends the game you are playing and goes back to the title screen. Saved games stay saved. To keep this game for later, use <b>Save and quit</b> in ⋯ More first.</div>');rsCard.hidden=true;sheet.appendChild(rsCard);
  var rsRow=el('div','bq-row');rsCard.appendChild(rsRow);
  var rsYes=el('button','danger','Start over');rsYes.addEventListener('click',function(){doRestart();});rsRow.appendChild(rsYes);
  var rsNo=el('button','','Keep playing');rsNo.addEventListener('click',function(){sheet.hidden=true;rsCard.hidden=true;card.hidden=false;});rsRow.appendChild(rsNo);
  function askRestart(){card.hidden=true;helpCard.hidden=true;rsCard.hidden=false;sheet.hidden=false;}
  function doRestart(){app.destroy();window.removeEventListener('resize',layout);if(root.parentNode)root.parentNode.removeChild(root);var a2=mount(host,opts);if(opts.onRestart)opts.onRestart(a2);}
  if(opts.kid){var kg=el('div','bq-kgrid');card.appendChild(kg);
    var KT=function(ic,label,fn){var b=el('button','','<span class="ic">'+ic+'</span>'+label);b.addEventListener('click',function(){fn(b);});kg.appendChild(b);return b;};
    KT('🔍','Closer / farther',function(){zoomStep();});
    KT('🔎','Look for secrets',function(){sheet.hidden=true;for(var i=0;i<5;i++)app.key(K('s'));});
    KT('😴','Sleep till better',function(){sheet.hidden=true;app.key(K('Z'));});
    var talkB=KT('🔊','Tap words to hear: '+(talkOn?'on':'off'),function(b){talkOn=!talkOn;try{localStorage.setItem((opts.storageKey||'brogue')+'.talk',talkOn?'1':'0');}catch(e){}
      b.lastChild.textContent='Tap words to hear: '+(talkOn?'on':'off');b.classList.toggle('on',talkOn);layout();});talkB.classList.toggle('on',talkOn);
    KT('💾','Save and stop',function(){sheet.hidden=true;app.key(K('S'));});
    KT('↻','Start over',function(){askRestart();});
    card.appendChild(el('h4','','Grown-up actions'));}
  var grid=el('div','bq-grid');card.appendChild(grid);
  [['OK / Enter','\n'],['Throw','t'],['Apply / use','a'],['Equip','e'],['Unequip','r'],['Drop','d'],['Name an item','c'],['Relabel','R'],['Rest until better','Z'],['Search 5 turns','sssss'],['Up stairs','<'],['Down stairs','>'],['Explore','x'],
   ['Messages','M'],['Discoveries','D'],['Look around','<look>'],['Throw again','T'],['Swap weapons','w'],['Tiles / text','G'],['Seed','~'],['Save and quit','S'],['Brogue help','?']].forEach(function(a){
    var b=el('button','',a[0]+'<small>'+(a[1].length===1?a[1]:'')+'</small>');
    if(a[1]==='\n')b.innerHTML='OK / Enter<small>Enter</small>';
    b.addEventListener('click',function(){if(a[1]==='<look>'){help(true);return;}sheet.hidden=true;if('taerdcRMD?~'.indexOf(a[1])>=0)app.suspendZoom();for(var i=0;i<a[1].length;i++)app.key(a[1].charCodeAt(i));});grid.appendChild(b);});
  var row=el('div','bq-row');card.appendChild(row);
  var bmb=el('button','','');function bmLabel(){bmb.textContent='Big menus: '+(bigMenus?'on':'off');}bmLabel();bmb.addEventListener('click',function(){setBigMenus(!bigMenus);bmLabel();});row.appendChild(bmb);
  var rsb=el('button','','Start over');rsb.addEventListener('click',function(){askRestart();});row.appendChild(rsb);
  var hb=el('button','','How to play');hb.addEventListener('click',function(){help(false);});row.appendChild(hb);
  var kb=el('button','','Keyboard keys');kb.addEventListener('click',function(){help('keys');});row.appendChild(kb);
  if(opts.onBack){var bb=el('button','','Back to clock');bb.addEventListener('click',function(){sheet.hidden=true;opts.onBack();});row.appendChild(bb);}
  var cb=el('button','','Close');cb.addEventListener('click',function(){sheet.hidden=true;});row.appendChild(cb);
  function help(look){card.hidden=true;helpCard.hidden=false;sheet.hidden=false;
    helpCard.innerHTML='<h3>'+(look==='keys'?'Keyboard keys':look?'Looking at things':'How to play')+'</h3><div class="bq-help">'+(look==='keys'?'<table class="bq-keys">'+[['Arrows, or h j k l, y u b n','Move (diagonals: y u b n, or numpad 7 9 1 3)'],['Shift + direction','Run until something happens'],['x','Explore and pick things up'],['&gt; &nbsp; &lt;','Travel to the stairs down / up'],['z &nbsp; Z','Rest a turn / rest until better'],['s','Search (press 5 times, or Z, to search hard)'],['i','Inventory'],['a &nbsp; e &nbsp; r','Apply (read, drink) / equip / remove'],['t &nbsp; T','Throw / throw again'],['d &nbsp; c &nbsp; R','Drop / name an item / relabel'],['w','Swap to your other weapon'],['Enter','Move a cursor to look around (Tab jumps between targets)'],['Esc','Cancel or close a menu'],['M &nbsp; D &nbsp; F','Messages / discoveries / feats'],['S','Save and quit'],['?','Brogue\'s full key list']].map(function(r){return '<tr><td><kbd>'+r[0]+'</kbd></td><td>'+r[1]+'</td></tr>';}).join('')+'</table>'+'<span style="opacity:.7">The mouse works too: click to walk or attack, hover to look.</span>':look?
    'Press and <b>hold</b> any tile on the map to see what it is: monsters, items and terrain show their details in the side panel without moving you. Tap entries in the side panel for more.':
    (opts.kid?'<b>Tap</b> a place on the map to walk there, or <b>hold an arrow</b> to keep walking. Walk into a monster to bump it. <b>Hold</b> a tile to see what it is.<br>'+
    '<b>🎒 Pack</b> is your bag: tap a thing to use it. <b>🧭 Explore</b> walks around and picks things up. <b>⬇ Stairs</b> goes to the way down.<br>'+
    '<b>💤</b> in the middle of the arrows rests, so your life comes back. <b>❤️</b> The life bar shows how much life you have.<br>'+
    '<b>🔊</b> Tap the words at the top to hear what just happened.<br><br><span style="opacity:.7">Grown-ups: the full list of actions is in ⋯ More.</span><br><br>':'')+
    (opts.kid?'':'<b>Tap</b> a tile to walk there. Tap a monster next to you to attack it. <b>Hold</b> a tile to look at it.<br><b>Tap things in the side panel</b> (left) for details on monsters and items you can see.<br>')+
    (opts.kid?'':'<b>🧭 Explore</b> walks you around and picks things up until something interesting happens. <b>⬇ Stairs</b> walks to the way down.<br>'+
    '<b>🎒 Pack</b> opens your items: tap one to read, drink, throw, equip or drop it. Unknown potions and scrolls get identified by using them.<br>'+
    '<b>✕ Back</b> cancels any menu, <b>✓ OK</b> confirms. <b>🔍 Zoom</b> follows your hero up close (tap again for closer, a third time to see everything).<br>'+
    '<b>✥ Pad</b> gives arrow buttons (turn on <b>RUN</b> to keep going). Find the <b>Amulet of Yendor</b> on depth 26 and bring it back up!<br>Playing with a keyboard? See <b>Keyboard keys</b> in ⋯ More.<br><br>')+
    '<span style="opacity:.7">Brogue: Community Edition, free software under the GNU AGPL 3.0 (github.com/tmewett/BrogueCE). Tiles CC BY-SA 4.0 by the Brogue CE maintainers, based on Oryx Design Lab.'+(opts.sourceUrl?' Source code for this build: <a href="'+opts.sourceUrl+'" style="color:#9cf">'+opts.sourceUrl.split('/').pop()+'</a>.':'')+'</span>')+
    '</div>';var r2=el('div','bq-row');var bk=el('button','','Back');bk.addEventListener('click',function(){helpCard.hidden=true;card.hidden=false;});var c2=el('button','','Close');c2.addEventListener('click',function(){sheet.hidden=true;helpCard.hidden=true;card.hidden=false;});r2.appendChild(bk);r2.appendChild(c2);helpCard.appendChild(r2);}
  // ---- big title buttons (Brogue's own title menu is tiny on a phone) ----
  var turn=el('div','bq-turn','Turn your phone sideways for a bigger dungeon');turn.hidden=true;root.appendChild(turn);
  var title=el('div','bq-title');title.hidden=true;root.appendChild(title);
  function tb(label,cls,keys){var b=el('button',cls,label);b.addEventListener('click',function(){for(var i=0;i<keys.length;i++)app.key(K(keys[i]));});title.appendChild(b);return b;}
  // Kid's play: a new game on one of the gentle dungeons in opts.kidSeeds (picked at random, not the last few played)
  var kidSeeding=false;
  function kidPlay(){var L=opts.kidSeeds||[];if(!L.length){app.key(K('n'));return;}var key=(opts.storageKey||'brogue')+'.kidseeds',recent=[];
    try{recent=JSON.parse(localStorage.getItem(key)||'[]');}catch(e){}
    var pool=L.filter(function(x){return recent.indexOf(x)<0;});if(!pool.length)pool=L;var seed=pool[Math.floor(Math.random()*pool.length)];
    recent.push(seed);if(recent.length>Math.min(10,Math.floor(L.length/2)))recent.shift();try{localStorage.setItem(key,JSON.stringify(recent));}catch(e){}
    kidSeeding=true;app.key(K('p'));app.key(K('s'));var d=String(seed);for(var i=0;i<d.length;i++)app.key(d.charCodeAt(i));app.key(10);
    setTimeout(function(){kidSeeding=false;},4000);app.kidSeed=seed;}
  if(opts.kid&&opts.kidSeeds&&opts.kidSeeds.length){var kp=el('button','main kidplay','🦄 Kid\'s play');kp.addEventListener('click',kidPlay);title.appendChild(kp);tb('New game','',['n']);}
  else tb('New game','main',['n']);
  var loadBtn=tb('Load saved game','',['p','l']);tb('Seeded game','',['p','s']);tb('High scores','',['v','h']);tb('Recordings','',['v','r']);
  function showTitle(on){title.hidden=!on;left.style.visibility=on?'hidden':'';if(opts.kid)pad.style.visibility=on?'hidden':'';if(on){loadBtn.hidden=!app.hasSave();layout();}app.needPresent=true;}
  // ---- big-button menus: every Brogue menu (inventory, item actions, yes/no, file lists) as a tap list ----
  var bigMenus=null;try{var bm=localStorage.getItem('brogue.bigmenus');if(bm)bigMenus=bm==='1';}catch(e){}
  if(bigMenus===null)bigMenus=!!(window.matchMedia&&matchMedia('(pointer:coarse)').matches);
  if(opts.kid)bigMenus=true;bmLabel();
  var menu=el('div','bq-menu');menu.hidden=true;root.appendChild(menu);var menuItems=null;
  menu.addEventListener('pointerdown',function(e){e.stopPropagation();});
  var menuWin=null;
  function showMenu(items,win){menuItems=items;if(win)menuWin=win;if(!bigMenus)return;menu.innerHTML='';
    var any=false;items.forEach(function(it){if(!it.label||!it.en)return;any=true;var b=el('button');b.textContent=/^[a-z]{2}/.test(it.label)?it.label.charAt(0).toUpperCase()+it.label.slice(1):it.label;
      if(opts.kid){var lab=it.label.replace(/^[a-zA-Z]\)\s*/,'').replace(/^[^A-Za-z0-9+\-'"]+\s*/,'').replace(/\s*<[^>]*>/g,'').replace(/\s*\[[^\]]*\]/g,'').replace(/(^|\s)[+-]\d+(?=\s)/g,'$1').replace(/\s{2,}/g,' ').trim();
        b.textContent=lab.charAt(0).toUpperCase()+lab.slice(1);b._it=it;
        if(/^yes$/i.test(lab)){b.textContent='✓  Yes';b.classList.add('yes');b._it=null;}else if(/^no$/i.test(lab)){b.textContent='✗  No';b.classList.add('no');b._it=null;}}
      b.addEventListener('click',function(){app.tapCell(it.x+1,it.y);});menu.appendChild(b);});
    if(!any)return;
    // pictures: Brogue draws its window just after announcing the menu, so look for them a moment later
    if(opts.kid){var pics=function(){Array.prototype.forEach.call(menu.children,function(b){if(!b._it||b.classList.contains('pic'))return;var ic=itemIcon(b._it);if(ic){b.insertBefore(ic,b.firstChild);b.classList.add('pic');}});};
      setTimeout(pics,40);setTimeout(pics,200);setTimeout(pics,600);}
    var c=el('button','cancel','✕ Cancel');c.addEventListener('click',function(){app.key(27);});menu.appendChild(c);
    // the question goes on top of its Yes / No, with a speaker to hear it
    if(question&&Date.now()-question.at<3000&&items.some(function(it){return /^\s*yes\s*$/i.test(it.label);})){var qt=question.t;
      var q=el('div','bq-q','<span class="spk" aria-hidden="true">🔊</span>');q.appendChild(document.createTextNode(qt));
      q.addEventListener('click',function(){speak(qt);});menu.insertBefore(q,menu.firstChild);}
    menu.hidden=false;placeMenu();menu.scrollTop=0;}
  function hideMenu(){menu.hidden=true;menuItems=null;}
  app.menuItems=function(){return menuItems;};
  // the sprite drawn at the start of a menu line (inventory rows show the item's picture there)
  function itemIcon(it){try{var K=app.kid;if(!K||!K.fix)return null;for(var x=Math.max(0,it.x-1);x<Math.min(100,it.x+6);x++){var c=app.cells[it.y*100+x];
      if(c&&c.s>=256&&K.has[c.s-256]){var cv2=document.createElement('canvas');cv2.width=64;cv2.height=112;cv2.className='pic';var g=cv2.getContext('2d'),k=c.s-256;
        if(K.tint[k]){g.drawImage(K.tin,(k%16)*64,Math.floor(k/16)*112,64,112,0,0,64,112);g.globalCompositeOperation='source-in';g.fillStyle=c.f;g.fillRect(0,0,64,112);g.globalCompositeOperation='source-over';}
        g.drawImage(K.fix,(k%16)*64,Math.floor(k/16)*112,64,112,0,0,64,112);return cv2;}}}catch(e){}return null;}
  // the list goes beside Brogue's own window (its text stays readable), on the side with more room
  function placeMenu(){if(menu.hidden||!menuItems)return;var W=root.clientWidth,H=root.clientHeight;
    var cr=app.cellRectCss(),off=cv.offsetLeft,L,Rt;
    if(cr&&menuWin&&menuWin.w>0){L=off+cr.x0+menuWin.x*cr.cw;Rt=off+cr.x0+(menuWin.x+menuWin.w)*cr.cw;}
    else{var xs=menuItems.map(function(it){return it.x;});var c=cr||{x0:0,cw:cv.clientWidth/100};L=off+c.x0+Math.min.apply(null,xs)*c.cw;Rt=off+c.x0+(Math.max.apply(null,xs)+20)*c.cw;}
    var freeL=L-12,freeR=W-Rt-12,onLeft=freeL>freeR,free=Math.max(freeL,freeR);
    var w=Math.round(Math.min(420,Math.max(230,free)));menu.style.width=w+'px';menu.style.top='8px';menu.style.maxHeight=(H-16)+'px';
    // never over the page's own buttons: stay inside the game's area
    var cvR=cv.offsetLeft+cv.clientWidth,rightGap=Math.max(8,W-cvR+8);if(opts.kid){w=Math.round(Math.min(w,cv.clientWidth-16));menu.style.width=w+'px';}
    if(onLeft){menu.style.left=(cv.offsetLeft+8)+'px';menu.style.right='';}else{menu.style.right=rightGap+'px';menu.style.left='';}}
  function setBigMenus(on){bigMenus=on;bmLabel();try{localStorage.setItem('brogue.bigmenus',on?'1':'0');}catch(e){}if(!on)menu.hidden=true;else if(menuItems)showMenu(menuItems);}
  // ---- text entry ----
  var txt=el('div','bq-text');txt.hidden=true;var inp=el('input');inp.setAttribute('autocomplete','off');var go=el('button','','OK');txt.appendChild(inp);txt.appendChild(go);root.appendChild(txt);
  var sent='';inp.addEventListener('input',function(){var v=inp.value;while(sent.length>v.length){app.key(127);sent=sent.slice(0,-1);}for(var i=sent.length;i<v.length;i++)app.key(v.charCodeAt(i));sent=v;});
  go.addEventListener('click',function(){app.key(10);sent='';inp.value='';});inp.addEventListener('keydown',function(e){e.stopPropagation();if(e.key==='Enter'){app.key(10);sent='';inp.value='';e.preventDefault();}});
  // ---- layout: canvas fills; controls sit in side gutters when there is room, else overlay ----
  function layoutKid(W,H,dpr){
    // right column: Exit, Pack (double), Explore and Stairs (1.35), Back, More; wide buttons are easier for small hands
    var kw=Math.round(Math.max(104,Math.min(140,W*0.135))),n=right.children.length,units=0;
    Array.prototype.forEach.call(right.children,function(b){units+=b.classList.contains('xl')?2:b.classList.contains('lg')?1.35:1;});
    var ku=Math.round(Math.max(40,Math.min(76,(H-20-(n-1)*10)/units)));
    root.style.setProperty('--kw',kw+'px');root.style.setProperty('--ku',ku+'px');
    right.style.right='10px';right.style.top='10px';right.style.flexDirection='column';
    var cw=W-kw-20;cv.style.left='0px';cv.style.top='0px';cv.style.width=cw+'px';cv.style.height=H+'px';
    cv.width=Math.round(cw*dpr);cv.height=Math.round(H*dpr);app.needPresent=true;
    var ps=Math.round(Math.max(50,Math.min(76,H*0.12,cw*0.09)));root.style.setProperty('--ps',ps+'px');
    pad.style.left='10px';pad.style.bottom='10px';var padW=ps*3+12;
    left.style.flexDirection='row';left.style.left='10px';left.style.right='';left.style.top='';left.style.bottom=(10+padW+10)+'px';left.style.opacity='1';
    if(life){var lx=10+padW+16;life.style.left=lx+'px';life.style.bottom='12px';life.style.width=Math.round(Math.max(150,Math.min(420,cw-lx-12)))+'px';}
    turn.hidden=!(H>W&&W<700);
    title.style.left=Math.round(cw/2)+'px';title.style.bottom='12px';title.style.maxWidth=Math.round(cw-16)+'px';
    placeSay();placeMenu();}
  // the tap-to-hear area sits over the message lines at the top (whichever view is showing)
  function placeSay(){if(!say)return;var R=app.R,k=(cv.width/(cv.clientWidth||1))||1,r=null;
    var show=talkOn&&opts.kid&&!app.dead&&app.inGame&&app.inGame()&&lastMsgs.length>0;
    if(show&&R&&R.length>1&&R[0].strip)r={x:R[0].dx/k,y:R[0].dy/k,w:R[0].dw/k,h:R[0].dh/k};
    else if(show){var c=app.cellRectCss();if(c)r={x:c.x0+21*c.cw,y:c.y0,w:79*c.cw,h:3*c.ch};}
    if(!r){say.hidden=true;return;}
    say.style.left=Math.round(cv.offsetLeft+r.x)+'px';say.style.top=Math.round(cv.offsetTop+r.y)+'px';say.style.width=Math.round(r.w)+'px';say.style.height=Math.max(48,Math.round(r.h))+'px';say.hidden=false;}
  function hudSync(){if(!opts.kid)return;var busy=!menu.hidden||!!app.zoomSusp||!(app.inGame&&app.inGame());
    pad.style.visibility=busy?'hidden':'';left.style.visibility=busy?'hidden':'';if(life&&busy)life.style.visibility='hidden';else if(life)life.style.visibility='';if(busy)say.hidden=true;}
  setInterval(function(){if(app.dead)return;placeSay();hudSync();},300);
  function layout(){
    var W=root.clientWidth,H=root.clientHeight,dpr=Math.min(2,window.devicePixelRatio||1),A=1600/952;
    if(opts.kid){layoutKid(W,H,dpr);return;}
    // buttons that don't fit the right column at 40px move to the left side (short screens, e.g. a phone in landscape)
    var avail=H-20,cap=Math.max(1,Math.floor((avail+8)/48)),moved=[];
    if(R0.length>cap)moved=SPILL.slice(0,Math.min(SPILL.length,R0.length-cap));
    R0.forEach(function(b){if(moved.indexOf(b)<0)right.appendChild(b);});L0.concat(moved).forEach(function(b){left.appendChild(b);});
    var nb=right.children.length,nl=left.children.length,fit=function(n){return Math.floor((avail-(n-1)*8)/n);};
    var bs=Math.max(40,Math.min(70,fit(nb)));root.style.setProperty('--ps',Math.round(Math.min(bs,62))+'px');
    var col=bs+20,cx=0,cw=W-col;          // right column always
    var spare=cw-H*A;                     // room left over beside the console
    var twoCols=spare>=col;               // phone-like: put a column on the left too
    if(twoCols){cx=col;cw=W-2*col;bs=Math.max(40,Math.min(bs,fit(nl)));}
    root.style.setProperty('--bs',bs+'px');
    cv.style.left=cx+'px';cv.style.top='0px';cv.style.width=cw+'px';cv.style.height=H+'px';
    cv.width=Math.round(cw*dpr);cv.height=Math.round(H*dpr);app.needPresent=true;
    right.style.right='10px';right.style.top='10px';right.style.flexDirection='column';
    left.style.flexDirection='column';
    if(twoCols){left.style.left='10px';left.style.top='10px';left.style.bottom='';left.style.right='';left.style.removeProperty('--bs');}
    else{var lb=Math.max(42,Math.min(56,Math.round(cw*0.19/3)-6));left.style.setProperty('--bs',lb+'px');left.style.right='';left.style.top='';var conH=Math.min(H,cw/A),conW=conH*A,rowH=conH/34,lbot=Math.round((H-conH)/2+rowH*2+6);left.style.left=Math.round(cx+(cw-conW)/2+6)+'px';left.style.bottom=lbot+'px';left.style.flexDirection='row';left.style.opacity='.92';}
    var ps=Math.round(Math.min(bs,62));pad.style.bottom='10px';
    if(twoCols){pad.style.left=(col+8)+'px';pad.style.bottom='10px';}else{pad.style.left='10px';pad.style.bottom=(lbot+lb+14)+'px';}
    turn.hidden=!(H>W&&W<700);
    title.style.left=Math.round(cx+cw/2)+'px';title.style.bottom='12px';title.style.maxWidth=Math.round(cw-16)+'px';
    placeMenu();
  }
  window.addEventListener('resize',layout);setTimeout(layout,0);
  app.start().then(function(){load.hidden=true;layout();}).catch(function(e){load.textContent='Could not start: '+e;});
  return app;
}
window.BrogueUI={mount:mount};
})();
