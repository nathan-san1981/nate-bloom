/* Touch-first shell around BrogueApp: d-pad, action buttons, zoom, text entry, help. */
(function(){
'use strict';
var CSS=`
.bq [hidden]{display:none!important}
.bq{position:absolute;inset:0;background:#000;overflow:hidden;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;-webkit-user-select:none;user-select:none;touch-action:none}
.bq canvas{position:absolute;left:0;top:0;touch-action:none}
.bq .bq-col{position:absolute;display:flex;flex-direction:column;gap:8px;z-index:3}
.bq .bq-b{width:var(--bs,58px);height:var(--bs,58px);border-radius:16px;border:2px solid rgba(255,255,255,.35);background:rgba(20,22,40,.72);color:#fff;font-size:15px;font-weight:700;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;padding:0;line-height:1;touch-action:none;backdrop-filter:blur(3px)}
.bq .bq-b small{font-size:10px;font-weight:600;opacity:.8}
.bq .bq-b:active,.bq .bq-b.on{background:rgba(120,90,220,.85);border-color:#fff}
.bq .bq-b .ic{font-size:22px}
.bq .bq-b.exit{background:#C2367E;border-color:#fff;box-shadow:0 4px 0 #8C1F59}.bq .bq-b.exit small{opacity:1;font-size:13px;font-weight:800}
.bq .bq-b.restart{border-color:rgba(255,190,120,.7)}
.bq .bq-row button.danger{background:#B8321F;border-color:#E8766A}
.bq .bq-pad{position:absolute;z-index:3;display:grid;grid-template-columns:repeat(3,var(--ps,56px));grid-template-rows:repeat(3,var(--ps,56px));gap:4px;opacity:.92}
.bq .bq-pad button{border-radius:14px;border:2px solid rgba(255,255,255,.3);background:rgba(20,22,40,.6);color:#fff;font-size:22px;font-weight:700;padding:0;touch-action:none}
.bq .bq-pad button:active{background:rgba(120,90,220,.85)}
.bq .bq-pad .run{font-size:12px}
.bq .bq-pad .run.on{background:rgba(220,120,60,.85)}
.bq .bq-sheet{position:absolute;inset:0;z-index:6;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center}
.bq .bq-sheet[hidden]{display:none}
.bq .bq-card{background:#16182c;color:#eee;border:2px solid #4a4f80;border-radius:20px;padding:16px 18px;max-width:min(760px,94%);max-height:90%;overflow:auto}
.bq .bq-card h3{margin:0 0 10px;font-size:19px}
.bq .bq-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(112px,1fr));gap:8px}
.bq .bq-grid button{height:56px;border-radius:14px;border:2px solid #4a4f80;background:#23264a;color:#fff;font-size:14px;font-weight:700;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px}
.bq .bq-grid button small{font-weight:500;opacity:.7;font-size:11px}
.bq .bq-row{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
.bq .bq-row button{height:48px;padding:0 16px;border-radius:14px;border:2px solid #4a4f80;background:#2f3366;color:#fff;font-size:15px;font-weight:700}
.bq .bq-help{font-size:14px;line-height:1.45;color:#cfd2ee}
.bq .bq-help b{color:#fff}
.bq .bq-keys{border-collapse:collapse;width:100%;margin:2px 0 8px}.bq .bq-keys td{padding:3px 6px;vertical-align:top;border-bottom:1px solid rgba(255,255,255,.08)}.bq .bq-keys td:first-child{white-space:nowrap}
.bq kbd{font:600 13px ui-monospace,Menlo,Consolas,monospace;color:#ffe08a}
.bq .bq-text{position:absolute;left:50%;top:10px;transform:translateX(-50%);z-index:7;display:flex;gap:6px;background:#16182c;border:2px solid #7a6fe0;border-radius:14px;padding:6px}
.bq .bq-text[hidden]{display:none}
.bq .bq-text input{font-size:18px;width:240px;border:none;border-radius:8px;padding:8px;background:#0c0d1a;color:#fff}
.bq .bq-text button{border:none;border-radius:10px;background:#7a6fe0;color:#fff;font-weight:700;padding:0 14px;font-size:16px}
.bq .bq-title{position:absolute;z-index:4;display:flex;flex-wrap:wrap;justify-content:center;align-items:center;gap:10px;pointer-events:none;transform:translateX(-50%)}
.bq .bq-title button{pointer-events:auto;min-height:50px;padding:0 20px;border-radius:16px;border:2px solid rgba(255,255,255,.45);background:rgba(22,24,48,.86);color:#fff;font:700 17px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;backdrop-filter:blur(4px)}
.bq .bq-title button.main{min-height:60px;font-size:21px;padding:0 30px;background:#6d4fd8;border-color:#fff}
.bq .bq-title button:active{background:#8c70f0}
.bq .bq-menu{position:absolute;z-index:5;display:flex;flex-direction:column;gap:6px;padding:8px;overflow-y:auto;-webkit-overflow-scrolling:touch;touch-action:pan-y;background:rgba(14,15,32,.94);border:2px solid #4a4f80;border-radius:18px;box-sizing:border-box}
.bq .bq-menu button{flex:none;min-height:46px;text-align:left;padding:6px 12px;border-radius:12px;border:2px solid #3d4275;background:#23264a;color:#fff;font:600 16px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;line-height:1.25;touch-action:manipulation}
.bq .bq-menu button:active{background:#5b48c4}
.bq .bq-menu button[disabled]{opacity:.4}
.bq .bq-menu button.cancel{text-align:center;background:#3a2238;border-color:#6b3d5f}
.bq .bq-turn{position:absolute;left:50%;top:8px;transform:translateX(-50%);z-index:4;background:rgba(22,24,48,.9);color:#fff;border:1px solid #4a4f80;border-radius:12px;padding:6px 12px;font:600 14px system-ui,-apple-system,sans-serif;pointer-events:none;white-space:nowrap}
.bq .bq-load{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#ccc;font-size:18px;z-index:2}
`;
function el(tag,cls,html){var e=document.createElement(tag);if(cls)e.className=cls;if(html!=null)e.innerHTML=html;return e;}
function mount(host,opts){
  if(!document.getElementById('bq-css')){var st=el('style');st.id='bq-css';st.textContent=CSS;document.head.appendChild(st);}
  var root=el('div','bq');host.appendChild(root);
  var cv=el('canvas');root.appendChild(cv);var load=el('div','bq-load','Opening the dungeon…');root.appendChild(load);
  var app=new BrogueApp({canvas:cv,wasmB64:opts.wasmB64,tilesB64:opts.tilesB64,storageKey:opts.storageKey||'brogue.fs',graphics:opts.graphics!==false,
    keyTarget:opts.keyTarget,onExit:function(){load.textContent='Thanks for playing! Reload to play again.';load.hidden=false;},
    onTextInput:function(on){txt.hidden=!on;if(on){inp.value='';setTimeout(function(){try{inp.focus();}catch(e){}},50);}},
    onError:function(e){load.hidden=false;load.textContent='Something went wrong: '+e;},
    onTitle:function(on){showTitle(on);},onMenu:function(items,win){showMenu(items,win);},onMenuClose:function(){hideMenu();}});
  // ---- controls ----
  var K=function(c){return typeof c==='string'?c.charCodeAt(0):c;};
  var right=el('div','bq-col'),left=el('div','bq-col');root.appendChild(right);root.appendChild(left);
  function B(parent,label,small,fn,title){var b=el('button','bq-b','<span class="ic">'+label+'</span>'+(small?'<small>'+small+'</small>':''));b.title=title||small||'';
    b.addEventListener('pointerdown',function(e){e.preventDefault();e.stopPropagation();fn(b);});parent.appendChild(b);return b;}
  var zooms=[1,1.8,2.6],zi=0,run=false;
  if(opts.onBack){var exitBtn=B(right,'<svg width="26" height="26" viewBox="0 0 26 26" aria-hidden="true"><path d="M11 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h5" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/><path d="M16 8l5 5-5 5M21 13H10" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>','Exit',function(){opts.onBack();},'Back to the clock');exitBtn.classList.add('exit');}
  B(right,'✕','Back',function(){app.key(27);setTimeout(function(){app.resumeZoom();},250);},'Escape / cancel');
  B(right,'✓','OK',function(){app.key(10);},'Enter / confirm');
  B(right,'🎒','Pack',function(){app.suspendZoom();app.key(K('i'));},'Inventory (i)');
  B(right,'🧭','Explore',function(){app.key(K('x'));},'Auto-explore (x)');
  var stairsBtn=B(right,'⬇','Stairs',function(){app.key(K('>'));},'Travel to the down stairs (>)');
  var zoomBtn=B(right,'🔍','Zoom',function(b){zi=(zi+1)%zooms.length;app.setZoom(zooms[zi]);b.querySelector('small').textContent=zi?('×'+zooms[zi]):'Zoom';b.classList.toggle('on',zi>0);},'Zoom in on your hero');
  B(right,'⋯','More',function(){card.hidden=false;helpCard.hidden=true;sheet.hidden=false;},'All actions');
  B(left,'🔎','Search',function(){app.key(K('s'));},'Search (s), press 5 times to search hard');
  B(left,'💤','Rest',function(){app.key(K('z'));},'Rest one turn (z)');
  var padBtn=B(left,'✥','Pad',function(b){pad.hidden=!pad.hidden;b.classList.toggle('on',!pad.hidden);try{localStorage.setItem('brogue.pad',pad.hidden?'0':'1');}catch(e){}layout();},'Show the direction pad');
  var restartBtn=B(right,'↻','Restart',function(){askRestart();},'Start a new game');restartBtn.classList.add('restart');
  var R0=Array.prototype.slice.call(right.children),L0=Array.prototype.slice.call(left.children),SPILL=[zoomBtn,stairsBtn,restartBtn];
  // d-pad: yku / h.l / bjn
  var pad=el('div','bq-pad');pad.hidden=true;try{pad.hidden=localStorage.getItem('brogue.pad')!=='1';}catch(e){}root.appendChild(pad);
  [['↖','y'],['↑','k'],['↗','u'],['←','h'],['RUN','.'],['→','l'],['↙','b'],['↓','j'],['↘','n']].forEach(function(d){var b=el('button',d[1]==='.'?'run':'',d[0]);
    b.addEventListener('pointerdown',function(e){e.preventDefault();e.stopPropagation();
      if(d[1]==='.'){run=!run;b.classList.toggle('on',run);return;}
      app.key(K(run?d[1].toUpperCase():d[1]));});pad.appendChild(b);});
  // ---- more sheet: actions card + help card ----
  var sheet=el('div','bq-sheet');sheet.hidden=true;root.appendChild(sheet);
  sheet.addEventListener('click',function(e){if(e.target===sheet){sheet.hidden=true;rsCard.hidden=true;card.hidden=false;}});
  var card=el('div','bq-card','<h3>Actions</h3>');sheet.appendChild(card);
  var helpCard=el('div','bq-card');helpCard.hidden=true;sheet.appendChild(helpCard);
  var rsCard=el('div','bq-card','<h3>Start over?</h3><div class="bq-help">This ends the game you are playing and goes back to the title screen. Saved games stay saved. To keep this game for later, use <b>Save and quit</b> in ⋯ More first.</div>');rsCard.hidden=true;sheet.appendChild(rsCard);
  var rsRow=el('div','bq-row');rsCard.appendChild(rsRow);
  var rsYes=el('button','danger','Start over');rsYes.addEventListener('click',function(){doRestart();});rsRow.appendChild(rsYes);
  var rsNo=el('button','','Keep playing');rsNo.addEventListener('click',function(){sheet.hidden=true;rsCard.hidden=true;card.hidden=false;});rsRow.appendChild(rsNo);
  function askRestart(){card.hidden=true;helpCard.hidden=true;rsCard.hidden=false;sheet.hidden=false;}
  function doRestart(){app.destroy();window.removeEventListener('resize',layout);if(root.parentNode)root.parentNode.removeChild(root);var a2=mount(host,opts);if(opts.onRestart)opts.onRestart(a2);}
  var grid=el('div','bq-grid');card.appendChild(grid);
  [['Throw','t'],['Apply / use','a'],['Equip','e'],['Unequip','r'],['Drop','d'],['Name an item','c'],['Relabel','R'],['Rest until better','Z'],['Search 5 turns','sssss'],['Up stairs','<'],['Down stairs','>'],['Explore','x'],
   ['Messages','M'],['Discoveries','D'],['Look around','<look>'],['Throw again','T'],['Swap weapons','w'],['Tiles / text','G'],['Seed','~'],['Save and quit','S'],['Brogue help','?']].forEach(function(a){
    var b=el('button','',a[0]+'<small>'+(a[1].length===1?a[1]:'')+'</small>');
    b.addEventListener('click',function(){if(a[1]==='<look>'){help(true);return;}sheet.hidden=true;if('taerdcRMD?~'.indexOf(a[1])>=0)app.suspendZoom();for(var i=0;i<a[1].length;i++)app.key(a[1].charCodeAt(i));});grid.appendChild(b);});
  var row=el('div','bq-row');card.appendChild(row);
  var bmb=el('button','','');function bmLabel(){bmb.textContent='Big menus: '+(bigMenus?'on':'off');}bmLabel();bmb.addEventListener('click',function(){setBigMenus(!bigMenus);bmLabel();});row.appendChild(bmb);
  var rsb=el('button','','Start over');rsb.addEventListener('click',function(){askRestart();});row.appendChild(rsb);
  var hb=el('button','','How to play');hb.addEventListener('click',function(){help(false);});row.appendChild(hb);
  var kb=el('button','','Keyboard keys');kb.addEventListener('click',function(){help('keys');});row.appendChild(kb);
  if(opts.onBack){var bb=el('button','','Back to clock');bb.addEventListener('click',function(){sheet.hidden=true;opts.onBack();});row.appendChild(bb);}
  var cb=el('button','','Close');cb.addEventListener('click',function(){sheet.hidden=true;});row.appendChild(cb);
  function help(look){card.hidden=true;helpCard.hidden=false;sheet.hidden=false;
    helpCard.innerHTML='<h3>'+(look==='keys'?'Keyboard keys':look?'Looking at things':'How to play')+'</h3><div class="bq-help">'+(look==='keys'?'<table class="bq-keys">'+[['Arrows, or h j k l, y u b n','Move (diagonals: y u b n, or numpad 7 9 1 3)'],['Shift + direction','Run until something happens'],['x','Explore and pick things up'],['&gt; &nbsp; &lt;','Travel to the stairs down / up'],['z &nbsp; Z','Rest a turn / rest until better'],['s','Search (press 5 times, or Z, to search hard)'],['i','Inventory'],['a &nbsp; e &nbsp; r','Apply (read, drink) / equip / remove'],['t &nbsp; T','Throw / throw again'],['d &nbsp; c &nbsp; R','Drop / name an item / relabel'],['w','Swap to your other weapon'],['Enter','Move a cursor to look around (Tab jumps between targets)'],['Esc','Cancel or close a menu'],['M &nbsp; D &nbsp; F','Messages / discoveries / feats'],['S','Save and quit'],['?','Brogue\'s full key list']].map(function(r){return '<tr><td><kbd>'+r[0]+'</kbd></td><td>'+r[1]+'</td></tr>';}).join('')+'</table>'+'<span style="opacity:.7">The mouse works too: click to walk or attack, hover to look.</span>':look?
    'Press and <b>hold</b> any tile on the map to see what it is: monsters, items and terrain show their details in the side panel without moving you. Tap entries in the side panel for more.':
    '<b>Tap</b> a tile to walk there. Tap a monster next to you to attack it. <b>Hold</b> a tile to look at it.<br><b>Tap things in the side panel</b> (left) for details on monsters and items you can see.<br>'+
    '<b>🧭 Explore</b> walks you around and picks things up until something interesting happens. <b>⬇ Stairs</b> walks to the way down.<br>'+
    '<b>🎒 Pack</b> opens your items: tap one to read, drink, throw, equip or drop it. Unknown potions and scrolls get identified by using them.<br>'+
    '<b>✕ Back</b> cancels any menu, <b>✓ OK</b> confirms. <b>🔍 Zoom</b> follows your hero up close (tap again for closer, a third time to see everything).<br>'+
    '<b>✥ Pad</b> gives arrow buttons (turn on <b>RUN</b> to keep going). Find the <b>Amulet of Yendor</b> on depth 26 and bring it back up!<br>Playing with a keyboard? See <b>Keyboard keys</b> in ⋯ More.<br><br>'+
    '<span style="opacity:.7">Brogue: Community Edition, free software under the GNU AGPL 3.0 (github.com/tmewett/BrogueCE). Tiles CC BY-SA 4.0 by the Brogue CE maintainers, based on Oryx Design Lab.'+(opts.sourceUrl?' Source code for this build: <a href="'+opts.sourceUrl+'" style="color:#9cf">'+opts.sourceUrl.split('/').pop()+'</a>.':'')+'</span>')+
    '</div>';var r2=el('div','bq-row');var bk=el('button','','Back');bk.addEventListener('click',function(){helpCard.hidden=true;card.hidden=false;});var c2=el('button','','Close');c2.addEventListener('click',function(){sheet.hidden=true;helpCard.hidden=true;card.hidden=false;});r2.appendChild(bk);r2.appendChild(c2);helpCard.appendChild(r2);}
  // ---- big title buttons (Brogue's own title menu is tiny on a phone) ----
  var turn=el('div','bq-turn','Turn your phone sideways for a bigger dungeon');turn.hidden=true;root.appendChild(turn);
  var title=el('div','bq-title');title.hidden=true;root.appendChild(title);
  function tb(label,cls,keys){var b=el('button',cls,label);b.addEventListener('click',function(){for(var i=0;i<keys.length;i++)app.key(K(keys[i]));});title.appendChild(b);return b;}
  tb('New game','main',['n']);var loadBtn=tb('Load saved game','',['p','l']);tb('Seeded game','',['p','s']);tb('High scores','',['v','h']);tb('Recordings','',['v','r']);
  function showTitle(on){title.hidden=!on;if(on){loadBtn.hidden=!app.hasSave();layout();}}
  // ---- big-button menus: every Brogue menu (inventory, item actions, yes/no, file lists) as a tap list ----
  var bigMenus=null;try{var bm=localStorage.getItem('brogue.bigmenus');if(bm)bigMenus=bm==='1';}catch(e){}
  if(bigMenus===null)bigMenus=!!(window.matchMedia&&matchMedia('(pointer:coarse)').matches);
  var menu=el('div','bq-menu');menu.hidden=true;root.appendChild(menu);var menuItems=null;
  menu.addEventListener('pointerdown',function(e){e.stopPropagation();});
  var menuWin=null;
  function showMenu(items,win){menuItems=items;if(win)menuWin=win;if(!bigMenus)return;menu.innerHTML='';
    var any=false;items.forEach(function(it){if(!it.label||!it.en)return;any=true;var b=el('button');b.textContent=/^[a-z]{2}/.test(it.label)?it.label.charAt(0).toUpperCase()+it.label.slice(1):it.label;
      b.addEventListener('click',function(){app.tapCell(it.x+1,it.y);});menu.appendChild(b);});
    if(!any)return;
    var c=el('button','cancel','✕ Cancel');c.addEventListener('click',function(){app.key(27);});menu.appendChild(c);
    menu.hidden=false;placeMenu();menu.scrollTop=0;}
  function hideMenu(){menu.hidden=true;menuItems=null;}
  // the list goes beside Brogue's own window (its text stays readable), on the side with more room
  function placeMenu(){if(menu.hidden||!menuItems)return;var W=root.clientWidth,H=root.clientHeight;
    var cr=app.cellRectCss(),off=cv.offsetLeft,L,Rt;
    if(cr&&menuWin&&menuWin.w>0){L=off+cr.x0+menuWin.x*cr.cw;Rt=off+cr.x0+(menuWin.x+menuWin.w)*cr.cw;}
    else{var xs=menuItems.map(function(it){return it.x;});var c=cr||{x0:0,cw:cv.clientWidth/100};L=off+c.x0+Math.min.apply(null,xs)*c.cw;Rt=off+c.x0+(Math.max.apply(null,xs)+20)*c.cw;}
    var freeL=L-12,freeR=W-Rt-12,onLeft=freeL>freeR,free=Math.max(freeL,freeR);
    var w=Math.round(Math.min(420,Math.max(230,free)));menu.style.width=w+'px';menu.style.top='8px';menu.style.maxHeight=(H-16)+'px';
    if(onLeft){menu.style.left='8px';menu.style.right='';}else{menu.style.right='8px';menu.style.left='';}}
  function setBigMenus(on){bigMenus=on;try{localStorage.setItem('brogue.bigmenus',on?'1':'0');}catch(e){}if(!on)menu.hidden=true;else if(menuItems)showMenu(menuItems);}
  // ---- text entry ----
  var txt=el('div','bq-text');txt.hidden=true;var inp=el('input');inp.setAttribute('autocomplete','off');var go=el('button','','OK');txt.appendChild(inp);txt.appendChild(go);root.appendChild(txt);
  var sent='';inp.addEventListener('input',function(){var v=inp.value;while(sent.length>v.length){app.key(127);sent=sent.slice(0,-1);}for(var i=sent.length;i<v.length;i++)app.key(v.charCodeAt(i));sent=v;});
  go.addEventListener('click',function(){app.key(10);sent='';inp.value='';});inp.addEventListener('keydown',function(e){e.stopPropagation();if(e.key==='Enter'){app.key(10);sent='';inp.value='';e.preventDefault();}});
  // ---- layout: canvas fills; controls sit in side gutters when there is room, else overlay ----
  function layout(){
    var W=root.clientWidth,H=root.clientHeight,dpr=Math.min(2,window.devicePixelRatio||1),A=1600/952;
    // buttons that don't fit the right column at 40px move to the left side (short screens, e.g. a phone in landscape)
    var avail=H-20,cap=Math.max(1,Math.floor((avail+8)/48)),moved=[];
    if(R0.length>cap)moved=SPILL.slice(0,Math.min(SPILL.length,R0.length-cap));
    R0.forEach(function(b){if(moved.indexOf(b)<0)right.appendChild(b);});L0.concat(moved).forEach(function(b){left.appendChild(b);});
    var nb=right.children.length,nl=left.children.length,fit=function(n){return Math.floor((avail-(n-1)*8)/n);};
    var bs=Math.max(40,Math.min(70,fit(nb)));root.style.setProperty('--ps',Math.round(Math.min(bs,62))+'px');
    var col=bs+20,cx=0,cw=W-col;          // right column always
    var spare=cw-H*A;                     // room left over beside the console
    var twoCols=spare>=col;               // phone-like: put a column on the left too
    if(twoCols){cx=col;cw=W-2*col;bs=Math.max(40,Math.min(bs,fit(nl)));}
    root.style.setProperty('--bs',bs+'px');
    cv.style.left=cx+'px';cv.style.top='0px';cv.style.width=cw+'px';cv.style.height=H+'px';
    cv.width=Math.round(cw*dpr);cv.height=Math.round(H*dpr);app.needPresent=true;
    right.style.right='10px';right.style.top='10px';right.style.flexDirection='column';
    left.style.flexDirection='column';
    if(twoCols){left.style.left='10px';left.style.top='10px';left.style.bottom='';left.style.right='';left.style.removeProperty('--bs');}
    else{var lb=Math.max(42,Math.min(56,Math.round(cw*0.19/3)-6));left.style.setProperty('--bs',lb+'px');left.style.right='';left.style.top='';var conH=Math.min(H,cw/A),conW=conH*A,rowH=conH/34,lbot=Math.round((H-conH)/2+rowH*2+6);left.style.left=Math.round(cx+(cw-conW)/2+6)+'px';left.style.bottom=lbot+'px';left.style.flexDirection='row';left.style.opacity='.92';}
    var ps=Math.round(Math.min(bs,62));pad.style.bottom='10px';
    if(twoCols){pad.style.left=(col+8)+'px';pad.style.bottom='10px';}else{pad.style.left='10px';pad.style.bottom=(lbot+lb+14)+'px';}
    turn.hidden=!(H>W&&W<700);
    title.style.left=Math.round(cx+cw/2)+'px';title.style.bottom='12px';title.style.maxWidth=Math.round(cw-16)+'px';
    placeMenu();
  }
  window.addEventListener('resize',layout);setTimeout(layout,0);
  app.start().then(function(){load.hidden=true;layout();}).catch(function(e){load.textContent='Could not start: '+e;});
  return app;
}
window.BrogueUI={mount:mount};
})();
