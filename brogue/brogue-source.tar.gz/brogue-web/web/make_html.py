import base64,sys
W='/root/wasm'
wasm=base64.b64encode(open(W+'/out/brogue.async.wasm','rb').read()).decode()
tiles=base64.b64encode(open(W+'/web/tiles48.png','rb').read()).decode()
core=open(W+'/web/brogue-core.js').read();ui=open(W+'/web/brogue-ui.js').read()
html='''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes"><meta name="theme-color" content="#000000">
<title>Brogue</title>
<style>html,body{margin:0;height:100%;background:#000;overflow:hidden;color-scheme:dark}#host{position:fixed;inset:0;padding:env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left)}#host>.bq{position:absolute;inset:env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left)}</style>
</head><body><div id="host"></div>
<script>'''+core+'''</script><script>'''+ui+'''</script>
<script>var WASM_B64="'''+wasm+'''",TILES_B64="'''+tiles+'''";
window.brogue=BrogueUI.mount(document.getElementById('host'),{wasmB64:WASM_B64,tilesB64:TILES_B64,storageKey:'brogue.fs',onRestart:function(a){window.brogue=a;}});</script>
</body></html>'''
out=sys.argv[1] if len(sys.argv)>1 else W+'/web/brogue.html'
if len(sys.argv)>2 and sys.argv[2]=='pages':
    # GitHub Pages: installable (manifest, icons, offline service worker) and links its source
    head=('<title>Brogue</title>\n<link rel="manifest" href="manifest.webmanifest"><link rel="apple-touch-icon" href="icon-192.png"><link rel="icon" href="icon-192.png">\n'
          '<meta name="apple-mobile-web-app-title" content="Brogue"><meta name="apple-mobile-web-app-status-bar-style" content="black">')
    html=html.replace('<title>Brogue</title>',head,1)
    tail=("storageKey:'brogue.fs',sourceUrl:'brogue-source.tar.gz',onRestart:function(a){window.brogue=a;}});\n"
          "if('serviceWorker' in navigator&&location.protocol==='https:')navigator.serviceWorker.register('sw.js').catch(function(){});</script>")
    assert html.count("storageKey:'brogue.fs',onRestart:function(a){window.brogue=a;}});</script>")==1
    html=html.replace("storageKey:'brogue.fs',onRestart:function(a){window.brogue=a;}});</script>",tail,1)
    open(out,'w').write(html);print(out,len(html));sys.exit(0)
if len(sys.argv)>2 and sys.argv[2]=='artifact':
    # the artifact host adds doctype/head/body; keep only title, style and content
    art='''<title>Brogue Dungeon</title>
<meta name="apple-mobile-web-app-capable" content="yes"><meta name="theme-color" content="#000000">
<style>:root{color-scheme:dark;background:#000}html,body{height:100%;margin:0;background:#000;overflow:hidden}#host{position:fixed;inset:0}#host>.bq{position:absolute;inset:env(safe-area-inset-top,0px) env(safe-area-inset-right,0px) env(safe-area-inset-bottom,0px) env(safe-area-inset-left,0px)}</style>
<div id="host"></div>
<script>'''+core+'''</script><script>'''+ui+'''</script>
<script>var WASM_B64="'''+wasm+'''",TILES_B64="'''+tiles+'''";
window.brogue=BrogueUI.mount(document.getElementById('host'),{wasmB64:WASM_B64,tilesB64:TILES_B64,storageKey:'brogue.fs',onRestart:function(a){window.brogue=a;}});</script>'''
    open(out,'w').write(art);print(out,len(art));sys.exit(0)
open(out,'w').write(html);print(out,len(html))
