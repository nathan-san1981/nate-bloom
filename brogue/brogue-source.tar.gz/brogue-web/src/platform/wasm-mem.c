/* Plain memcpy / memmove / memset for the web build, compiled without bulk-memory instructions, so the
   module loads in older web engines (Chrome 57+, older Fire tablets) as well as new ones. */
#include <stddef.h>
#include <stdint.h>

__attribute__((no_builtin)) void *memcpy(void *restrict d, const void *restrict s, size_t n) {
    unsigned char *dp = d;
    const unsigned char *sp = s;
    if (((uintptr_t)dp & 3) == ((uintptr_t)sp & 3)) {
        while (n && ((uintptr_t)dp & 3)) { *dp++ = *sp++; n--; }
        uint32_t *dw = (uint32_t *)dp;
        const uint32_t *sw = (const uint32_t *)sp;
        while (n >= 16) { dw[0] = sw[0]; dw[1] = sw[1]; dw[2] = sw[2]; dw[3] = sw[3]; dw += 4; sw += 4; n -= 16; }
        while (n >= 4) { *dw++ = *sw++; n -= 4; }
        dp = (unsigned char *)dw;
        sp = (const unsigned char *)sw;
    }
    while (n--) *dp++ = *sp++;
    return d;
}

__attribute__((no_builtin)) void *memmove(void *d, const void *s, size_t n) {
    unsigned char *dp = d;
    const unsigned char *sp = s;
    if (dp == sp || n == 0) return d;
    if (dp < sp || dp >= sp + n) return memcpy(d, s, n);
    dp += n;
    sp += n;
    while (n--) *--dp = *--sp;
    return d;
}

__attribute__((no_builtin)) void *memset(void *d, int c, size_t n) {
    unsigned char *dp = d;
    unsigned char v = (unsigned char)c;
    while (n && ((uintptr_t)dp & 3)) { *dp++ = v; n--; }
    uint32_t w = v * 0x01010101u;
    uint32_t *dw = (uint32_t *)dp;
    while (n >= 16) { dw[0] = w; dw[1] = w; dw[2] = w; dw[3] = w; dw += 4; n -= 16; }
    while (n >= 4) { *dw++ = w; n -= 4; }
    dp = (unsigned char *)dw;
    while (n--) *dp++ = v;
    return d;
}
