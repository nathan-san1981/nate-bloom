// WebAssembly platform for Brogue CE: draws through JS imports, receives input through
// an async JS import (made synchronous-looking with Binaryen's Asyncify pass).
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "platform.h"
#include "GlobalsBase.h"

#define WASM_IMPORT(name) __attribute__((import_module("env"), import_name(#name)))

WASM_IMPORT(js_plot) void js_plot(int glyph, int sprite, int unicode, int x, int y,
                                  int fr, int fg, int fb, int br, int bg, int bb);
WASM_IMPORT(js_next_event) void js_next_event(int *out, int textInput, int colorsDance);
WASM_IMPORT(js_pause) int js_pause(int ms, int behavior);
WASM_IMPORT(js_modifier) int js_modifier(int which);
WASM_IMPORT(js_notify) void js_notify(int eventId, int d1, int d2, const char *s1, const char *s2);
WASM_IMPORT(js_bubble) int js_bubble(void);
int wasmBubble(void) { return js_bubble(); }
WASM_IMPORT(js_kid) int js_kid(void);
int wasmKid(void) { return js_kid(); }
WASM_IMPORT(js_graphics) int js_graphics(int mode);
WASM_IMPORT(js_remap) void js_remap(const char *from, const char *to);

static enum graphicsModes curMode = TEXT_GRAPHICS;

static int spriteIndex(enum displayGlyph glyph) {
    if (glyph == G_UP_ARROW) return 0x90;
    if (glyph == G_DOWN_ARROW) return 0x91;
    if (glyph < 128) return glyph;
    if (curMode == TILES_GRAPHICS || (curMode == HYBRID_GRAPHICS && isEnvironmentGlyph(glyph)))
        return glyph + 128 - 2;
    return -1; // text: use unicode
}

void wasm_gameLoop(void) {
    int code = rogueMain();
    js_notify(-1, code, 0, "", "");
}

boolean wasm_pauseForMilliseconds(short ms, PauseBehavior behavior) {
    return js_pause(ms, behavior.interuptForMouseMove ? 1 : 0) ? true : false;
}

void wasm_nextKeyOrMouseEvent(rogueEvent *ev, boolean textInput, boolean colorsDance) {
    int buf[5] = {0, 0, 0, 0, 0};
    for (;;) {
        js_next_event(buf, textInput ? 1 : 0, colorsDance ? 1 : 0);
        if (buf[0] == 99) { // redraw request with dancing colors
            if (colorsDance) {
                shuffleTerrainColors(3, true);
                commitDraws();
            }
            continue;
        }
        break;
    }
    ev->eventType = buf[0];
    ev->param1 = buf[1];
    ev->param2 = buf[2];
    ev->controlKey = buf[3] ? true : false;
    ev->shiftKey = buf[4] ? true : false;
}

void wasm_plotChar(enum displayGlyph ch, short x, short y,
                          short fr, short fg, short fb, short br, short bg, short bb) {
    int sprite = spriteIndex(ch);
    unsigned int uni = glyphToUnicode(ch);
    js_plot((int)ch, sprite, (int)uni, x, y, fr, fg, fb, br, bg, bb);
}

static void wasm_remap(const char *from, const char *to) { js_remap(from, to); }
static boolean wasm_modifierHeld(int modifier) { return js_modifier(modifier) ? true : false; }
static void wasm_notifyEvent(short id, int d1, int d2, const char *s1, const char *s2) {
    js_notify(id, d1, d2, s1 ? s1 : "", s2 ? s2 : "");
}
static boolean wasm_takeScreenshot() { return false; }
static enum graphicsModes wasm_setGraphicsMode(enum graphicsModes mode) {
    curMode = mode;
    js_graphics((int)mode);
    return mode;
}

struct brogueConsole wasmConsole = {
    wasm_gameLoop,
    wasm_pauseForMilliseconds,
    wasm_nextKeyOrMouseEvent,
    wasm_plotChar,
    wasm_remap,
    wasm_modifierHeld,
    wasm_notifyEvent,
    wasm_takeScreenshot,
    wasm_setGraphicsMode
};

// helpers for the JS front end
__attribute__((export_name("wasm_player_x"))) int wasm_player_x(void) { return player.loc.x; }
__attribute__((export_name("wasm_player_y"))) int wasm_player_y(void) { return player.loc.y; }
__attribute__((export_name("wasm_depth"))) int wasm_depth(void) { return rogue.depthLevel; }
__attribute__((export_name("wasm_playing"))) int wasm_playing(void) { return rogue.gameHasEnded ? 0 : 1; }
__attribute__((export_name("wasm_turn"))) int wasm_turn(void) { return (int)rogue.absoluteTurnNumber; }
__attribute__((export_name("wasm_malloc"))) void *wasm_malloc(int n) { return malloc(n); }

#ifdef KID_TEST
// test-only build: force the situations where an enemy could look like a unicorn
__attribute__((export_name("wasm_test_kid"))) int wasm_test_kid(int mode) {
    if (mode == 1) {
        player.status[STATUS_HALLUCINATING] = player.maxStatus[STATUS_HALLUCINATING] = 500;
        displayLevel();
        return 0;
    }
    short id = (mode == 4) ? MK_RAT : MK_UNICORN; // 2 friendly unicorn, 3 discord-turned unicorn, 4 hostile rat
    creature *m = generateMonster(id, false, false);
    m->loc = getQualifyingPathLocNear(player.loc, true, T_DIVIDES_LEVEL & avoidedFlagsForMonster(&(m->info)), HAS_PLAYER,
                                      avoidedFlagsForMonster(&(m->info)), (HAS_PLAYER | HAS_MONSTER | HAS_STAIRS), false);
    pmapAt(m->loc)->flags |= HAS_MONSTER;
    if (mode == 2 || mode == 3) becomeAllyWith(m);
    if (mode == 3) m->status[STATUS_DISCORDANT] = m->maxStatus[STATUS_DISCORDANT] = 500;
    m->ticksUntilTurn = 30000;
    displayLevel();
    return m->loc.x * 100 + m->loc.y;
}
#endif
