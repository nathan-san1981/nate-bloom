#!/usr/bin/env python3
"""keys-server — serves Keys on the Raspberry Pi box and does what a browser can't.
Listens on 127.0.0.1 only (Web MIDI needs a secure context; localhost qualifies).
  GET  /                 index.html (Keys)
  GET  /api/status       box info: sinks, temperature, power, app
  POST /api/state        save progress JSON to disk     POST /api/state/get   read it back
  POST /api/sink {id}    set default audio output (wpctl)
  POST /api/app {to}     switch the kiosk app: 'bloom' | 'keys' (box-switch)
  POST /api/power {action}  'shutdown' | 'reboot'
"""
import json, os, re, subprocess, shutil, time, urllib.request, urllib.error
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

HERE = os.path.dirname(os.path.abspath(__file__))
CONF = {}
for line in open('/etc/keys-box.conf') if os.path.exists('/etc/keys-box.conf') else []:
    m = re.match(r'\s*([A-Z_]+)=(.*)$', line)
    if m: CONF[m.group(1)] = m.group(2).strip().strip('"')
PORT = int(CONF.get('KEYS_PORT', os.environ.get('KEYS_PORT', '8090')))
STATE_DIR = os.path.expanduser(CONF.get('STATE_DIR', '~/.local/share/keys'))
INDEX = os.path.join(HERE, 'index.html')
MUSIC_SERVER = CONF.get('MUSIC_SERVER', '').rstrip('/')   # Keys Music on the Beelink, e.g. http://192.168.1.50:8770

def music_proxy(path, data=None):
    req = urllib.request.Request(MUSIC_SERVER + path, data=data, method='POST' if data is not None else 'GET')
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.status, r.read(), r.headers.get('Content-Type', 'application/json'), r.headers.get('X-File-Name')

def run(cmd, timeout=4):
    try: return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout
    except Exception: return ''

def sinks():
    out, res, in_sinks = run(['wpctl', 'status']), [], False
    for line in out.splitlines():
        s = line.replace('│', ' ').replace('├', ' ').replace('└', ' ').replace('─', ' ')
        if 'Sinks:' in s: in_sinks = True; continue
        if in_sinks:
            if not s.strip() or s.strip().endswith(':'): break
            m = re.match(r'\s*(\*)?\s*(\d+)\.\s+(.+?)(\s+\[vol:.*)?$', s)
            if m: res.append({'id': m.group(2), 'name': m.group(3).strip(), 'default': bool(m.group(1))})
    return res

def status():
    t = re.search(r'temp=([\d.]+)', run(['vcgencmd', 'measure_temp']))
    th = re.search(r'throttled=(0x[0-9a-fA-F]+)', run(['vcgencmd', 'get_throttled']))
    return {'box': True, 'app': 'keys', 'sinks': sinks(), 'temp': float(t.group(1)) if t else None,
            'throttled': th.group(1) if th else None, 'stateFile': os.path.exists(os.path.join(STATE_DIR, 'progress.json')),
            'bloom': bool(CONF.get('BLOOM_CMD'))}

def save_state(data):
    os.makedirs(STATE_DIR, exist_ok=True)
    p = os.path.join(STATE_DIR, 'progress.json'); tmp = p + '.tmp'
    with open(tmp, 'w') as f: json.dump(data, f)
    f = open(tmp); os.fsync(f.fileno()); f.close()
    os.replace(tmp, p)
    day = time.strftime('%Y-%m-%d')                    # one backup per day, keep 14
    bdir = os.path.join(STATE_DIR, 'backups'); os.makedirs(bdir, exist_ok=True)
    shutil.copyfile(p, os.path.join(bdir, f'progress-{day}.json'))
    for old in sorted(os.listdir(bdir))[:-14]: os.remove(os.path.join(bdir, old))

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def send(self, code, body, ctype='application/json'):
        b = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code); self.send_header('Content-Type', ctype); self.send_header('Content-Length', str(len(b)))
        self.send_header('Cache-Control', 'no-store'); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        path = self.path.split('?')[0]
        if path in ('/', '/index.html'):
            return self.send(200, open(INDEX, 'rb').read(), 'text/html; charset=utf-8')
        if path == '/api/status': return self.send(200, status())
        if path.startswith('/api/music/'):
            if not MUSIC_SERVER: return self.send(503, {'error': 'no music server configured'})
            try:
                code, body, ctype, fname = music_proxy(self.path)
                self.send_response(code); self.send_header('Content-Type', ctype); self.send_header('Content-Length', str(len(body)))
                if fname: self.send_header('X-File-Name', fname)
                self.end_headers(); self.wfile.write(body); return
            except urllib.error.HTTPError as e: return self.send(e.code, {'error': 'music server said ' + str(e.code)})
            except Exception: return self.send(502, {'error': 'music server not reachable'})
        self.send(404, {'error': 'not found'})
    def do_POST(self):
        n = int(self.headers.get('Content-Length') or 0)
        if self.path.startswith('/api/music/upload'):
            if not MUSIC_SERVER: return self.send(503, {'error': 'no music server configured'})
            if n > 50_000_000: return self.send(413, {'error': 'too large'})
            try: code, body, ctype, _ = music_proxy(self.path, self.rfile.read(n)); return self.send(code, json.loads(body or b'{}'))
            except Exception: return self.send(502, {'error': 'music server not reachable'})
        if n > 20_000_000: return self.send(413, {'error': 'too large'})
        try: body = json.loads(self.rfile.read(n) or b'{}')
        except Exception: return self.send(400, {'error': 'bad json'})
        path = self.path.split('?')[0]
        if path == '/api/state':
            if not isinstance(body, dict) or 'profiles' not in body: return self.send(400, {'error': 'not a Keys state'})
            save_state(body); return self.send(200, {'ok': True})
        if path == '/api/state/get':
            p = os.path.join(STATE_DIR, 'progress.json')
            return self.send(200, json.load(open(p)) if os.path.exists(p) else {})
        if path == '/api/sink':
            sid = str(body.get('id', ''))
            if not sid.isdigit(): return self.send(400, {'error': 'bad id'})
            run(['wpctl', 'set-default', sid]); return self.send(200, {'ok': True})
        if path == '/api/app':
            to = body.get('to')
            if to not in ('bloom', 'keys'): return self.send(400, {'error': 'bad app'})
            subprocess.Popen(['/usr/local/bin/box-switch', to], start_new_session=True)
            return self.send(200, {'ok': True})
        if path == '/api/power':
            a = body.get('action')
            if a not in ('shutdown', 'reboot'): return self.send(400, {'error': 'bad action'})
            subprocess.Popen(['sudo', '-n', '/usr/bin/systemctl', 'poweroff' if a == 'shutdown' else 'reboot'], start_new_session=True)
            return self.send(200, {'ok': True})
        self.send(404, {'error': 'not found'})

if __name__ == '__main__':
    ThreadingHTTPServer(('127.0.0.1', PORT), H).serve_forever()
