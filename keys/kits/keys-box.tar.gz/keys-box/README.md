# Keys on the Nate Bloom Box (Raspberry Pi 5)

Piano lessons on the same box as Nate Bloom: Pi 5 (4 GB), Touch Display 2 (1280×720 landscape),
any of the three controllers, sound out of the USB-C headphone cable.

## Install
Copy this folder to the Pi (scp or a USB stick), then on the Pi:

    cd keys-box && ./install.sh && sudo reboot

Re-run `./install.sh` to update (copy a newer index.html in first). Re-running keeps /etc/keys-box.conf.

## What it sets up
| Piece | What it does |
|---|---|
| `keys-server.py` (user service, 127.0.0.1:8090) | Serves Keys; saves progress to `~/.local/share/keys/progress.json` (+14 daily backups); lists/switches audio outputs (wpctl); app switch; shutdown/reboot. Localhost only. |
| `box-session` (tty1 autologin) | The box's one launcher. Runs Nate Bloom **or** Keys full screen under cage; reads `~/.config/keys-box/app`. |
| `box-switch keys\|bloom` | Switches the app on screen (Keys' Settings → "Switch to Nate Bloom" calls it; Nate Bloom calls `box-switch keys`). |
| `kiosk.sh` | Chromium flags: Wayland, 1.25× scale (1024×576 CSS px), autoplay allowed (no "tap to start"), MIDI without a prompt, in-process audio, 256-frame buffer. |
| `/etc/keys-box.conf` | Port, scale, audio buffer, progress folder, `BLOOM_CMD` (how to start Nate Bloom), `DEFAULT_APP` at boot. |
| PipeWire | 48 kHz, quantum 128 (same as the Nate Bloom spec). |
| config.txt | `usb_max_current_enable=1` so the Pi powers the KeyLab or MiniLab from a power bank. |

## Controllers on the box
- **KeyLab Essential 61** — Setup A: 61 keys, box plays the piano sound.
- **Yamaha P-225 + pedal** — Setup B: 88 keys, piano plays its own sound, pedal lessons unlocked. Use a powered USB hub only if something else is plugged in too.
- **MiniLab 3** — 25 keys, box plays the sound. The on-screen keyboard follows its octave buttons. Lessons that need more than two octaves say so and suggest the octave to set; use the KeyLab or Yamaha for full lessons.
Pads, knobs and faders are ignored by Keys (they still work in Nate Bloom).

## Notes
- **Read-only root:** if the box's root filesystem is made read-only, keep `STATE_DIR` on a writable location or progress resets at power-off.
- **Bluetooth headphones** add 150–250 ms. Timing scores stay fair only after Settings → Measure latency. Wired is the right choice for lessons.
- **Latency target:** with PipeWire at quantum 128 and `--audio-buffer-size=256`, key-to-sound should be ~20 ms. If it crackles, set `KEYS_AUDIO_BUFFER=512` in /etc/keys-box.conf.
- **Text too small/large:** change `KEYS_SCALE` (1.0 = 1280×720, 1.25 default, 1.5 = 853×480).
- Logs: `journalctl --user -u keys-server`.
