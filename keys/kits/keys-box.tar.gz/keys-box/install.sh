#!/bin/bash
# Keys for the Nate Bloom Box (Raspberry Pi 5, Raspberry Pi OS 64-bit, Touch Display 2).
# Run from this folder as the user who will be logged in on the box:  ./install.sh
# Safe to re-run (updates in place). Works with or without Nate Bloom installed.
set -euo pipefail
cd "$(dirname "$0")"
U=$(id -un); H=$HOME
echo "== packages"
sudo apt-get update -qq
BROWSER_PKG=chromium; apt-cache show chromium >/dev/null 2>&1 || BROWSER_PKG=chromium-browser
sudo apt-get install -y -qq cage python3 pipewire wireplumber pipewire-alsa "$BROWSER_PKG" fonts-dejavu-core >/dev/null

echo "== files"
install -d "$H/keys"
install -m 644 index.html "$H/keys/index.html"
install -m 755 keys-server.py kiosk.sh box-session "$H/keys/"
sudo install -m 755 box-switch /usr/local/bin/box-switch

echo "== config (/etc/keys-box.conf)"
if [ ! -f /etc/keys-box.conf ]; then
  BLOOM_CMD=""
  if command -v nate-bloom >/dev/null 2>&1; then BLOOM_CMD="nate-bloom --box"; fi
  sudo tee /etc/keys-box.conf >/dev/null <<CONF
# Keys on the box. Edit, then: systemctl --user restart keys-server
KEYS_USER=$U
KEYS_PORT=8090
KEYS_SCALE=1.25
KEYS_AUDIO_BUFFER=256
# Where progress is saved (must be writable even if the root filesystem is read-only)
STATE_DIR=$H/.local/share/keys
# Command that starts Nate Bloom full screen (empty = Keys only). Used by box-session/box-switch.
BLOOM_CMD="$BLOOM_CMD"
# App shown at boot: bloom or keys
DEFAULT_APP=$([ -n "$BLOOM_CMD" ] && echo bloom || echo keys)
# Keys Music on the Beelink (Piano Music folder), e.g. http://192.168.1.50:8770 — empty = off
MUSIC_SERVER=
CONF
fi

echo "== server (systemd user service)"
install -d "$H/.config/systemd/user"
install -m 644 keys-server.service "$H/.config/systemd/user/"
sudo loginctl enable-linger "$U"
systemctl --user daemon-reload
systemctl --user enable --now keys-server.service

echo "== power buttons (shutdown/reboot without a password, nothing else)"
echo "$U ALL=(root) NOPASSWD: /usr/bin/systemctl poweroff, /usr/bin/systemctl reboot" | sudo tee /etc/sudoers.d/keys-box >/dev/null
sudo chmod 440 /etc/sudoers.d/keys-box

echo "== audio: PipeWire 48 kHz, quantum 128"
install -d "$H/.config/pipewire/pipewire.conf.d"
cat > "$H/.config/pipewire/pipewire.conf.d/10-box.conf" <<PW
context.properties = { default.clock.rate = 48000  default.clock.quantum = 128  default.clock.min-quantum = 128 }
PW
sudo usermod -aG audio "$U"

echo "== USB power for the controller"
CFG=/boot/firmware/config.txt; [ -f $CFG ] || CFG=/boot/config.txt
grep -q '^usb_max_current_enable=1' $CFG || echo 'usb_max_current_enable=1' | sudo tee -a $CFG >/dev/null

echo "== boot into the box session on tty1"
if ! grep -q 'keys/box-session' "$H/.bash_profile" 2>/dev/null; then
  if grep -q 'cage' "$H/.bash_profile" 2>/dev/null; then
    echo "!! ~/.bash_profile already starts a kiosk (Nate Bloom?). Replace that line with:"
    echo '   [ "$(tty)" = /dev/tty1 ] && [ -z "$WAYLAND_DISPLAY" ] && exec $HOME/keys/box-session'
    echo "   and set BLOOM_CMD in /etc/keys-box.conf to the command it ran."
  else
    cat >> "$H/.bash_profile" <<'BP'
# Nate Bloom Box: one launcher for Nate Bloom and Keys
[ "$(tty)" = /dev/tty1 ] && [ -z "$WAYLAND_DISPLAY" ] && exec $HOME/keys/box-session
BP
  fi
fi
command -v raspi-config >/dev/null && sudo raspi-config nonint do_boot_behaviour B2 || true

echo "== check"
sleep 1
curl -fs "http://127.0.0.1:8090/api/status" >/dev/null && echo "keys-server OK on 127.0.0.1:8090" || echo "!! keys-server not answering: journalctl --user -u keys-server"
echo "Done. Reboot to start the box session:  sudo reboot"
