#!/bin/bash
# Keys in Chromium, full screen under cage. Started by box-session.
. /etc/keys-box.conf 2>/dev/null
BROWSER=$(command -v chromium || command -v chromium-browser)
SCALE=${KEYS_SCALE:-1.25}      # 1280x720 panel -> 1024x576 CSS px: staff and keys readable on 5"
exec "$BROWSER" --kiosk --app="http://localhost:${KEYS_PORT:-8090}/?box=1" \
  --ozone-platform=wayland --force-device-scale-factor="$SCALE" \
  --autoplay-policy=no-user-gesture-required \
  --disable-features=BlockMidiByDefault,AudioServiceOutOfProcess,AudioServiceSandbox,Translate \
  --audio-buffer-size="${KEYS_AUDIO_BUFFER:-256}" \
  --enable-gpu-rasterization --ignore-gpu-blocklist \
  --user-data-dir="$HOME/.config/keys-chromium" \
  --noerrdialogs --disable-session-crashed-bubble --disable-infobars --no-first-run \
  --overscroll-history-navigation=0 --disable-pinch --check-for-update-interval=31536000 \
  --password-store=basic
