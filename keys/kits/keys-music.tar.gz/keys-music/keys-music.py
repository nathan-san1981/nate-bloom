#!/usr/bin/env python3
"""Keys Music — the "Piano Music" folder on the computer, shared with the Keys app.

Drop a file in the folder and it shows up in Keys on the tablet and the Pi box.
  MusicXML (.mxl .musicxml .xml) and MIDI (.mid)   -> served as-is (Keys converts them)
  PDF / photos of sheet music (.pdf .png .jpg)     -> Audiveris -> MusicXML   (if installed)
  Recordings (.mp3 .wav .m4a .flac)                -> basic-pitch -> MIDI     (if installed)

  GET  /api/music/list           catalog (JSON)
  GET  /api/music/file/<id>      the file Keys should import (converted output for PDFs/audio)
  POST /api/music/upload?name=   add a file to the folder (from the tablet's "Add music")
  GET  /                         the Keys app itself (so the computer can also host it)
Read-only except for upload; CORS open so the app can be hosted anywhere (GitHub Pages, the Pi).
"""
import hashlib, json, os, re, shutil, subprocess, threading, time, urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

CONF = {}
for path in ('/etc/keys-music.conf', os.path.expanduser('~/.config/keys-music.conf')):
    if os.path.exists(path):
        for line in open(path):
            m = re.match(r'\s*([A-Z_]+)=(.*)$', line)
            if m: CONF[m.group(1)] = m.group(2).strip().strip('"')
MUSIC_DIR = os.path.expanduser(CONF.get('MUSIC_DIR', '~/Piano Music'))
CACHE = os.path.expanduser(CONF.get('CACHE_DIR', '~/.cache/keys-music'))
VOICE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'voice')
PORT = int(CONF.get('PORT', '8770'))
BIND = CONF.get('BIND', '0.0.0.0')
AUDIVERIS = CONF.get('AUDIVERIS_CMD', '') or (shutil.which('audiveris') or ('flatpak run org.audiveris.audiveris' if shutil.which('flatpak') and subprocess.run(['flatpak', 'info', 'org.audiveris.audiveris'], capture_output=True).returncode == 0 else ''))
BASIC_PITCH = CONF.get('BASIC_PITCH_CMD', '') or (shutil.which('basic-pitch') or '')
HERE = os.path.dirname(os.path.abspath(__file__))
DIRECT = {'.mxl', '.musicxml', '.xml', '.mid', '.midi', '.kar'}
SCAN = {'.pdf', '.png', '.jpg', '.jpeg', '.tif', '.tiff'}
AUDIO = {'.mp3', '.wav', '.m4a', '.flac', '.ogg'}
os.makedirs(MUSIC_DIR, exist_ok=True); os.makedirs(CACHE, exist_ok=True)
state = {}           # id -> {status, out, error}
lock = threading.Lock()

def fid(rel, st): return hashlib.sha1(f'{rel}:{st.st_size}:{int(st.st_mtime)}'.encode()).hexdigest()[:16]
def title_of(name): return re.sub(r'[_\-]+', ' ', os.path.splitext(name)[0]).strip()

def catalog():
    items = []
    for root, dirs, files in os.walk(MUSIC_DIR):
        dirs[:] = [d for d in dirs if not d.startswith('.')]
        for f in sorted(files):
            if f.startswith('.'): continue
            ext = os.path.splitext(f)[1].lower()
            if ext not in DIRECT | SCAN | AUDIO: continue
            full = os.path.join(root, f); rel = os.path.relpath(full, MUSIC_DIR); st = os.stat(full)
            i = fid(rel, st)
            kind = 'notation' if ext in DIRECT else 'scan' if ext in SCAN else 'audio'
            with lock: s = state.get(i)
            if kind == 'notation': status, err = 'ready', ''
            elif s: status, err = s['status'], s.get('error', '')
            else:
                tool = AUDIVERIS if kind == 'scan' else BASIC_PITCH
                status, err = ('waiting', '') if tool else ('needs-tool', 'The converter for this kind of file is not installed on the computer yet.')
            items.append({'id': i, 'name': f, 'title': title_of(f), 'folder': os.path.dirname(rel), 'kind': kind, 'size': st.st_size,
                          'mtime': int(st.st_mtime), 'status': status, 'error': err, 'rough': kind == 'audio', '_full': full})
    return items

def convert_loop():
    """background worker: converts PDFs/photos and recordings one at a time"""
    while True:
        try:
            for it in catalog():
                if it['status'] != 'waiting': continue
                i, full = it['id'], it['_full']
                outdir = os.path.join(CACHE, i); os.makedirs(outdir, exist_ok=True)
                with lock: state[i] = {'status': 'converting'}
                try:
                    if it['kind'] == 'scan':
                        cmd = AUDIVERIS.split() + ['-batch', '-export', '-output', outdir, full]
                        subprocess.run(cmd, capture_output=True, timeout=900)
                        outs = [os.path.join(dp, f) for dp, _, fs in os.walk(outdir) for f in fs if f.lower().endswith(('.mxl', '.musicxml'))]
                    else:
                        subprocess.run(BASIC_PITCH.split() + [outdir, full], capture_output=True, timeout=900)
                        outs = [os.path.join(outdir, f) for f in os.listdir(outdir) if f.lower().endswith('.mid')]
                    with lock: state[i] = {'status': 'ready', 'out': outs[0]} if outs else {'status': 'failed', 'error': 'The computer could not read this file.'}
                except Exception as e:
                    with lock: state[i] = {'status': 'failed', 'error': str(e)[:200]}
                break     # rescan after each conversion
        except Exception:
            pass
        time.sleep(5)

def cached_outputs():
    """remember conversions across restarts"""
    for i in os.listdir(CACHE):
        d = os.path.join(CACHE, i)
        outs = [os.path.join(dp, f) for dp, _, fs in os.walk(d) for f in fs if f.lower().endswith(('.mxl', '.musicxml', '.mid'))]
        if outs: state[i] = {'status': 'ready', 'out': outs[0]}

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def cors(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Access-Control-Allow-Private-Network', 'true')
    def send(self, code, body, ctype='application/json', extra=None):
        b = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code); self.cors(); self.send_header('Content-Type', ctype); self.send_header('Content-Length', str(len(b)))
        self.send_header('Cache-Control', 'no-store')
        for k, v in (extra or {}).items(): self.send_header(k, v)
        self.end_headers(); self.wfile.write(b)
    def do_OPTIONS(self):
        self.send_response(204); self.cors(); self.send_header('Content-Length', '0'); self.end_headers()
    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path == '/api/music/list':
            items = catalog()
            for it in items: it.pop('_full', None)
            return self.send(200, {'folder': MUSIC_DIR, 'items': items, 'converters': {'scan': bool(AUDIVERIS), 'audio': bool(BASIC_PITCH)}})
        m = re.match(r'^/api/music/file/([0-9a-f]{16})$', path)
        if m:
            it = next((x for x in catalog() if x['id'] == m.group(1)), None)
            if not it: return self.send(404, {'error': 'not found'})
            if it['kind'] == 'notation': src, name = it['_full'], it['name']
            else:
                with lock: s = state.get(it['id'], {})
                if s.get('status') != 'ready': return self.send(409, {'error': 'not ready', 'status': s.get('status', it['status'])})
                src = s['out']; name = os.path.splitext(it['name'])[0] + os.path.splitext(src)[1]
            return self.send(200, open(src, 'rb').read(), 'application/octet-stream', {'X-File-Name': urllib.parse.quote(name)})
        # spoken prompts for child mode, made once by make-voice.sh
        if path == '/api/music/voice/list':
            f = os.path.join(VOICE_DIR, 'list.json')
            return self.send(200, open(f, 'rb').read() if os.path.exists(f) else b'{"items":[]}', 'application/json')
        m = re.match(r'^/api/music/voice/([a-z0-9_]{1,40})$', path)
        if m:
            for ext, ct in (('.ogg', 'audio/ogg'), ('.wav', 'audio/wav')):
                f = os.path.join(VOICE_DIR, m.group(1) + ext)
                if os.path.exists(f): return self.send(200, open(f, 'rb').read(), ct, {'Cache-Control': 'max-age=86400'})
            return self.send(404, {'error': 'no clip'})
        if path in ('/', '/index.html') and os.path.exists(os.path.join(HERE, 'index.html')):
            return self.send(200, open(os.path.join(HERE, 'index.html'), 'rb').read(), 'text/html; charset=utf-8')
        self.send(404, {'error': 'not found'})
    def do_POST(self):
        u = urllib.parse.urlparse(self.path)
        if u.path != '/api/music/upload': return self.send(404, {'error': 'not found'})
        name = os.path.basename(urllib.parse.parse_qs(u.query).get('name', [''])[0])
        ext = os.path.splitext(name)[1].lower()
        if not name or ext not in DIRECT | SCAN | AUDIO: return self.send(400, {'error': 'unsupported file'})
        n = int(self.headers.get('Content-Length') or 0)
        if n <= 0 or n > 50_000_000: return self.send(413, {'error': 'too large'})
        dest_dir = os.path.join(MUSIC_DIR, 'From the tablet'); os.makedirs(dest_dir, exist_ok=True)
        dest = os.path.join(dest_dir, name)
        if os.path.exists(dest): return self.send(200, {'ok': True, 'exists': True})
        data = self.rfile.read(n)
        with open(dest + '.part', 'wb') as f: f.write(data)
        os.replace(dest + '.part', dest)
        self.send(200, {'ok': True})

if __name__ == '__main__':
    cached_outputs()
    threading.Thread(target=convert_loop, daemon=True).start()
    print(f'Keys Music: {MUSIC_DIR} on port {PORT}', flush=True)
    ThreadingHTTPServer((BIND, PORT), H).serve_forever()
