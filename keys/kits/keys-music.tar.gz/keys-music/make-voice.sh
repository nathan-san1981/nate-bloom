#!/bin/sh
# Make the spoken prompts for Keys child mode with Piper (free, offline neural voice).
#   ./make-voice.sh                 make all clips with the default voice
#   ./make-voice.sh --samples       one line in four voices, to pick from (voice-samples/)
#   ./make-voice.sh --voice NAME    use another voice, e.g. en_US-amy-medium
# Clips land in ./voice and are served to the tablet and the Pi by keys-music.
set -e
cd "$(dirname "$0")"
VOICE=en_US-lessac-medium
SAMPLES=0
while [ $# -gt 0 ]; do case "$1" in --voice) VOICE="$2"; shift 2;; --samples) SAMPLES=1; shift;; *) echo "unknown option $1"; exit 1;; esac; done
if [ ! -x piper-venv/bin/python ]; then
  echo "Installing Piper (one time)..."
  python3 -m venv piper-venv
  piper-venv/bin/pip install -q --upgrade pip piper-tts
fi
mkdir -p voices voice
piper-venv/bin/python - "$VOICE" "$SAMPLES" <<'PY'
import sys, os, subprocess, json, wave, shutil
voice, samples = sys.argv[1], sys.argv[2] == '1'
from piper import PiperVoice
def get(name):
    path = os.path.join('voices', name + '.onnx')
    if not os.path.exists(path):
        subprocess.run([sys.executable, '-m', 'piper.download_voices', name, '--data-dir', 'voices'], check=True)
    return PiperVoice.load(path)
ff = shutil.which('ffmpeg')
def say(v, text, out_base):
    wav = out_base + '.wav'
    with wave.open(wav, 'wb') as w: v.synthesize_wav(text, w)
    if ff:
        r = subprocess.run([ff, '-y', '-loglevel', 'error', '-i', wav, '-af', 'silenceremove=start_periods=1:start_threshold=-50dB,areverse,silenceremove=start_periods=1:start_threshold=-50dB,areverse,apad=pad_dur=0.08',
                            '-c:a', 'libopus', '-b:a', '40k', out_base + '.ogg'])
        if r.returncode == 0: os.remove(wav)
if samples:
    os.makedirs('voice-samples', exist_ok=True)
    for name in ['en_US-lessac-medium', 'en_US-amy-medium', 'en_US-hfc_female-medium', 'en_US-ryan-high']:
        print('sample', name); say(get(name), "Great job! Now find C, and play it with finger one.", os.path.join('voice-samples', name))
    print('Listen to the files in voice-samples/, then run: ./make-voice.sh --voice <name>')
    sys.exit()
v = get(voice); keys = []
for line in open('voice-phrases.txt', encoding='utf-8'):
    line = line.strip()
    if not line or line.startswith('#') or '|' not in line: continue
    k, text = [x.strip() for x in line.split('|', 1)]
    for old in ('.ogg', '.wav'):
        p = os.path.join('voice', k + old)
        if os.path.exists(p): os.remove(p)
    say(v, text, os.path.join('voice', k)); keys.append(k); print('  ', k, '-', text)
json.dump({'voice': voice, 'items': keys}, open(os.path.join('voice', 'list.json'), 'w'))
print(f'{len(keys)} clips made with {voice}. On the tablet: parent controls -> Voice -> Get the voice.')
PY
