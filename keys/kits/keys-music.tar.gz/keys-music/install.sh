#!/bin/bash
# Keys Music on the Beelink (Linux Mint). Run from this folder:  ./install.sh
# Options:  --with-pdf    install Audiveris (reads PDFs/photos of sheet music)
#           --with-audio  install basic-pitch (turns recordings into notes)
# Safe to re-run.
set -euo pipefail
cd "$(dirname "$0")"
WITH_PDF=0; WITH_AUDIO=0
for a in "$@"; do case "$a" in --with-pdf) WITH_PDF=1;; --with-audio) WITH_AUDIO=1;; esac; done
U=$(id -un)
APP_URL="https://nathan-san1981.github.io/nate-bloom/keys/"
echo "== files"
install -d "$HOME/keys-music"
install -m 755 keys-music.py "$HOME/keys-music/"
[ -f index.html ] && install -m 644 index.html "$HOME/keys-music/"
install -m 755 make-voice.sh "$HOME/keys-music/"
[ -f "$HOME/keys-music/voice-phrases.txt" ] || install -m 644 voice-phrases.txt "$HOME/keys-music/"   # keep any wording you changed
MUSIC_DIR="$HOME/Piano Music"
install -d "$MUSIC_DIR"
cat > "$MUSIC_DIR/READ ME.txt" <<TXT
Put music here and it appears in Keys (the piano app) on the tablet and the Pi box.

Best: MusicXML files (.mxl or .musicxml) — on MuseScore.com choose Download > MusicXML.
Also fine: MIDI files (.mid).
PDFs and photos of sheet music, and MP3 recordings, are converted here first (if the converters are installed).

Folders inside this folder are fine. Deleting a file here does not delete it from the tablet.
TXT
[ -f /etc/keys-music.conf ] || sudo tee /etc/keys-music.conf >/dev/null <<CONF
MUSIC_DIR=$MUSIC_DIR
PORT=8770
BIND=0.0.0.0
# AUDIVERIS_CMD=     (auto-detected)
# BASIC_PITCH_CMD=   (auto-detected)
CONF

if [ $WITH_PDF = 1 ]; then
  echo "== Audiveris (sheet-music reader)"
  sudo apt-get install -y -qq flatpak >/dev/null
  flatpak remote-add --user --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo
  flatpak install --user -y flathub org.audiveris.audiveris
fi
if [ $WITH_AUDIO = 1 ]; then
  echo "== basic-pitch (recording -> notes)"
  sudo apt-get install -y -qq pipx >/dev/null
  pipx install basic-pitch || pipx upgrade basic-pitch
  pipx ensurepath >/dev/null
fi

echo "== service"
install -d "$HOME/.config/systemd/user"
cat > "$HOME/.config/systemd/user/keys-music.service" <<UNIT
[Unit]
Description=Keys Music (Piano Music folder for the Keys app)
After=network-online.target

[Service]
Environment=PATH=$HOME/.local/bin:/usr/local/bin:/usr/bin:/bin
ExecStart=/usr/bin/python3 $HOME/keys-music/keys-music.py
Restart=always
RestartSec=3
Nice=10

[Install]
WantedBy=default.target
UNIT
sudo loginctl enable-linger "$U"
systemctl --user daemon-reload
systemctl --user enable --now keys-music.service
systemctl --user restart keys-music.service

echo "== secure address for the tablet (Tailscale)"
TS_URL=""
if command -v tailscale >/dev/null 2>&1; then
  sudo tailscale serve --bg --https=8443 http://127.0.0.1:8770 >/dev/null 2>&1 || true
  DNS=$(tailscale status --json 2>/dev/null | python3 -c 'import sys,json; print(json.load(sys.stdin)["Self"]["DNSName"].rstrip("."))' 2>/dev/null || true)
  [ -n "$DNS" ] && TS_URL="https://$DNS:8443"
fi
LAN_IP=$(hostname -I | awk '{print $1}')
sleep 1
curl -fs "http://127.0.0.1:8770/api/music/list" >/dev/null && echo "Keys Music is running." || echo "!! Not answering yet: journalctl --user -u keys-music"
echo
echo "Music folder:     $MUSIC_DIR"
echo "For the Pi box:   MUSIC_SERVER=http://$LAN_IP:8770   (put this line in /etc/keys-box.conf on the Pi)"
if [ -n "$TS_URL" ]; then
  PAIR="$APP_URL#music=$(python3 -c "import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1], safe=''))" "$TS_URL")"
  echo "For the tablet:   $TS_URL  (the tablet needs the Tailscale app, signed in to your account)"
  echo
  echo "Scan this with the tablet's camera to connect Keys to this computer:"
  command -v qrencode >/dev/null || sudo apt-get install -y -qq qrencode >/dev/null
  qrencode -t ANSIUTF8 -m 2 "$PAIR"
  qrencode -t PNG -s 10 -o "$HOME/keys-music/connect-tablet.png" "$PAIR" && echo "(also saved as ~/keys-music/connect-tablet.png)"
  echo "$PAIR"
else
  echo "Tailscale not found: the tablet can still add files from itself; install Tailscale here and on the tablet, then re-run this to connect them."
fi
